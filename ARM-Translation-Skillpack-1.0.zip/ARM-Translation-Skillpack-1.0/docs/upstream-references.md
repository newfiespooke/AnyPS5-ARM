# Upstream References

Check the selected project's current documentation, supported targets, issue tracker, release notes, and license before integrating. Capabilities and requirements change over time.

## CPU and userspace translation

- FEX: https://github.com/FEX-Emu/FEX
- Box64: https://github.com/ptitSeb/box64
- Box86: https://github.com/ptitSeb/box86
- QEMU user-mode documentation: https://www.qemu.org/docs/master/user/
- QEMU emulation overview: https://www.qemu.org/docs/master/about/emulation.html

## Windows compatibility and graphics

- Wine: https://gitlab.winehq.org/wine/wine
- Proton: https://github.com/ValveSoftware/Proton
- DXVK: https://github.com/doitsujin/dxvk
- VKD3D-Proton: https://github.com/HansKristian-Work/vkd3d-proton
- Vulkan porting resources: https://www.vulkan.org/porting

## Android native development

- Android NDK ABIs: https://developer.android.com/ndk/guides/abis
- Android NDK CMake: https://developer.android.com/ndk/guides/cmake

## Integration checklist

For every upstream component, record:

- Exact Git commit or release tag.
- License and required notices.
- Supported host OS/ISA and guest ISA/ABI.
- Build dependencies and toolchain versions.
- Test commands and results.
- Known limitations, open issues, and security advisories.
- Local patch set and reason for each patch.

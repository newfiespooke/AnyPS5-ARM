# Architecture Reference: x86/x64 Compatibility on ARM

## 1. Four independent axes

Every port must identify four separate axes:

| Axis | Example | Why it matters |
|---|---|---|
| Instruction set | x86-64 guest, AArch64 host | Determines how instructions execute. |
| ABI | SysV AMD64, AAPCS64, Android `arm64-v8a` | Determines calls, data layout, registers, and binary interfaces. |
| Operating system | Linux, Android, Windows, macOS | Determines syscalls, APIs, process model, permissions, and libraries. |
| Executable format | ELF, PE/COFF, Mach-O, proprietary | Determines loader, relocations, imports, and metadata. |

An ARM64 CPU does not make Linux binaries directly executable on Android or macOS. A CPU translator does not automatically translate OS APIs.

## 2. Responsibilities and candidate projects

| Component | Main responsibility | Candidate project | Important boundary |
|---|---|---|---|
| x86-64 Linux user-mode translation | Execute Linux x86-64 userspace programs on ARM64 Linux | Box64, FEX | Requires compatible guest userspace and host integration. |
| x86 Linux user-mode translation | Execute 32-bit Linux x86 programs | Box86, QEMU user | 32-bit userspace/toolchain requirements matter. |
| Cross-architecture user-mode emulation | Run foreign-ISA programs under a compatible OS interface | QEMU user | Not a complete guest machine. |
| Windows API compatibility | Implement Windows APIs on supported host OSes | Wine | Does not itself translate x86 instructions. |
| Steam Windows game compatibility | Wine-based Steam compatibility stack | Proton | Requires Steam-oriented components/integration. |
| D3D 8/9/10/11 to Vulkan | Graphics API translation | DXVK | Needs supported Vulkan driver/features. |
| D3D12 to Vulkan | Graphics API translation | VKD3D-Proton | Its feature and driver requirements are version-specific. |
| Android native build | Build ARM libraries for Android | Android NDK | Android/Bionic is not generic glibc Linux. |

## 3. Typical Linux Windows-game path

A simplified path may look like:

```text
Windows x86/x64 game (PE)
        |
        v
Wine / Proton Windows API compatibility
        |
        +---- graphics DLL path: DXVK or VKD3D-Proton
        |
        v
Guest x86/x64 code execution layer (e.g. FEX or Box64 integration)
        |
        v
Linux ARM64 host libraries / Vulkan / kernel
        |
        v
ARM CPU + GPU
```

This is conceptual. The exact ordering, process model, ABI, 32-bit support, and integration differ between runtimes and versions. Validate the actual selected project's architecture rather than assuming the diagram is an implementation specification.

## 4. Android-specific caution

Android's ARM64 ABI is `arm64-v8a`, but Android is not simply a desktop Linux distribution. It has Bionic, a managed application lifecycle, sandbox/permission constraints, scoped storage, and Android graphics/audio APIs. Porting a Linux user-mode emulator to Android requires an explicit Android host port and dependency audit.

## 5. AnyPS5 project boundary

An experimental PS5 runtime needs independent research into guest executable/package formats, CPU state and instruction behavior, guest ABI, system services, libraries, memory model, threading, graphics, audio, input, and storage. Wine/Proton are Windows API compatibility projects; Box64/FEX target Linux x86 userspace execution models. They may offer reusable ideas or isolated components, but none is a PS5 compatibility layer by itself.

Do not claim a PS5 title runs because an ARM64 APK builds, a menu renders, or a generic x86 program executes. Report the exact stage that was demonstrated.

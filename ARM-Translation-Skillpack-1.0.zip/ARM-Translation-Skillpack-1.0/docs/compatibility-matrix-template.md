# Compatibility Matrix Template

Copy this file into the target repository and replace every placeholder.

## Target tuple

| Field | Value |
|---|---|
| Project/version | TODO |
| Host OS/version | TODO |
| Host ISA/CPU | TODO |
| Host ABI/userspace | TODO |
| Guest OS/API | TODO |
| Guest ISA/bitness | TODO |
| Guest ABI | TODO |
| Guest binary format | TODO |
| Runtime/translator versions | TODO |
| GPU/driver/API | TODO |

## Feature status

Use only: `NOT_ASSESSED`, `BLOCKED`, `NOT_IMPLEMENTED`, `IMPLEMENTED_UNTESTED`, `TESTED_PASS`, `TESTED_PARTIAL`, `TESTED_FAIL`, `NOT_APPLICABLE`.

| Feature | Status | Test scope/version | Evidence/log | Limitations |
|---|---|---|---|---|
| Executable parsing | NOT_ASSESSED | TODO | TODO | TODO |
| Loader and relocations | NOT_ASSESSED | TODO | TODO | TODO |
| Integer instructions | NOT_ASSESSED | TODO | TODO | TODO |
| Floating-point instructions | NOT_ASSESSED | TODO | TODO | TODO |
| SIMD instructions | NOT_ASSESSED | TODO | TODO | TODO |
| Guest memory model/atomics | NOT_ASSESSED | TODO | TODO | TODO |
| Guest ABI and callbacks | NOT_ASSESSED | TODO | TODO | TODO |
| OS/API compatibility | NOT_ASSESSED | TODO | TODO | TODO |
| Dynamic libraries | NOT_ASSESSED | TODO | TODO | TODO |
| Filesystem/network | NOT_ASSESSED | TODO | TODO | TODO |
| Threads/signals/exceptions | NOT_ASSESSED | TODO | TODO | TODO |
| Graphics | NOT_ASSESSED | TODO | TODO | TODO |
| Audio | NOT_ASSESSED | TODO | TODO | TODO |
| Input/controllers | NOT_ASSESSED | TODO | TODO | TODO |
| Installation/lifecycle | NOT_ASSESSED | TODO | TODO | TODO |
| Security/fuzzing | NOT_ASSESSED | TODO | TODO | TODO |
| Performance | NOT_ASSESSED | TODO | TODO | TODO |

## Hardware test table

| Device/SoC | OS build | CPU features | GPU/driver | Runtime commit | Result |
|---|---|---|---|---|---|
| TODO | TODO | TODO | TODO | TODO | TODO |

## Release claims

List only claims supported by the evidence above. Identify whether each test ran on an emulator, virtual machine, or physical ARM hardware.

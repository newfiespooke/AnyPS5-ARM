# ARM Translation Engineering Skillpack 1.0

A reusable skill pack for analyzing, porting, integrating, and validating x86/x64 software and compatibility runtimes on ARM32/ARM64.

## Contents

### Core skills
- `skills/arm-software-engineering.skill` — native ARM application and systems development.
- `skills/x86-x64-to-arm-porting.skill` — source-level and binary-boundary porting from x86/x64 to ARM.
- `skills/translation-layers-to-arm.skill` — architecture for CPU translators, API compatibility layers, Wine/Proton integrations, graphics, audio, and input.
- `skills/translation-runtime-validation.skill` — differential testing, conformance, security, performance, release gates, and evidence reporting.

### Engineering references and templates
- `docs/architecture-reference.md` — layer boundaries and project selection guidance.
- `docs/compatibility-matrix-template.md` — reusable target and feature matrix.
- `docs/porting-plan-template.md` — phased project plan and gates.
- `docs/upstream-references.md` — primary upstream documentation links checked for this release.

## How to use

1. Read the core skill relevant to the task.
2. Read `translation-layers-to-arm.skill` when integrating an execution translator or compatibility runtime.
3. Apply `translation-runtime-validation.skill` before claiming any feature works.
4. Copy the templates into the target repository and fill them with verified project facts.
5. Keep upstream projects as version-pinned dependencies unless there is a documented reason to fork them.

## Engineering scope

This pack supports Android, Linux, macOS, Windows on ARM, and embedded ARM systems. It distinguishes CPU instruction translation, OS/API compatibility, binary loading, and graphics translation. These are separate responsibilities and must be tested separately.

For AnyPS5-like research projects, this pack provides engineering process and runtime architecture guidance only. It does not provide PS5 firmware, console keys, proprietary system libraries, game binaries, or a working PS5 emulator. A Windows/Linux compatibility layer is not a PS5 compatibility implementation.

## Versioning

- Skillpack version: 1.0
- Format: Markdown with YAML-style front matter
- File extension: `.skill`
- Generated: 2026-11-09

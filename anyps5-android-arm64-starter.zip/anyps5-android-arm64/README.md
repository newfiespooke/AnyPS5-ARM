# AnyPS5 Android ARM64 (starter port)

This is the first native Android application scaffold for an AnyPS5 ARM64 port. It is deliberately an integration shell, **not a working PS5 game runtime yet**.

## Current milestone

- Native Android package target: `arm64-v8a`
- Kotlin Android activity with JNI
- Native C++ runtime capability report
- SAF-based file picker for user-selected test inputs
- CMake/NDK build configuration
- Explicit status showing that the AnyPS5 relinker, x86-64 guest execution, PS5 PRX libraries and Vulkan runtime are not integrated yet

## Architecture direction

`Android UI (Kotlin) -> JNI -> libanyps5_android.so (ARM64) -> platform adapter`

The native process is ARM64. AnyPS5's current Linux/Windows relinker emits an x86-64 guest program, so it cannot run directly on an ARM64 Android host. Our preferred route is to adapt the experimental `AnyPS5-ARM/native-arm64` branch: it translates x86-64 guest functions ahead of time through Capstone + LLVM into AArch64 and builds PRX libraries for ARM64. That branch has demonstrated a native ARM64 homebrew DOOM milestone on Apple silicon, but it is experimental and macOS-specific. Android/Bionic still needs its own ABI, signal, TLS, memory, unwind, and toolchain work. Box64 remains a useful fallback/reference route, not the definition of our native target.

Graphics direction: native Android Vulkan backend, initially capability-probed only. The separate Android reference project demonstrates a native ARM64 SDL_GPU/Vulkan bridge and a Box64 guest path, but its game-specific hooks and patches must not be copied blindly.

## Build

Requirements:
- Android Studio or command-line Android SDK
- Android NDK (side-by-side)
- CMake 3.22.1+
- JDK 17

Open this folder in Android Studio and build the `app` configuration, or run:

```bash
gradle :app:assembleDebug
```

The output APK is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations

1. This scaffold does not execute PS5 ELF files.
2. It does not include Sony firmware, SDKs, keys, game data, or decryption/circumvention tools.
3. It does not bundle AnyPS5, Box64, Mesa/Turnip, SDL, or shader tools. Those must be integrated from their own verified upstream sources and licenses.
4. File selection is for local diagnostics only. It does not imply that selected files are valid or supported.
5. No APK build was run in the authoring environment because Android SDK/NDK and network access to fetch dependencies were unavailable.

## Next engineering milestones

A. Reproducible ARM64 APK build and device smoke test.
B. Pin upstream AnyPS5 and inspect the experimental `AnyPS5-ARM/native-arm64` translator as the primary CPU strategy.
C. Port the Capstone + LLVM AOT translator to Android host tooling (or ship a desktop-side converter first), while keeping the runtime and PRX libraries ARM64/Bionic.
D. Port the native runtime boundary: guest state, callbacks, TLS, signals, memory mapping, and calling-convention bridges. Treat setjmp/longjmp, fibers, C++ unwinding, and x86 TSO memory ordering as explicit blockers.
E. Build the relinker and PRX libraries for Android/Bionic where technically valid.
F. Add Android Vulkan + SDL3 backend and feature tests.
G. Bring up one lawful homebrew/public test ELF and report exact blockers.

## Licensing

AnyPS5 is GPL-2.0-only. When upstream code is integrated, preserve its license and comply with source-distribution requirements. This starter scaffold contains no copied AnyPS5 implementation code; review all third-party licenses before adding dependencies.

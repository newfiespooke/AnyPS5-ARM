package org.anyps5.android

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private val pickInput = 1001

    private external fun nativeGetStatus(): String
    private external fun nativeInspectUri(uri: String): String

    companion object {
        init {
            System.loadLibrary("anyps5_android")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
        }

        val title = TextView(this).apply {
            text = "AnyPS5 Android"
            textSize = 26f
        }
        val subtitle = TextView(this).apply {
            text = "Native ARM64 development build"
            textSize = 14f
            setPadding(0, 8, 0, 24)
        }

        statusView = TextView(this).apply {
            textSize = 14f
            setTextIsSelectable(true)
        }

        val choose = Button(this).apply {
            text = "Select a local test file"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, pickInput)
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(choose)
        root.addView(statusView)
        setContentView(ScrollView(this).apply { addView(root) })
        refreshStatus()
    }

    private fun refreshStatus(extra: String? = null) {
        statusView.text = buildString {
            append(nativeGetStatus())
            if (extra != null) {
                append("\n\nSelected input:\n")
                append(extra)
            }
        }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickInput && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            refreshStatus(nativeInspectUri(uri.toString()))
        }
    }
}

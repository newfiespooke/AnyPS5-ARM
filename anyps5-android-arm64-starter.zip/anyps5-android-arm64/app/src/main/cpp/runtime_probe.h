#pragma once
#include <string>

namespace aps5 {
std::string BuildRuntimeReport();
std::string InspectSelectedUri(const std::string& uri);
}

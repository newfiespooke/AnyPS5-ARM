#include <jni.h>

#include "runtime_probe.h"

#include <string>

namespace {
std::string FromJString(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (chars == nullptr) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

jstring ToJString(JNIEnv* env, const std::string& value) {
    return env->NewStringUTF(value.c_str());
}
} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_org_anyps5_android_MainActivity_nativeGetStatus(JNIEnv* env, jobject) {
    return ToJString(env, aps5::BuildRuntimeReport());
}

extern "C" JNIEXPORT jstring JNICALL
Java_org_anyps5_android_MainActivity_nativeInspectUri(
    JNIEnv* env, jobject, jstring uri) {
    return ToJString(env, aps5::InspectSelectedUri(FromJString(env, uri)));
}

#include "runtime_probe.h"

#include <android/api-level.h>
#include <sys/utsname.h>

#include <sstream>

namespace aps5 {

std::string BuildRuntimeReport() {
    struct utsname info {};
    const int unameResult = uname(&info);

    std::ostringstream out;
    out << "Build: 0.1.0-dev\n";
#if defined(__aarch64__)
    out << "Native ABI: AArch64 / arm64-v8a\n";
#else
    out << "Native ABI: NOT arm64 (unexpected build configuration)\n";
#endif
    out << "Android API: " << android_get_device_api_level() << "\n";
    if (unameResult == 0) {
        out << "Kernel: " << info.sysname << " " << info.release << "\n";
        out << "Machine: " << info.machine << "\n";
    }

    out << "\nRuntime integration status\n";
    out << "- AnyPS5 relinker: not integrated\n";
    out << "- PS5 PRX/system libraries: not integrated\n";
    out << "- x86-64 guest translator: not integrated\n";
    out << "- Vulkan renderer: capability probe pending\n";
    out << "- SDL/controller/audio: not integrated\n";
    out << "\nThis is an ARM64 Android shell, not yet a game runner.";
    return out.str();
}

std::string InspectSelectedUri(const std::string& uri) {
    // SAF content URIs must be opened through Android ContentResolver.
    // This function intentionally does not pretend a URI is a filesystem path.
    std::ostringstream out;
    out << uri << "\n";
    out << "URI recorded only. Native file access must be implemented through "
           "a JNI ContentResolver/PFD bridge before parsing.";
    return out.str();
}

} // namespace aps5

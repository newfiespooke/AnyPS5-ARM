# Native ARM64 Android port plan

## Confirmed upstream architecture

AnyPS5's documented conversion path reads PS5 imports by NID, validates syscalls, converts bundled modules, patches the output executable, and relies on host shared libraries implementing the imported PRX functions. Current Linux/Windows output is a native x86-64 program. That output is not directly executable on Android ARM64.

## Proposed target layout

```text
Android app (Kotlin)
  └── JNI / Android lifecycle bridge
      └── libanyps5_android.so (arm64-v8a)
          ├── Android platform layer (Bionic, pthread, mmap, signals)
          ├── AnyPS5 relinker (Android-host build)
          ├── PRX library set (ARM64 host libraries)
          ├── Guest execution bridge
          │   ├── Preferred: AOT x86-64 → AArch64 translator (Capstone + LLVM)
          │   └── Fallback/reference: Box64 guest execution
          ├── Graphics
          │   └── Vulkan / SDL3 Android backend
          └── Input/audio/window lifecycle
```

## Critical distinction

"Native ARM64 Android app" means the Android process and native platform libraries are ARM64. It does **not** make the x86-64 guest instructions produced by the current relinker native ARM64. The guest CPU boundary must be translated or the relinker and all guest code generation must be changed and verified. The experimental AnyPS5-ARM `native-arm64` branch already contains an ahead-of-time translator that lifts x86-64 functions into LLVM IR and emits AArch64. It is the best architectural reference for a truly native target, but it currently targets Apple Silicon/macOS and has documented gaps (bundled PRX modules, non-local control flow, exception unwinding, memory ordering, and instruction coverage). Android requires a separate Bionic port, not a blind branch copy.

## First integration tasks

1. Pin AnyPS5 upstream commit and record submodule state.
2. Build a minimal Android-host `ANYPS5_RELINKER_ONLY` configuration with NDK/Clang.
3. Classify every dependency and platform call that blocks Bionic/Android.
4. Evaluate and pin the experimental AnyPS5-ARM `native-arm64` translator. Port its Capstone/LLVM pipeline and AArch64 runtime to Android/Bionic; keep Box64 as a fallback/reference only. Do not conflate guest translation with compiling host PRX libraries for ARM64.
5. Differential-test translated instruction fixtures against x86-64 reference execution; then prove a tiny synthetic guest executable before attempting any game.
6. Add Vulkan instance/device enumeration and SDL3 Android lifecycle test.
7. Bring up a lawful homebrew/public test binary and record unsupported imports.

## Definition of done for milestone 0

- APK installs on a physical arm64-v8a device.
- Native report says AArch64.
- App survives activity recreation and background/foreground.
- SAF URI selection works without raw-path assumptions.
- No claim of PS5 game execution.

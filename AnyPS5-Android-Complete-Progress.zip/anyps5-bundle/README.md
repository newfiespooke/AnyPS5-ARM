# AnyPS5 Android Port - Complete Progress Archive

This is a consolidated archive of the recoverable AnyPS5 Android/ARM64 port work to date. Start with `PROJECT-STATUS.md` for an honest implementation status and build notes.

Folders:
- `source-releases/` - all recovered source snapshots, milestone/community ZIPs, and available checksums.
- `skills/` - source migration and PS5 reverse-engineering skill files used during the project.
- `documentation/` - project README and notes.

The newest source snapshot is `source-releases/AnyPS5-Android-0.4.0-alpha-source.zip`.

Important: the project is an Android ARM64/JNI foundation, not a completed PS5 emulator. No verified AnyPS5 APK is included because no successful APK build was completed in the available work.

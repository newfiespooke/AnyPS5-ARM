# AnyPS5 Android / ARM64 Port - Progress Bundle

Prepared: 2026-11-09
Repository target: https://github.com/newfiespooke/AnyPS5-ARM

## What is included

This bundle consolidates the recoverable project artifacts from the prior AnyPS5 Android porting sessions:

- `source-releases/AnyPS5-Android-0.4.0-alpha-source.zip` - latest source snapshot (77 archive entries; Kotlin Android app, JNI bridge, C++/CMake foundation, docs, tests and an Android APK GitHub Actions workflow).
- `source-releases/AnyPS5-Android-0.3.0-alpha-source.zip` - prior source snapshot (43 archive entries).
- Earlier milestone archives: 0.2.0 Samsung foundation, 0.1.1 smooth navigation, 0.1.0 initial source, ARM64 starter, and community pack.
- `skills/` - the recovered Android migration and PS5 reverse-engineering skill files.
- `documentation/README-AnyPS5-Android.md` - project notes and setup/porting overview.
- SHA-256 sidecar files for the 0.3.0 and 0.4.0 source archives.

## Latest source configuration (0.4.0-alpha)

- Android application package: `com.anyps5.android`
- Minimum Android version: API 26 (Android 8.0)
- Compile/target SDK: 35
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Java: 17
- Native ABI target: `arm64-v8a`
- NDK documented for build: `27.2.12479018`
- CMake: 3.22.1
- Gradle wrapper/build recommendation: Gradle 8.9

## Implemented foundation

The available source snapshots contain an Android app/dashboard foundation, Kotlin UI and native bridge declarations, a JNI/C++ bridge scaffold, CMake/NDK project wiring, ARM64 build configuration, diagnostics and file-import foundations, architecture/porting documentation, and test/build workflow scaffolding. Earlier engineering work also added or described bounded CPU/memory state scaffolds, ELF64 inspection, a NID registry, fail-closed translation placeholders, host-side native tests, sanitizer/fuzz-test scaffolding, and CI validation.

## Not implemented / not verified

This is **not a working PS5 emulator** and no installable AnyPS5 APK has been successfully built or tested on a Samsung device. The following remain major engineering work:

1. PS5 x86-64 instruction translation/execution on ARM64.
2. PS5 runtime, ABI, system-call and PRX/library compatibility.
3. Complete graphics translation/rendering path (including Vulkan integration).
4. Audio, storage and other platform services integration.
5. Full controller/DualSense support and game compatibility.
6. Samsung-device validation/certification and real-hardware performance testing.

The Android project and workflow are a foundation only. A successful Gradle build would produce an Android app package, not prove PS5 game execution.

## GitHub repository status at bundle preparation

The repository `newfiespooke/AnyPS5-ARM` was previously inspected. Its main branch contained several source ZIP archives, including the 0.4.0-alpha archive, plus a very short README and a placeholder workflow. An attempt to add a fuller README and an APK-build workflow was rejected by the connected GitHub integration with HTTP 403 (`Resource not accessible by integration`). Therefore those proposed changes were **not committed** and this bundle does not claim they are present in the remote repository.

The 0.4.0 source archive itself contains `.github/workflows/android-apk.yml`. The separate workflow proposal to extract/build the archive at repository root and upload a debug APK artifact was prepared in the conversation but could not be committed because of the permission error.

## Suggested next build milestone

Extract the 0.4.0 source archive into the repository, verify the Gradle wrapper and Android SDK/NDK versions, run the Android workflow, fix compile/test failures, and publish the resulting debug APK only after the build succeeds. Then proceed with the emulator/runtime work as separately tracked milestones.

# Changelog\n\n## 0.1.1-alpha\n- Added spring focus scaling for library tiles.\n- Added short animated color transitions for tile focus, tabs, and game rows.\n- Preserved large touch targets and controller-selected visual state.\n- Documented performance profiling requirements.\n\nThis release is not device-performance certified and does not include the PS5 runtime.\n
## 0.2.0-alpha — ARM64 and tablet foundation
- Restricted native APK ABI target to `arm64-v8a`.
- Added an NDK/CMake JNI bridge scaffold (status-only, no guest execution).
- Added responsive page insets and resizable activity behavior for tablets.
- Added upstream feature inventory and ARM64 translation architecture.
- Added Samsung tablet validation plan.
- No PS5 execution, ARM64 DBT, or Android PRX runtime is claimed in this alpha.

# AnyPS5 Android ARM64 port roadmap

## Phase 0 — Android shell (current alpha)
Native Compose dashboard, touch/controller navigation, SAF import, red adaptive icon, tablet-responsive page insets, and an NDK/JNI ARM64 bridge scaffold. This is not a PS5 execution runtime.

## Phase 1 — Build and device capability foundation
- Build only `arm64-v8a` with Android NDK/CMake.
- Add device report: ABI, API level, CPU feature flags, Vulkan version/extensions/features, memory budget, display modes, thermal status and controller inventory.
- Add Samsung tablet portrait/landscape, split-screen and DeX test matrix.
- Make all native work asynchronous and preserve UI responsiveness.

## Phase 2 — Upstream source integration audit
- Pin an upstream AnyPS5 commit and recursively initialize submodules.
- Preserve GPL-2.0-only and third-party licenses.
- Identify architecture-neutral relinker components and isolate x86-64-only code.
- Create an Android/Bionic portability layer; do not assume glibc compatibility.
- Keep upstream changes in a clean integration branch and document local patches.

## Phase 3 — ARM64 execution strategy
- Select and prototype x86-64 static translation, dynamic binary translation, or a hybrid.
- Implement guest register/flags and SIMD state, instruction decoding, control flow, relocations, indirect branches and code cache.
- Define exception, signal, TLS, atomics, memory mapping and unwind behavior.
- Build differential instruction tests against a trusted x86-64 reference.
- Do not claim general game compatibility until test coverage demonstrates it.

## Phase 4 — Android PRX/runtime
- Port NID resolution, guest module loading and lifecycle.
- Port supported PRX exports to ARM64 and Android/Bionic.
- Preserve guest ABI structures, error codes, thread behavior and memory semantics.
- Keep unknown exports explicitly unsupported and logged.

## Phase 5 — Graphics, display, audio and input
- Shader recompiler to SPIR-V and Android Vulkan pipeline.
- Android Surface/swapchain, VideoOut timing, refresh changes and lifecycle.
- SDL/Android gamepad hotplug, analog axes/triggers, touchpad/touch overlay, keyboard/mouse and per-title profiles.
- Low-latency audio output, audio focus and codec paths.
- File/archive/network/USB service adapters as upstream capabilities require.

## Phase 6 — Controlled title bring-up
- Homebrew/test binaries first.
- One title per reproducible report: exact build, device, Vulkan capabilities, logs, patches, compatibility status and known gaps.
- Fuzz executable parsing and translation; sanitizer-test native code.
- Thermal soak, memory-pressure and sustained frame-time testing on Samsung tablets.

## Phase 7 — Release
- CI builds a signed debug APK for testers and a release APK/AAB only after all required native modules and license notices are included.
- Release notes distinguish implemented, partial, unsupported and untested features.

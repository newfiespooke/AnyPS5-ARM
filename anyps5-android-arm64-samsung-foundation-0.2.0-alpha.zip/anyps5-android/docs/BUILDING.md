# Build and install

## Local build

Install JDK 17, Gradle 8.9, Android SDK Platform 35 and Android Build Tools 35.0.0, then run:

```sh
gradle --no-daemon :app:assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Install it on a connected Android device with:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions build

Push the source tree to a GitHub repository. Open Actions → Build Android APK → Run workflow. Download the `AnyPS5-Android-debug-apk` artifact from the completed workflow run.

The artifact is a debug-signed APK for testing, not a Play Store release. A public release needs a separately managed signing key and a release build configuration.


## ARM64 native bridge

Install Android SDK Platform 35, Android NDK (side by side), CMake 3.22.1, and JDK 17. The app config deliberately builds `arm64-v8a` only. The current JNI library is a status-only scaffold; it does not load or execute PS5 binaries.

Build locally with:

```bash
./gradlew :app:assembleDebug
```

The debug APK should contain `lib/arm64-v8a/libanyps5_android_bridge.so`. Confirm with:

```bash
unzip -l app/build/outputs/apk/debug/app-debug.apk | grep 'lib/arm64-v8a/'
```

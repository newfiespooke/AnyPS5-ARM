#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_anyps5_android_NativeBridge_nativeGetBridgeStatus(JNIEnv* env, jobject) {
    const std::string status =
        "ARM64 Android native bridge scaffold; PS5 execution backend is not connected";
    return env->NewStringUTF(status.c_str());
}

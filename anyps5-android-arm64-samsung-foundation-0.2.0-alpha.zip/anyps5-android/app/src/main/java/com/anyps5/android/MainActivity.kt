package com.anyps5.android

import android.content.Intent
import android.hardware.input.InputManager
import android.net.Uri
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent as NativeKeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.nativeKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF171820)
private val Red = Color(0xFFFF2438)
private val Muted = Color(0xFF9CA0AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 9, 13)
        window.navigationBarColor = android.graphics.Color.rgb(8, 9, 13)
        setContent { AnyPS5App() }
    }
}

private data class GameEntry(val name: String, val subtitle: String, val accent: Color)

@Composable
private fun AnyPS5App() {
    val context = LocalContext.current
    val games = remember { mutableStateListOf<GameEntry>() }
    var selected by remember { mutableIntStateOf(0) }
    var activeTab by remember { mutableStateOf("Home") }
    var notice by remember { mutableStateOf<String?>(null) }
    var importedName by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            importedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected game file"
            games.add(GameEntry(importedName ?: "Imported game", "Imported file · runtime not connected", Red))
            notice = "Game file added to your library. The PS5 runtime is not included in this UI preview yet."
        }
    }
    var hasController by remember { mutableStateOf(hasGameController()) }
    val inputManager = remember { context.getSystemService(InputManager::class.java) }
    DisposableEffect(inputManager) {
        val listener = object : InputManager.InputDeviceListener {
            override fun onInputDeviceAdded(deviceId: Int) { hasController = hasGameController() }
            override fun onInputDeviceRemoved(deviceId: Int) { hasController = hasGameController() }
            override fun onInputDeviceChanged(deviceId: Int) { hasController = hasGameController() }
        }
        inputManager?.registerInputDeviceListener(listener, null)
        onDispose { inputManager?.unregisterInputDeviceListener(listener) }
    }

    MaterialTheme {
        Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val tabletLayout = maxWidth >= 600.dp
                val wideLayout = maxWidth >= 840.dp
                val pageInset = when {
                    wideLayout -> 40.dp
                    tabletLayout -> 28.dp
                    else -> 18.dp
                }
                Column(
                modifier = Modifier
                    .fillMaxSize()
                    .onPreviewKeyEvent { event ->
                        val e = event.nativeKeyEvent
                        if (e.action == NativeKeyEvent.ACTION_DOWN) {
                            when (e.keyCode) {
                                NativeKeyEvent.KEYCODE_DPAD_LEFT -> { selected = (selected - 1).coerceAtLeast(0); true }
                                NativeKeyEvent.KEYCODE_DPAD_RIGHT -> { selected = (selected + 1).coerceAtMost(5 + games.size); true }
                                NativeKeyEvent.KEYCODE_DPAD_UP -> { activeTab = "Home"; true }
                                NativeKeyEvent.KEYCODE_DPAD_DOWN -> { activeTab = "Games"; true }
                                NativeKeyEvent.KEYCODE_BUTTON_A, NativeKeyEvent.KEYCODE_ENTER -> { notice = "Selected: ${tileName(selected, games)}"; true }
                                NativeKeyEvent.KEYCODE_BUTTON_B, NativeKeyEvent.KEYCODE_BACK -> { activeTab = "Home"; true }
                                NativeKeyEvent.KEYCODE_BUTTON_X -> { picker.launch(arrayOf("*/*")); true }
                                NativeKeyEvent.KEYCODE_BUTTON_Y, NativeKeyEvent.KEYCODE_BUTTON_START -> { activeTab = "Settings"; true }
                                else -> false
                            }
                        } else false
                    }
                    .padding(horizontal = pageInset, vertical = if (tabletLayout) 20.dp else 12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Header(activeTab, hasController) { activeTab = it }
                Spacer(Modifier.height(18.dp))
                HeroPanel(onLaunch = { notice = "The Android launcher UI is ready. The PS5 compatibility runtime still needs to be ported and integrated." }, onImport = { picker.launch(arrayOf("*/*")) })
                Spacer(Modifier.height(20.dp))
                SectionTitle(if (activeTab == "Settings") "System & input" else "Your library", "${games.size} imported")
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item { LibraryTile("PS5 Files", "Import a game file", Icons.Filled.FolderOpen, selected == 0, { selected = 0 }) { picker.launch(arrayOf("*/*")) } }
                    item { LibraryTile("Game Library", "${games.size} items", Icons.Filled.Gamepad, selected == 1, { selected = 1 }) { activeTab = "Games" } }
                    item { LibraryTile("Tools", "Runtime diagnostics", Icons.Filled.Tune, selected == 2, { selected = 2 }) { notice = "Diagnostics scaffold: ARM64 Android / Vulkan checks will be added with the runtime bridge." } }
                    item { LibraryTile("Settings", "Controls & display", Icons.Filled.Settings, selected == 3, { selected = 3 }) { activeTab = "Settings" } }
                    item { LibraryTile("About", "Build 0.2.0-alpha", Icons.Filled.Info, selected == 4, { selected = 4 }) { activeTab = "About" } }
                    item { LibraryTile("Add Game", "Choose a file", Icons.Filled.Add, selected == 5, { selected = 5 }) { picker.launch(arrayOf("*/*")) } }
                }
                Spacer(Modifier.height(18.dp))
                SectionTitle("Recently added", "${games.size} files")
                Spacer(Modifier.height(10.dp))
                if (games.isEmpty()) {
                    EmptyLibrary(onImport = { picker.launch(arrayOf("*/*")) })
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        games.forEachIndexed { index, game ->
                            GameRow(game, index == selected - 6) { notice = "${game.name}: added to library. Runtime support is not active yet." }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Footer(hasController)
                }
            }
        }
    }
    if (notice != null) {
        AlertDialog(
            onDismissRequest = { notice = null },
            containerColor = Panel,
            title = { Text("AnyPS5", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text(notice ?: "", color = Muted) },
            confirmButton = { TextButton(onClick = { notice = null }) { Text("OK", color = Red) } }
        )
    }
}


private fun hasGameController(): Boolean = InputDevice.getDeviceIds().any { id ->
    val device = InputDevice.getDevice(id)
    device != null && (
        device.sources and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD ||
            device.sources and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK
        )
}

private fun tileName(index: Int, games: List<GameEntry>): String = when (index) {
    0 -> "PS5 Files"; 1 -> "Game Library"; 2 -> "Tools"; 3 -> "Settings"; 4 -> "About"; 5 -> "Add Game"; else -> games.getOrNull(index - 6)?.name ?: "AnyPS5"
}

@Composable
private fun Header(active: String, hasController: Boolean, onTab: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Color(0xFFFF4957), Color(0xFF8E0010))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text("A", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("AnyPS5", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("FOR ANDROID", color = Red, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(22.dp))
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Home", "Games", "Tools", "Settings", "About").forEach { tab ->
                val chosen = active == tab
                val tabTint by animateColorAsState(
                    targetValue = if (chosen) Color.White else Muted,
                    animationSpec = tween(150),
                    label = "tabTint"
                )
                TextButton(onClick = { onTab(tab) }, colors = ButtonDefaults.textButtonColors(contentColor = tabTint)) {
                    Text(tab, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
        Box(Modifier.background(if (hasController) Color(0xFF153B2A) else Panel, CircleShape).padding(horizontal = 10.dp, vertical = 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Gamepad, null, tint = if (hasController) Color(0xFF57E39B) else Muted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text(if (hasController) "Controller" else "Touch", color = Color.White, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun HeroPanel(onLaunch: () -> Unit, onImport: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().background(
            Brush.horizontalGradient(listOf(Color(0xFF26070D), Color(0xFF11121A), Color(0xFF1D080D))),
            RoundedCornerShape(22.dp)
        ).border(1.dp, Color(0xFF55202B), RoundedCornerShape(22.dp)).padding(20.dp)
    ) {
        Column(Modifier.fillMaxWidth(0.72f)) {
            Text("PLAY. EXPLORE. REIMAGINED.", color = Red, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("AnyPS5", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
            Text("for Android", color = Red, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("A PS5-inspired launcher and compatibility project, built for touchscreens and game controllers.", color = Color(0xFFD0D0D7), fontSize = 13.sp, lineHeight = 19.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onLaunch, colors = ButtonDefaults.buttonColors(containerColor = Red), shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Filled.Bolt, null, tint = Color.White, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Launch")
                }
                OutlinedButton(onClick = onImport, border = BorderStroke(1.dp, Color(0xFF85404A)), shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Import game", color = Color.White)
                }
            }
        }
        Text("PS5", color = Color(0x22FFFFFF), fontSize = 64.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp))
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(18.dp).background(Red, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text(trailing, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun LibraryTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onFocus: () -> Unit,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val highlighted = focused || selected
    val scale by animateFloatAsState(
        targetValue = if (highlighted) 1.035f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "tileScale"
    )
    val borderWidth by animateDpAsState(
        targetValue = if (highlighted) 2.dp else 1.dp,
        animationSpec = tween(140),
        label = "tileBorder"
    )
    val background by animateColorAsState(
        targetValue = if (highlighted) Color(0xFF351018) else Panel,
        animationSpec = tween(160),
        label = "tileBackground"
    )
    val iconColor by animateColorAsState(
        targetValue = if (highlighted) Red else Color(0xFFE5E5EA),
        animationSpec = tween(140),
        label = "tileIcon"
    )

    Column(
        Modifier
            .width(144.dp)
            .height(112.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .background(background, RoundedCornerShape(16.dp))
            .border(borderWidth, if (highlighted) Red else Color(0xFF2C2E38), RoundedCornerShape(16.dp))
            .onFocusChanged {
                focused = it.isFocused
                if (it.isFocused) onFocus()
            }
            .clickable { onFocus(); onClick() }
            .focusable()
            .padding(13.dp)
            .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow)),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(icon, null, tint = iconColor, modifier = Modifier.size(25.dp))
        Column {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun EmptyLibrary(onImport: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF111219), RoundedCornerShape(16.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Filled.FolderOpen, null, tint = Red, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(6.dp))
        Text("Your library is waiting", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Import a legally obtained game file to add it here.", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onImport, border = BorderStroke(1.dp, Red)) { Text("Browse files", color = Color.White) }
    }
}

@Composable
private fun GameRow(game: GameEntry, selected: Boolean, onClick: () -> Unit) {
    val rowColor by animateColorAsState(
        targetValue = if (selected) Color(0xFF2A1017) else Panel,
        animationSpec = tween(150),
        label = "gameRowColor"
    )
    Row(Modifier.fillMaxWidth().background(rowColor, RoundedCornerShape(12.dp)).clickable { onClick() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(36.dp).background(game.accent.copy(alpha = 0.18f), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Apps, null, tint = game.accent)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(game.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(game.subtitle, color = Muted, fontSize = 10.sp)
        }
        Text("IMPORTED", color = Color(0xFFFF8792), fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Footer(hasController: Boolean) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF111219), RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF58D68D), modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(if (hasController) "Controller detected" else "Touch controls ready", color = Color.White, fontSize = 10.sp)
        Spacer(Modifier.weight(1f))
        Text("D-pad Navigate   •   A Select   •   B Back   •   X Import", color = Muted, fontSize = 9.sp)
    }
}

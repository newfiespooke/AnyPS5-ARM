package com.anyps5.android

object NativeBridge {
    private val loaded: Boolean = try {
        System.loadLibrary("anyps5_android_bridge")
        true
    } catch (_: UnsatisfiedLinkError) {
        false
    }

    external fun nativeGetBridgeStatus(): String

    fun status(): String = if (loaded) {
        nativeGetBridgeStatus()
    } else {
        "Native ARM64 bridge is not installed in this build"
    }
}

# Android graphics and audio roadmap

## Vulkan

1. Enumerate physical devices, queue families, extensions, features, formats and memory heaps.
2. Define a renderer interface independent of Compose and the launcher.
3. Create Android surface/swapchain lifecycle integration.
4. Add command submission, synchronization, resource lifetime and device-loss handling.
5. Implement shader translation only after the upstream shader representation and legal integration path are verified.
6. Build per-GPU capability profiles. Do not assume Turnip is usable outside supported Qualcomm Adreno configurations.

## Audio

1. Open AAudio streams with low-latency/performance mode where available.
2. Add a bounded callback mixer and ring buffer with no allocation in the real-time callback.
3. Track underruns, callback duration, sample rate and channel layout.
4. Add guest audio API mapping only after the relevant PS5 audio interfaces are identified and documented.

Neither subsystem should report success for a feature that is only a stub.

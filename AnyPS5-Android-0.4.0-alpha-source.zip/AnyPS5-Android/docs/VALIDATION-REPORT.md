# Validation report for 0.4.0-alpha source update

## Passed in this turn

- CMake configured the portable native runtime core.
- `anyps5_runtime_core` compiled, including the new backend factory and PRX metadata inspector.
- `anyps5_runtime_tests` compiled.
- CTest: `1/1` test passed, including explicit fail-closed backend selection and malformed PRX rejection.

## Host build limitation

A full default host build also attempted to compile the Android JNI bridge and failed because the host environment does not provide Android `jni.h`. This is expected for the Android-specific target and is not an Android NDK build. The portable test target succeeded independently.

## Not validated

- Android Gradle build/APK assembly and Android NDK compilation.
- Vulkan probe compilation or execution on Android hardware.
- AAudio stream creation or audio latency.
- Any x86-64 instruction translation or execution.
- PRX relocation, import resolution, module loading, or PS5 runtime services.
- Samsung device certification, performance, thermal behavior, or controller/audio testing.
- Commercial or homebrew PS5 game compatibility.

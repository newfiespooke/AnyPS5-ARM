# Samsung device certification matrix

No device is certified by this source package. Fill one row per exact device model and firmware build.

| Field | Evidence to capture |
|---|---|
| Model / product code | Settings > About tablet; `adb shell getprop ro.product.model` |
| Android build / API | `adb shell getprop ro.build.fingerprint`; API level |
| SoC / GPU | SoC model and Vulkan physical-device properties |
| ABI | `adb shell getprop ro.product.cpu.abilist` |
| RAM / storage | Total RAM, free app storage, peak process PSS |
| Vulkan | API version, extensions, features, formats, queue families, memory heaps |
| Audio | AAudio stream open result, sample rate, burst size, underruns and latency |
| Input | Touch, keyboard, mouse, USB gamepad, Bluetooth gamepad, DualSense if available |
| Display | Portrait/landscape, refresh rate, DeX, split-screen, external display |
| Thermals | 20-minute sustained workload, thermal status, throttling and frame-time trend |
| Lifecycle | Background/foreground, screen off/on, rotation, process recreation, low-memory kill |
| Result | Pass / fail / blocked, test build SHA, logs and tester/date |

## Required test gates

1. Install/uninstall and cold start without crash.
2. Portrait, landscape, split-screen and DeX layout checks.
3. Touch and controller navigation with disconnect/reconnect.
4. Vulkan instance/device enumeration and feature/extension inventory.
5. Audio API probe; later stream latency and underrun tests once implemented.
6. 20-minute thermal soak with repeatable workload and frame-time capture.
7. Lifecycle and memory-pressure tests.
8. Attach `adb logcat`, device report JSON, APK SHA-256 and test notes.

A device passes only the tested launcher/platform gates. This does not imply PS5 game compatibility.

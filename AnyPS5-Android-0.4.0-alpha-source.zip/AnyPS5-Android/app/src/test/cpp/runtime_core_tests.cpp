#include "runtime/elf_image.hpp"
#include "runtime/guest_cpu.hpp"
#include "runtime/guest_memory.hpp"
#include "runtime/service_registry.hpp"
#include "runtime/translation_backend.hpp"
#include "runtime/prx_module.hpp"

#include <elf.h>
#include <array>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

using namespace anyps5::runtime;

static void test_guest_memory() {
    GuestMemory memory;
    std::string error;
    assert(!memory.allocate(0, &error));
    assert(memory.allocate(4096, &error));
    const std::uint32_t expected = 0xA55A1234;
    assert(memory.write(memory.base_address() + 16, &expected, sizeof(expected)));
    std::uint32_t actual = 0;
    assert(memory.read(memory.base_address() + 16, &actual, sizeof(actual)));
    assert(actual == expected);
    assert(!memory.read(memory.base_address() + memory.size() - 1, &actual, sizeof(actual)));
}

static void test_backend_is_explicitly_unavailable() {
    UnavailableBackend backend;
    GuestCpuState state{};
    const auto result = backend.execute_block(state, 0x1000, 32);
    assert(result.status == BackendStatus::BackendNotImplemented);
    assert(state.rip == 0x1000);
    assert(result.detail.find("not implemented") != std::string::npos);
}

static void test_translation_backend_fails_closed() {
    std::string reason;
    auto backend = TranslationBackendFactory::create(&reason);
    assert(!backend);
    assert(reason.find("not integrated") != std::string::npos || reason.find("not running") != std::string::npos);
}

static void test_prx_inspection_rejects_invalid_input() {
    const std::uint8_t invalid[] = {0,1,2,3};
    const auto result = inspect_prx_module(invalid, sizeof(invalid), "sample.prx");
    assert(result.status == ModuleStatus::Rejected);
    assert(!result.reason.empty());
}

static void test_service_registry() {
    ServiceRegistry registry;
    registry.register_export(0x1234, {"libSceExample", "sceExampleInit", false});
    const auto* item = registry.find(0x1234);
    assert(item && item->name == "sceExampleInit" && !item->implemented);
    assert(registry.find(0x9999) == nullptr);
    assert(registry.describe(0x9999).find("unsupported") != std::string::npos);
}

static void test_elf_validation() {
    std::vector<std::uint8_t> image(sizeof(Elf64_Ehdr) + sizeof(Elf64_Phdr), 0);
    auto* header = reinterpret_cast<Elf64_Ehdr*>(image.data());
    std::memcpy(header->e_ident, ELFMAG, SELFMAG);
    header->e_ident[EI_CLASS] = ELFCLASS64;
    header->e_ident[EI_DATA] = ELFDATA2LSB;
    header->e_ident[EI_VERSION] = EV_CURRENT;
    header->e_type = ET_DYN;
    header->e_machine = EM_X86_64;
    header->e_version = EV_CURRENT;
    header->e_ehsize = sizeof(Elf64_Ehdr);
    header->e_phoff = sizeof(Elf64_Ehdr);
    header->e_phentsize = sizeof(Elf64_Phdr);
    header->e_phnum = 1;
    auto* phdr = reinterpret_cast<Elf64_Phdr*>(image.data() + sizeof(Elf64_Ehdr));
    phdr->p_type = PT_LOAD;
    phdr->p_offset = image.size();
    phdr->p_vaddr = 0x400000;
    phdr->p_filesz = 0;
    phdr->p_memsz = 4096;
    phdr->p_flags = PF_R | PF_X;
    phdr->p_align = 1;

    ElfImageInfo info{};
    std::string error;
    assert(inspect_x86_64_elf64(image.data(), image.size(), &info, &error));
    assert(info.machine == EM_X86_64);
    assert(info.load_segments.size() == 1);

    header->e_machine = EM_AARCH64;
    assert(!inspect_x86_64_elf64(image.data(), image.size(), &info, &error));
    assert(error.find("not x86-64") != std::string::npos);
}

int main() {
    test_guest_memory();
    test_backend_is_explicitly_unavailable();
    test_service_registry();
    test_translation_backend_fails_closed();
    test_prx_inspection_rejects_invalid_input();
    test_elf_validation();
    std::cout << "AnyPS5 runtime core tests passed\n";
    return 0;
}

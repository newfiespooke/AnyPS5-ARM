#include "translation_backend.hpp"

namespace anyps5::runtime {
BackendCapabilities TranslationBackendFactory::inspect_host() noexcept {
#if defined(__aarch64__)
    return {"unconfigured-arm64", true, false, false, false, false};
#else
    return {"unsupported-host", false, false, false, false, false};
#endif
}
std::unique_ptr<X64ToA64Backend> TranslationBackendFactory::create(std::string* reason) {
    const auto caps = inspect_host();
    if (reason) *reason = caps.arm64_host
        ? "ARM64 host detected, but no validated x86-64 decoder/AArch64 emitter/JIT backend is integrated"
        : "This build is not running on an ARM64 host";
    return nullptr; // fail closed until an audited DBT backend is integrated
}
} // namespace anyps5::runtime

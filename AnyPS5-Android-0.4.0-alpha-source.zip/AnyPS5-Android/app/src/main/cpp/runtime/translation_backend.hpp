#pragma once
#include "guest_cpu.hpp"
#include "guest_memory.hpp"
#include <cstdint>
#include <memory>
#include <string>

namespace anyps5::runtime {
struct BackendCapabilities {
    const char* name;
    bool arm64_host;
    bool x64_decoder;
    bool a64_emitter;
    bool jit_cache;
    bool signal_bridge;
};

// Selection boundary for a real DBT implementation. No backend is reported
// ready until its decoder, emitter, cache, and Android signal/TLS bridge exist.
class TranslationBackendFactory final {
public:
    static BackendCapabilities inspect_host() noexcept;
    static std::unique_ptr<X64ToA64Backend> create(std::string* reason);
};
} // namespace anyps5::runtime

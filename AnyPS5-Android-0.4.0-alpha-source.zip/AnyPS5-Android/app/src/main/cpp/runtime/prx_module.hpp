#pragma once
#include "elf_image.hpp"
#include <cstdint>
#include <string>
#include <vector>
namespace anyps5::runtime {
enum class ModuleStatus { Inspected, Rejected };
struct PrxModuleInfo { ModuleStatus status{ModuleStatus::Rejected}; ElfImageInfo elf{}; std::string module_name; std::string reason; };
// PRX files are treated as untrusted ELF containers. This performs metadata
// inspection only: no relocations, imports, constructors, or code execution.
PrxModuleInfo inspect_prx_module(const std::uint8_t* bytes, std::size_t size, const std::string& display_name);
} // namespace anyps5::runtime

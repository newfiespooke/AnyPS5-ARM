#include "prx_module.hpp"
namespace anyps5::runtime {
PrxModuleInfo inspect_prx_module(const std::uint8_t* bytes, std::size_t size, const std::string& display_name) {
    PrxModuleInfo out{}; out.module_name = display_name;
    if (!inspect_x86_64_elf64(bytes, size, &out.elf, &out.reason)) { out.status = ModuleStatus::Rejected; return out; }
    if (out.elf.type != 3 /* ET_DYN */) { out.status = ModuleStatus::Rejected; out.reason = "PRX-style modules must be ET_DYN shared objects"; return out; }
    out.status = ModuleStatus::Inspected; out.reason = "ELF64 x86-64 module metadata accepted; dynamic relocations, imports and PRX semantics are not implemented";
    return out;
}
} // namespace anyps5::runtime

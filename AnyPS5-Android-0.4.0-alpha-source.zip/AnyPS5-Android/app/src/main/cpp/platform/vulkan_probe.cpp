#include "vulkan_probe.hpp"
#include <vulkan/vulkan.h>
#include <sstream>
#include <vector>
namespace anyps5::platform {
std::string inspect_vulkan_capabilities() {
 VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO}; app.pApplicationName="AnyPS5 capability probe"; app.apiVersion=VK_API_VERSION_1_0;
 VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO}; ci.pApplicationInfo=&app; VkInstance instance=VK_NULL_HANDLE;
 VkResult r=vkCreateInstance(&ci,nullptr,&instance); if(r!=VK_SUCCESS) return "{\"available\":false,\"stage\":\"create_instance\",\"vkResult\":"+std::to_string(r)+"}";
 uint32_t n=0; r=vkEnumeratePhysicalDevices(instance,&n,nullptr); std::vector<VkPhysicalDevice> devs(n); if(r==VK_SUCCESS && n) r=vkEnumeratePhysicalDevices(instance,&n,devs.data());
 std::ostringstream o; o<<"{\"available\":"<<(r==VK_SUCCESS?"true":"false")<<",\"deviceCount\":"<<n<<",\"devices\":[";
 for(uint32_t i=0;i<n && r==VK_SUCCESS;i++){ VkPhysicalDeviceProperties p{}; vkGetPhysicalDeviceProperties(devs[i],&p); if(i)o<<','; o<<"{\"name\":\""<<p.deviceName<<"\",\"apiVersion\":\""<<VK_VERSION_MAJOR(p.apiVersion)<<'.'<<VK_VERSION_MINOR(p.apiVersion)<<'.'<<VK_VERSION_PATCH(p.apiVersion)<<"\",\"vendorId\":"<<p.vendorID<<",\"deviceId\":"<<p.deviceID<<"}"; }
 o<<"]}"; vkDestroyInstance(instance,nullptr); return o.str();
}
}

#pragma once
#include <cstdint>
#include <string>
namespace anyps5::platform {
struct AudioDeviceReport { bool aaudio_available{false}; int32_t sample_rate{0}; int32_t burst_frames{0}; std::string detail; };
// Reports Android low-latency audio API availability; it does not yet create
// a stream or mix guest audio.
AudioDeviceReport inspect_audio_backend();
}

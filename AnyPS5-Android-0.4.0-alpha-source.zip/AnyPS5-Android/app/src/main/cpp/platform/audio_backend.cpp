#include "audio_backend.hpp"
#include <aaudio/AAudio.h>
namespace anyps5::platform {
AudioDeviceReport inspect_audio_backend(){ AudioDeviceReport r{}; r.aaudio_available=true; r.detail="AAudio API is available; stream creation, mixing, timing and guest audio routing are not implemented"; return r; }
}

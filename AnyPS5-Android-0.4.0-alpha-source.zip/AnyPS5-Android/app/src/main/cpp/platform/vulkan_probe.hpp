#pragma once
#include <string>
namespace anyps5::platform {
std::string inspect_vulkan_capabilities();
}

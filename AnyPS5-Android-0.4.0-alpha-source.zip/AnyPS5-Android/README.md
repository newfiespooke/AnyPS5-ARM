# AnyPS5 Android Edition

**Version:** 0.3.0-alpha  
**Platform target:** Android ARM64 (`arm64-v8a`)  
**Project type:** Early-stage community port foundation  
**Status:** Android dashboard and native bridge scaffold; PS5 execution is not implemented.

AnyPS5 Android Edition is an experimental Android-focused porting effort based on the upstream [AnyPS5 project](https://github.com/boykopovar/AnyPS5). The goal is to bring the project's capabilities to ARM64 Android devices, including Samsung tablets, while providing a controller-first interface inspired by console dashboards and media-center applications.

> **Important:** This repository is not currently a working PS5 emulator or a complete PS5 game compatibility layer. The current alpha contains the Android application shell, a basic native JNI bridge scaffold, and engineering documentation for the work still required. It does not yet execute PS5 games.

## Project goals

- Provide a native Android application with a PS5-inspired, red-accented dashboard.
- Support touchscreen interaction and Android-compatible game controllers.
- Provide a responsive layout for phones and tablets, including portrait and landscape use.
- Establish an Android NDK / CMake / JNI foundation targeting `arm64-v8a`.
- Audit and port upstream AnyPS5 functionality where technically and legally possible.
- Develop a real x86-64 guest-to-ARM64 execution strategy before claiming game compatibility.
- Build, test, sign, and distribute Android packages once the implementation is ready.

## Current status

| Area | Current state |
|---|---|
| Android dashboard | Early implementation |
| PS5-inspired visual design | Early implementation |
| Touch interaction | Basic UI support |
| Controller navigation | Basic UI support; device testing required |
| Tablet-responsive layout | Initial support; device testing required |
| Android native bridge | JNI status and device-diagnostics scaffold |
| Android ABI target | `arm64-v8a` configured |
| PS5 x86-64 instruction translation | Not implemented |
| Guest CPU state, guest memory and metadata-only ELF64 x86-64 inspector | Initial scaffold; host tests pass |
| x86-64 to ARM64 instruction translator | Not implemented |
| PS5 guest ABI and runtime | Not implemented |
| PS5 PRX/system-library compatibility | Not implemented |
| Android Vulkan diagnostics | Loader and physical-device discovery scaffold |
| Android Vulkan graphics backend | Not implemented |
| PS5 game execution | Not implemented |
| Installable, device-tested APK | Not yet verified |

Features described as goals or roadmap items should not be interpreted as implemented functionality.

## Repository structure

The exact contents may evolve as the port progresses. Key areas include:

- `app/` — Android application source, resources, and build configuration.
- `app/src/main/cpp/` — Native C++ bridge, runtime contracts, ELF metadata inspector and CMake configuration.
- `app/src/test/cpp/` — Host-side native tests and an optional ELF parser fuzz harness.
- `scripts/` — Reproducible upstream checkout scripts pinned to reviewed commits.
- `docs/UPSTREAM-FEATURE-MAP.md` — Upstream feature inventory and Android port requirements.
- `docs/SAMSUNG-TABLET-TEST-PLAN.md` — Tablet layout, device capability, and performance validation plan.
- `PORTING-ROADMAP.md` — Staged engineering roadmap.
- `CHANGELOG.md` — Project changes by alpha version.
- `.github/workflows/` — Automated Android build workflow, where configured.

## Build requirements

For a local Android build, install:

- JDK 17
- Android SDK Platform 35
- Android SDK Build Tools 35.0.0
- Android NDK `27.2.12479018` (or the version pinned by the workflow)
- CMake 3.22.1
- Gradle 8.9 (the project currently does not include the Gradle wrapper)

The Android native build is configured for `arm64-v8a`. Other ABIs are not currently targeted.

### Build a debug APK

From the project root:

```bash
gradle --no-daemon :app:assembleDebug
```

On Windows:

```powershell
gradle --no-daemon :app:assembleDebug
```

If the build succeeds, the debug APK is normally created at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

To inspect whether the APK contains the ARM64 native bridge:

```bash
unzip -l app/build/outputs/apk/debug/app-debug.apk | grep 'lib/arm64-v8a/'
```

A successful APK build only verifies that the current Android application and native scaffold compile. It does **not** verify PS5 game execution.

## Installing the debug APK

Transfer the generated APK to an ARM64 Android device and open it to install. You may need to allow installation from the file manager or browser used to open the APK.

Alternatively, with Android Debug Bridge (ADB) enabled:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Only install APKs built from source you trust. A debug APK is for development and testing, not a production release.

## Samsung tablet support

Samsung tablets are an important target, but compatibility depends on the exact tablet model, Android version, chipset, GPU, memory, and available Vulkan features.

The project aims to support:

- Portrait and landscape layouts.
- Resizable app windows and split-screen use where Android permits.
- Touch controls and external game controllers.
- Keyboard and mouse input where supported.
- Samsung DeX as an optional windowing environment on compatible devices.
- Runtime detection of CPU, GPU, Vulkan, memory, display, and thermal capabilities.

No particular Samsung tablet has been certified yet. Record the exact model and firmware when reporting test results.

## Why ARM64 requires more than recompiling

The upstream PC project targets x86-64 desktop environments. PS5 executable code is also based on an x86-64 architecture. Android phones and tablets generally use ARM64 processors.

Changing the compiler target does not translate x86-64 game instructions into ARM64 instructions. A genuine port needs substantial additional components, including:

1. An x86-64 instruction decoder and ARM64 code generator, or a suitable dynamic binary translation engine. The first candidate is documented in `docs/architecture/TRANSLATOR-DECISION.md`.
2. Guest CPU state, including general-purpose registers, flags, floating-point and SIMD state.
3. Guest memory mapping, relocations, indirect branches, exceptions, threading, and TLS behavior.
4. Compatibility for the guest calling convention and PS5 application binary interface.
5. Android/Bionic adaptations for host operating-system services.
6. ARM64 implementations of required PS5-facing system and PRX library interfaces.
7. A graphics path using Android Vulkan, including shader translation and display/swapchain integration.
8. Audio, controller, storage, networking, and other required platform services.

These components are not present in the current alpha. See `docs/UPSTREAM-FEATURE-MAP.md` and `PORTING-ROADMAP.md` for the detailed breakdown.

## Native runtime foundation

The native core now contains a guest CPU-state contract, bounded guest-memory helper, metadata-only ELF64 x86-64 inspector, explicit NID registry and a fail-closed translation-backend interface. Host-side tests cover the core safety checks. These pieces are groundwork only: they do not load, relocate or execute PS5 binaries.

The upstream snapshot used for the initial audit is recorded in [UPSTREAM-PIN.md](docs/UPSTREAM-PIN.md). No upstream source or submodules have been vendored yet. A Box64 x86-64-to-ARM64 backend is the first candidate for a prototype, but its Android/Linux userspace boundary remains a major integration question.

See the [validation report](docs/VALIDATION-REPORT.md), [translator selection](docs/architecture/TRANSLATOR-DECISION.md), [execution-engine architecture](docs/architecture/EXECUTION-ENGINE.md), [Android platform integration](docs/architecture/ANDROID-PLATFORM.md), [upstream integration policy](docs/architecture/UPSTREAM-INTEGRATION-POLICY.md), and the [title compatibility report template](docs/architecture/COMPATIBILITY-REPORT-TEMPLATE.md).

Run native core tests on a host with CMake and a C++20 compiler:

```bash
cmake -S app/src/main/cpp -B build/native-tests -DANYPS5_BUILD_NATIVE_TESTS=ON
cmake --build build/native-tests --target anyps5_runtime_tests --parallel
ctest --test-dir build/native-tests --output-on-failure
```

## Performance and testing principles

The interface should remain responsive while native work is performed. As development continues:

- Keep file scanning, metadata extraction, shader compilation, and runtime work off the Android UI thread.
- Use appropriately sized and cached artwork rather than decoding large images during menu navigation.
- Avoid unnecessary continuous animations and expensive visual effects.
- Measure frame pacing and input latency on physical devices.
- Monitor memory pressure and Android thermal status during sustained workloads.
- Validate Vulkan capabilities at runtime instead of assuming all Android GPUs support the same features.

Performance targets are goals, not measured claims. Do not advertise a frame rate or compatibility level without reproducible device test results.

## Contributing

Contributions are welcome. Please:

1. Open an issue describing the feature, bug, or proposed change.
2. Check existing issues and the porting roadmap before starting duplicate work.
3. Keep changes focused and include tests or reproducible validation where possible.
4. Clearly label work as implemented, partial, experimental, or not yet tested.
5. Include device details for Android-specific reports: model, Android version, ABI, chipset/GPU, RAM, and relevant logs.
6. Preserve upstream and third-party license notices.
7. Do not submit copyrighted game files, PS5 firmware, cryptographic keys, or proprietary Sony system libraries.

For substantial changes, open a pull request against the project's designated contribution branch. Maintainers should review licensing, security, build reproducibility, and device compatibility before merging.

## Legal and licensing notes

AnyPS5 Android Edition is an independent community development effort. It is not affiliated with, endorsed by, or sponsored by Sony Interactive Entertainment or Samsung.

PlayStation and PS5 are trademarks of Sony Interactive Entertainment. Android is a trademark of Google LLC. Samsung and Samsung DeX are trademarks of Samsung Electronics.

The upstream AnyPS5 repository identifies its license as **GPL-2.0**. The candidate Box64 project is separately licensed under MIT; its notices must remain separate if it is integrated. Review the upstream license file and all dependency licenses before distributing modified binaries or source. Preserve required copyright and license notices and comply with the applicable source-distribution obligations.

Do not bundle proprietary firmware, encryption keys, copyrighted game content, or proprietary console libraries. Users are responsible for ensuring that any software and data they use are lawfully obtained and used.

## Roadmap

1. Stabilize the Android app shell and controller/touch navigation.
2. Build and validate the ARM64 native bridge on physical Android devices.
3. Vendor the pinned upstream source and audit submodules/licenses.
4. Prototype the pinned Box64 candidate in a controlled Android guest userspace.
5. Implement guest ABI, module loading, and required system-library interfaces.
6. Bring up Android Vulkan rendering, display, audio, storage, and input backends.
7. Test legally supplied homebrew and test programs before attempting broader compatibility.
8. Establish reproducible device compatibility reports and release processes.

## Links

- Upstream project: https://github.com/boykopovar/AnyPS5
- Android NDK documentation: https://developer.android.com/ndk
- Android Vulkan documentation: https://developer.android.com/games/develop/vulkan
- Android app signing: https://developer.android.com/studio/publish/app-signing

---

**Current release note:** `0.3.0-alpha` is an early source foundation. It is not a completed ARM64 port, and it does not currently run PS5 games.

## 0.4.0-alpha status update

This update adds a fail-closed translation-backend selection interface, metadata-only PRX-style ELF inspection, Android Vulkan and AAudio capability-probe source, and a Samsung device certification evidence matrix. It does not include a working x86-64-to-AArch64 translator, PRX loader, PS5 system-library implementation, Vulkan renderer, audio mixer, or device certification. See `docs/architecture/0.4.0-MILESTONE-STATUS.md` before interpreting any subsystem status.

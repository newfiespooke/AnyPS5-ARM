# Changelog

## 0.3.0-alpha - Runtime foundation

- Added explicit x86-64 guest CPU state and a fail-closed ARM64 translation-backend contract.
- Added bounded native memory backing with range-checked reads and writes.
- Added metadata-only ELF64 little-endian x86-64 image inspection.
- Added a PS5 NID/service export registry with explicit implementation status.
- Added JNI device diagnostics for ABI, Android API, CPU and Vulkan physical-device discovery.
- Added native core host tests and a CI test job.
- Pinned and documented the upstream AnyPS5 source snapshot and submodule inventory.
- Added runtime architecture, Android platform, compatibility-report and upstream integration docs.

Important: the x86-64 to AArch64 translator, PRX runtime, Vulkan renderer and PS5 game execution are still not implemented. No APK or Samsung device build has been verified in this environment.

## 0.2.0-alpha

- Added ARM64 NDK/CMake/JNI foundation.
- Added Samsung tablet responsive-layout groundwork and controller/touch UI scaffolding.
- Added upstream feature map, roadmap and Samsung device test plan.

## 0.4.0-alpha

- Added explicit ARM64 translation backend factory; still fails closed because no DBT implementation is integrated.
- Added metadata-only PRX-style ELF64 ET_DYN inspection.
- Added Vulkan physical-device probe source and AAudio capability-report boundary.
- Added Samsung device certification matrix and graphics/audio roadmap.
- Added host tests for backend selection and malformed PRX input.
- No PS5 code execution, Vulkan renderer, audio mixer, or certified Samsung device is claimed.

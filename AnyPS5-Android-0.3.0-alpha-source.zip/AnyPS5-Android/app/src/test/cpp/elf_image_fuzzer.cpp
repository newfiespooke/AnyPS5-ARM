#include "runtime/elf_image.hpp"

#include <cstddef>
#include <cstdint>
#include <string>

extern "C" int LLVMFuzzerTestOneInput(const std::uint8_t* data, std::size_t size) {
    anyps5::runtime::ElfImageInfo output{};
    std::string error;
    (void)anyps5::runtime::inspect_x86_64_elf64(data, size, &output, &error);
    return 0;
}

#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>

namespace anyps5::runtime {

struct ServiceExport {
    std::string library;
    std::string name;
    bool implemented{false};
};

class ServiceRegistry final {
public:
    void register_export(std::uint64_t nid, ServiceExport entry);
    const ServiceExport* find(std::uint64_t nid) const noexcept;
    std::string describe(std::uint64_t nid) const;
private:
    std::unordered_map<std::uint64_t, ServiceExport> exports_;
};

} // namespace anyps5::runtime

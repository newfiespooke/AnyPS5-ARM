#include "guest_cpu.hpp"

namespace anyps5::runtime {

TranslationResult UnavailableBackend::execute_block(GuestCpuState& state,
                                                      std::uint64_t guest_address,
                                                      std::uint32_t instruction_budget) {
    (void)instruction_budget;
    state.rip = guest_address;
    return {BackendStatus::BackendNotImplemented, guest_address,
            "x86-64 to AArch64 dynamic translator is not implemented; guest code was not executed"};
}

const char* backend_status_name(BackendStatus status) noexcept {
    switch (status) {
        case BackendStatus::Ready: return "ready";
        case BackendStatus::UnsupportedInstruction: return "unsupported_instruction";
        case BackendStatus::UnsupportedGuestFeature: return "unsupported_guest_feature";
        case BackendStatus::InvalidGuestState: return "invalid_guest_state";
        case BackendStatus::BackendNotImplemented: return "backend_not_implemented";
        case BackendStatus::InternalError: return "internal_error";
    }
    return "unknown";
}

} // namespace anyps5::runtime

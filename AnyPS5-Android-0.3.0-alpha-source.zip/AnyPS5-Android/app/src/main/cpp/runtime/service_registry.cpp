#include "service_registry.hpp"
#include <sstream>

namespace anyps5::runtime {

void ServiceRegistry::register_export(std::uint64_t nid, ServiceExport entry) {
    exports_.insert_or_assign(nid, std::move(entry));
}

const ServiceExport* ServiceRegistry::find(std::uint64_t nid) const noexcept {
    const auto it = exports_.find(nid);
    return it == exports_.end() ? nullptr : &it->second;
}

std::string ServiceRegistry::describe(std::uint64_t nid) const {
    const auto* entry = find(nid);
    if (!entry) return "unsupported NID: no export registered";
    std::ostringstream out;
    out << entry->library << "!" << entry->name
        << (entry->implemented ? " [implemented]" : " [declared, not implemented]");
    return out.str();
}

} // namespace anyps5::runtime

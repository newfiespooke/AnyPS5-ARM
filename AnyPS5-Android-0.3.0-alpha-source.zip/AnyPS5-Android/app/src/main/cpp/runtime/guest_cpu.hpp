#pragma once

#include <array>
#include <cstdint>
#include <string>

namespace anyps5::runtime {

// PS5 user-mode code is x86-64. This state models the architectural guest
// context; it is not the host AArch64 register file.
struct alignas(16) GuestCpuState {
    std::array<std::uint64_t, 16> gpr{}; // RAX..R15, project-defined order
    std::uint64_t rip{0};
    std::uint64_t rflags{0x2};
    std::array<std::array<std::uint64_t, 2>, 16> xmm{};
    std::uint64_t fs_base{0};
    std::uint64_t gs_base{0};
};

enum class BackendStatus {
    Ready,
    UnsupportedInstruction,
    UnsupportedGuestFeature,
    InvalidGuestState,
    BackendNotImplemented,
    InternalError
};

struct TranslationResult {
    BackendStatus status{BackendStatus::BackendNotImplemented};
    std::uint64_t guest_rip{0};
    std::string detail;
};

// Contract for a future DBT backend. A backend must never silently execute
// an instruction it has not validated and translated.
class X64ToA64Backend {
public:
    virtual ~X64ToA64Backend() = default;
    virtual TranslationResult execute_block(GuestCpuState& state,
                                            std::uint64_t guest_address,
                                            std::uint32_t instruction_budget) = 0;
};

class UnavailableBackend final : public X64ToA64Backend {
public:
    TranslationResult execute_block(GuestCpuState& state,
                                     std::uint64_t guest_address,
                                     std::uint32_t instruction_budget) override;
};

const char* backend_status_name(BackendStatus status) noexcept;

} // namespace anyps5::runtime

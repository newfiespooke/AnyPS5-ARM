#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace anyps5::runtime {

struct ElfSegmentInfo {
    std::uint64_t file_offset{0};
    std::uint64_t virtual_address{0};
    std::uint64_t file_size{0};
    std::uint64_t memory_size{0};
    std::uint32_t flags{0};
    std::uint64_t alignment{0};
};

struct ElfImageInfo {
    std::uint16_t type{0};
    std::uint16_t machine{0};
    std::uint64_t entry{0};
    std::vector<ElfSegmentInfo> load_segments;
};

// Validates a little-endian ELF64 x86-64 image and extracts PT_LOAD metadata.
// It intentionally does not map or execute untrusted code.
bool inspect_x86_64_elf64(const std::uint8_t* bytes, std::size_t size,
                          ElfImageInfo* output, std::string* error);

} // namespace anyps5::runtime

#include "guest_memory.hpp"

#include <cstring>
#include <limits>
#include <sys/mman.h>
#include <unistd.h>

namespace anyps5::runtime {

GuestMemory::~GuestMemory() { reset(); }

GuestMemory::GuestMemory(GuestMemory&& other) noexcept
    : data_(other.data_), size_(other.size_) {
    other.data_ = nullptr;
    other.size_ = 0;
}

GuestMemory& GuestMemory::operator=(GuestMemory&& other) noexcept {
    if (this != &other) {
        reset();
        data_ = other.data_;
        size_ = other.size_;
        other.data_ = nullptr;
        other.size_ = 0;
    }
    return *this;
}

bool GuestMemory::allocate(std::size_t bytes, std::string* error) {
    reset();
    if (bytes == 0) {
        if (error) *error = "memory allocation size must be non-zero";
        return false;
    }
    const long page = sysconf(_SC_PAGESIZE);
    if (page <= 0) {
        if (error) *error = "unable to determine host page size";
        return false;
    }
    const auto page_size = static_cast<std::size_t>(page);
    if (bytes > std::numeric_limits<std::size_t>::max() - (page_size - 1)) {
        if (error) *error = "memory allocation size overflow";
        return false;
    }
    const std::size_t rounded = ((bytes + page_size - 1) / page_size) * page_size;
    void* mapping = mmap(nullptr, rounded, PROT_READ | PROT_WRITE,
                         MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mapping == MAP_FAILED) {
        if (error) *error = "mmap failed while allocating guest memory";
        return false;
    }
    data_ = mapping;
    size_ = rounded;
    return true;
}

void GuestMemory::reset() noexcept {
    if (data_) munmap(data_, size_);
    data_ = nullptr;
    size_ = 0;
}

bool GuestMemory::contains(std::uint64_t address, std::size_t bytes) const noexcept {
    if (!data_ || address < base_address()) return false;
    const std::uint64_t offset = address - base_address();
    return offset <= size_ && bytes <= size_ - static_cast<std::size_t>(offset);
}

bool GuestMemory::read(std::uint64_t address, void* destination, std::size_t bytes) const noexcept {
    if ((!destination && bytes != 0) || !contains(address, bytes)) return false;
    if (bytes) std::memcpy(destination, reinterpret_cast<const void*>(address), bytes);
    return true;
}

bool GuestMemory::write(std::uint64_t address, const void* source, std::size_t bytes) noexcept {
    if ((!source && bytes != 0) || !contains(address, bytes)) return false;
    if (bytes) std::memcpy(reinterpret_cast<void*>(address), source, bytes);
    return true;
}

std::uint64_t GuestMemory::base_address() const noexcept {
    return reinterpret_cast<std::uint64_t>(data_);
}

std::size_t GuestMemory::size() const noexcept { return size_; }

} // namespace anyps5::runtime

#pragma once

#include <cstddef>
#include <cstdint>
#include <string>

namespace anyps5::runtime {

// Initial backing-region helper only. Addresses passed to this class are host
// virtual addresses returned by base_address(), not PS5 guest virtual addresses.
class GuestMemory final {
public:
    GuestMemory() = default;
    ~GuestMemory();
    GuestMemory(const GuestMemory&) = delete;
    GuestMemory& operator=(const GuestMemory&) = delete;
    GuestMemory(GuestMemory&& other) noexcept;
    GuestMemory& operator=(GuestMemory&& other) noexcept;

    bool allocate(std::size_t bytes, std::string* error = nullptr);
    void reset() noexcept;
    bool contains(std::uint64_t guest_address, std::size_t bytes) const noexcept;
    bool read(std::uint64_t guest_address, void* destination, std::size_t bytes) const noexcept;
    bool write(std::uint64_t guest_address, const void* source, std::size_t bytes) noexcept;
    std::uint64_t base_address() const noexcept;
    std::size_t size() const noexcept;

private:
    void* data_{nullptr};
    std::size_t size_{0};
};

} // namespace anyps5::runtime

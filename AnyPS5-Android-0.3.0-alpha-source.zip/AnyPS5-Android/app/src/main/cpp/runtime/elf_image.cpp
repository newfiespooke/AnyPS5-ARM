#include "elf_image.hpp"

#include <elf.h>
#include <cstring>
#include <limits>

namespace anyps5::runtime {
namespace {

template <typename T>
bool read_object(const std::uint8_t* bytes, std::size_t size, std::uint64_t offset, T* out) {
    if (!bytes || !out || offset > size || sizeof(T) > size - static_cast<std::size_t>(offset)) return false;
    std::memcpy(out, bytes + offset, sizeof(T));
    return true;
}

bool range_valid(std::uint64_t offset, std::uint64_t length, std::size_t total) {
    return offset <= total && length <= static_cast<std::uint64_t>(total) - offset;
}

void fail(std::string* error, const char* message) { if (error) *error = message; }

} // namespace

bool inspect_x86_64_elf64(const std::uint8_t* bytes, std::size_t size,
                          ElfImageInfo* output, std::string* error) {
    if (!bytes || !output) { fail(error, "null ELF input or output"); return false; }
    Elf64_Ehdr header{};
    if (!read_object(bytes, size, 0, &header)) { fail(error, "truncated ELF header"); return false; }
    if (std::memcmp(header.e_ident, ELFMAG, SELFMAG) != 0) { fail(error, "invalid ELF magic"); return false; }
    if (header.e_ident[EI_CLASS] != ELFCLASS64 || header.e_ident[EI_DATA] != ELFDATA2LSB) {
        fail(error, "only little-endian ELF64 images are supported"); return false;
    }
    if (header.e_ident[EI_VERSION] != EV_CURRENT || header.e_version != EV_CURRENT) {
        fail(error, "unsupported ELF version"); return false;
    }
    if (header.e_machine != EM_X86_64) { fail(error, "guest ELF machine is not x86-64"); return false; }
    if (header.e_type != ET_EXEC && header.e_type != ET_DYN) {
        fail(error, "only ET_EXEC and ET_DYN ELF images are accepted"); return false;
    }
    if (header.e_ehsize < sizeof(Elf64_Ehdr) || header.e_phentsize < sizeof(Elf64_Phdr)) {
        fail(error, "invalid ELF header or program-header entry size"); return false;
    }
    if (header.e_phnum == PN_XNUM) { fail(error, "extended ELF program-header counts are not supported"); return false; }
    const std::uint64_t table_bytes = static_cast<std::uint64_t>(header.e_phentsize) * header.e_phnum;
    if (!range_valid(header.e_phoff, table_bytes, size)) { fail(error, "program-header table is outside the file"); return false; }

    ElfImageInfo parsed{};
    parsed.type = header.e_type;
    parsed.machine = header.e_machine;
    parsed.entry = header.e_entry;
    for (std::uint16_t i = 0; i < header.e_phnum; ++i) {
        const std::uint64_t offset = header.e_phoff + static_cast<std::uint64_t>(i) * header.e_phentsize;
        Elf64_Phdr phdr{};
        if (!read_object(bytes, size, offset, &phdr)) { fail(error, "truncated program header"); return false; }
        if (phdr.p_type != PT_LOAD) continue;
        if (phdr.p_filesz > phdr.p_memsz || !range_valid(phdr.p_offset, phdr.p_filesz, size)) {
            fail(error, "invalid PT_LOAD segment bounds"); return false;
        }
        if (phdr.p_align > 1 && (phdr.p_align & (phdr.p_align - 1)) != 0) {
            fail(error, "PT_LOAD alignment is not a power of two"); return false;
        }
        if (phdr.p_align > 1 && (phdr.p_offset % phdr.p_align) != (phdr.p_vaddr % phdr.p_align)) {
            fail(error, "PT_LOAD file offset and virtual address are not alignment-congruent"); return false;
        }
        if (phdr.p_vaddr > std::numeric_limits<std::uint64_t>::max() - phdr.p_memsz) {
            fail(error, "PT_LOAD virtual-address range overflows"); return false;
        }
        parsed.load_segments.push_back({phdr.p_offset, phdr.p_vaddr, phdr.p_filesz,
                                        phdr.p_memsz, phdr.p_flags, phdr.p_align});
    }
    if (parsed.load_segments.empty()) { fail(error, "ELF image has no loadable segments"); return false; }
    *output = std::move(parsed);
    if (error) error->clear();
    return true;
}

} // namespace anyps5::runtime

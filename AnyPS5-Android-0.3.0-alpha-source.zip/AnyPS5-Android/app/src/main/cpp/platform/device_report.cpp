#include <jni.h>
#include <android/api-level.h>
#include <vulkan/vulkan.h>

#include <dlfcn.h>
#include <sys/auxv.h>
#include <unistd.h>

#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

namespace {

std::string json_escape(const std::string& value) {
    std::string out;
    for (const unsigned char c : value) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default: if (c >= 0x20) out += static_cast<char>(c); break;
        }
    }
    return out;
}

std::string vulkan_report() {
    void* library = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
    if (!library) return "{\"available\":false,\"reason\":\"libvulkan.so unavailable\"}";

    using EnumerateVersion = VkResult (*)(std::uint32_t*);
    using CreateInstance = VkResult (*)(const VkInstanceCreateInfo*, const VkAllocationCallbacks*, VkInstance*);
    using EnumeratePhysical = VkResult (*)(VkInstance, std::uint32_t*, VkPhysicalDevice*);
    using GetProperties = void (*)(VkPhysicalDevice, VkPhysicalDeviceProperties*);
    using DestroyInstance = void (*)(VkInstance, const VkAllocationCallbacks*);

    auto enumerate_version = reinterpret_cast<EnumerateVersion>(dlsym(library, "vkEnumerateInstanceVersion"));
    auto create_instance = reinterpret_cast<CreateInstance>(dlsym(library, "vkCreateInstance"));
    auto enumerate_physical = reinterpret_cast<EnumeratePhysical>(dlsym(library, "vkEnumeratePhysicalDevices"));
    auto get_properties = reinterpret_cast<GetProperties>(dlsym(library, "vkGetPhysicalDeviceProperties"));
    auto destroy_instance = reinterpret_cast<DestroyInstance>(dlsym(library, "vkDestroyInstance"));

    std::uint32_t version = VK_API_VERSION_1_0;
    if (enumerate_version) (void)enumerate_version(&version);
    if (!create_instance || !enumerate_physical || !get_properties || !destroy_instance) {
        dlclose(library);
        return "{\"available\":false,\"reason\":\"Vulkan entry points incomplete\"}";
    }

    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "AnyPS5 Android diagnostics";
    app.apiVersion = version < VK_API_VERSION_1_0 ? VK_API_VERSION_1_0 : version;
    VkInstanceCreateInfo create{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    create.pApplicationInfo = &app;
    VkInstance instance = VK_NULL_HANDLE;
    if (create_instance(&create, nullptr, &instance) != VK_SUCCESS) {
        dlclose(library);
        return "{\"available\":false,\"reason\":\"vkCreateInstance failed\"}";
    }

    std::uint32_t count = 0;
    VkResult result = enumerate_physical(instance, &count, nullptr);
    std::vector<VkPhysicalDevice> devices(count);
    if (result == VK_SUCCESS && count > 0) result = enumerate_physical(instance, &count, devices.data());

    std::ostringstream out;
    out << "{\"available\":true,\"apiVersion\":\"" << VK_VERSION_MAJOR(version) << "."
        << VK_VERSION_MINOR(version) << "." << VK_VERSION_PATCH(version) << "\",\"devices\":[";
    bool first = true;
    if (result == VK_SUCCESS) {
        for (std::uint32_t i = 0; i < count; ++i) {
            VkPhysicalDeviceProperties properties{};
            get_properties(devices[i], &properties);
            if (!first) out << ',';
            first = false;
            out << "{\"name\":\"" << json_escape(properties.deviceName)
                << "\",\"vendorId\":" << properties.vendorID
                << ",\"deviceId\":" << properties.deviceID
                << ",\"apiVersion\":\"" << VK_VERSION_MAJOR(properties.apiVersion) << "."
                << VK_VERSION_MINOR(properties.apiVersion) << "."
                << VK_VERSION_PATCH(properties.apiVersion) << "\"}";
        }
    }
    out << "]}";
    destroy_instance(instance, nullptr);
    dlclose(library);
    return out.str();
}

std::string make_device_report() {
#if defined(__aarch64__)
    const char* abi = "arm64-v8a";
#else
    const char* abi = "non-arm64-build";
#endif
    const long page_size = sysconf(_SC_PAGESIZE);
    const unsigned long hwcap = getauxval(AT_HWCAP);
    std::ostringstream out;
    out << "{\"app\":\"AnyPS5 Android\",\"runtimeStatus\":\"scaffold_only\","
        << "\"abi\":\"" << abi << "\",\"androidApi\":" << android_get_device_api_level()
        << ",\"cpuCount\":" << sysconf(_SC_NPROCESSORS_ONLN)
        << ",\"pageSize\":" << page_size
        << ",\"hwcap\":" << hwcap
        << ",\"vulkan\":" << vulkan_report()
        << ",\"notes\":[\"Device capability probe only; it does not imply game compatibility.\","
        << "\"x86-64 translation backend is not implemented.\"]}";
    return out.str();
}

} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_com_anyps5_android_NativeBridge_nativeGetDeviceReport(JNIEnv* env, jobject) {
    const std::string report = make_device_report();
    return env->NewStringUTF(report.c_str());
}

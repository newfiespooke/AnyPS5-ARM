#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${ROOT}/upstream/AnyPS5"
REPO="https://github.com/boykopovar/AnyPS5.git"
COMMIT="f0228ed9ecb997f5b2839e04398994b3ebc82275"

if [[ -e "${DEST}" ]]; then
  echo "Refusing to overwrite existing upstream checkout: ${DEST}" >&2
  exit 2
fi
mkdir -p "$(dirname "${DEST}")"
git clone "${REPO}" "${DEST}"
git -C "${DEST}" checkout --detach "${COMMIT}"
git -C "${DEST}" submodule sync --recursive
git -C "${DEST}" submodule update --init --recursive

actual="$(git -C "${DEST}" rev-parse HEAD)"
if [[ "${actual}" != "${COMMIT}" ]]; then
  echo "Upstream checkout mismatch: expected ${COMMIT}, got ${actual}" >&2
  exit 3
fi
printf 'Checked out AnyPS5 %s with recursive submodules.\n' "${actual}"

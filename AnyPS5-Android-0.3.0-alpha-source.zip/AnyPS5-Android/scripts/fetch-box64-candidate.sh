#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="${ROOT}/upstream/box64-candidate"
REPO="https://github.com/ptitSeb/box64.git"
COMMIT="c8ad5c3782ca4d2d3fff662bf30474b849a2d12b"

if [[ -e "${DEST}" ]]; then
  echo "Refusing to overwrite existing Box64 checkout: ${DEST}" >&2
  exit 2
fi
mkdir -p "$(dirname "${DEST}")"
git clone "${REPO}" "${DEST}"
git -C "${DEST}" checkout --detach "${COMMIT}"
actual="$(git -C "${DEST}" rev-parse HEAD)"
if [[ "${actual}" != "${COMMIT}" ]]; then
  echo "Box64 checkout mismatch: expected ${COMMIT}, got ${actual}" >&2
  exit 3
fi
printf 'Checked out Box64 candidate %s. Review docs/architecture/TRANSLATOR-DECISION.md before integrating.\n' "${actual}"

# AnyPS5 Android ARM64 port roadmap

## Phase 0 — Android shell (current alpha)
Native Compose dashboard, touch/controller navigation, SAF import, red adaptive icon, tablet-responsive page insets, and an NDK/JNI ARM64 bridge with device diagnostics. This is not a PS5 execution runtime.

## Phase 1 — Build and device capability foundation
Status: **partially implemented; Android build and physical-device verification pending**.
- [x] Build configuration targets only `arm64-v8a` with Android NDK/CMake.
- [x] Add JNI device report for ABI, API level, online CPU count, page size, raw HWCAP and Vulkan loader/physical-device discovery.
- [x] Add native core host tests to CI.
- [ ] Extend Vulkan query to the complete extension/feature matrix, memory budget, display modes and thermal status.
- [ ] Add live controller inventory and Samsung tablet portrait/landscape, split-screen and DeX device test results.
- [ ] Make all future native work asynchronous and preserve UI responsiveness.

## Phase 1A — Runtime safety and interfaces
Status: **scaffolded and host-tested**.
- [x] Define x86-64 guest CPU state, including GPR, RIP, RFLAGS, XMM and FS/GS base.
- [x] Add bounded guest-memory mapping and range-checked read/write operations.
- [x] Add metadata-only ELF64 little-endian x86-64 `ET_EXEC` / `ET_DYN` inspector.
- [x] Add explicit NID/export registry and fail-closed translator interface.
- [x] Add host unit tests for memory bounds, ELF validation, service lookup and unsupported-backend behavior.
- [x] Add an optional libFuzzer harness for ELF metadata parsing.
- [ ] Run sustained fuzzing, add archive-parser coverage, sanitizers and hardened loading tests.
- [ ] Implement a real guest address space, permissions, relocations and loader only after security review.

## Phase 2 — Upstream source integration audit
Status: **repository snapshot pinned and structure inspected; source not yet vendored**.
- [x] Pin an upstream AnyPS5 commit and record the submodule inventory in [UPSTREAM-PIN.md](docs/UPSTREAM-PIN.md).
- [ ] Recursively initialize submodules at their exact recorded SHAs.
- Preserve GPL-2.0 and third-party licenses.
- Identify architecture-neutral relinker components and isolate x86-64-only code.
- Create an Android/Bionic portability layer; do not assume glibc compatibility.
- Keep upstream changes in a clean integration branch and document local patches.

## Phase 3 — ARM64 execution strategy
Status: **translator candidate selected for prototyping; no instruction translator is integrated yet**.
- [x] Compare available ARM64 x86-64 DBT candidates and record Box64 as the first prototype candidate in [TRANSLATOR-DECISION.md](docs/architecture/TRANSLATOR-DECISION.md).
- [ ] Build and validate the pinned Box64 candidate in a controlled guest userspace.
- Select and prototype x86-64 static translation, dynamic binary translation, or a hybrid.
- Implement guest register/flags and SIMD state, instruction decoding, control flow, relocations, indirect branches and code cache.
- Define exception, signal, TLS, atomics, memory mapping and unwind behavior.
- Build differential instruction tests against a trusted x86-64 reference.
- Do not claim general game compatibility until test coverage demonstrates it.

## Phase 4 — Android PRX/runtime
- Port NID resolution, guest module loading and lifecycle.
- Port supported PRX exports to ARM64 and Android/Bionic.
- Preserve guest ABI structures, error codes, thread behavior and memory semantics.
- Keep unknown exports explicitly unsupported and logged.

## Phase 5 — Graphics, display, audio and input
Status: **Vulkan loader/device discovery only; no renderer or media backend exists**.
- Shader recompiler to SPIR-V and Android Vulkan pipeline.
- Android Surface/swapchain, VideoOut timing, refresh changes and lifecycle.
- SDL/Android gamepad hotplug, analog axes/triggers, touchpad/touch overlay, keyboard/mouse and per-title profiles.
- Low-latency audio output, audio focus and codec paths.
- File/archive/network/USB service adapters as upstream capabilities require.

## Phase 6 — Controlled title bring-up
- Homebrew/test binaries first.
- One title per reproducible report: exact build, device, Vulkan capabilities, logs, patches, compatibility status and known gaps.
- Fuzz executable parsing and translation; sanitizer-test native code.
- Thermal soak, memory-pressure and sustained frame-time testing on Samsung tablets.

## Phase 7 — Release
- CI builds a signed debug APK for testers and a release APK/AAB only after all required native modules and license notices are included.
- Release notes distinguish implemented, partial, unsupported and untested features.

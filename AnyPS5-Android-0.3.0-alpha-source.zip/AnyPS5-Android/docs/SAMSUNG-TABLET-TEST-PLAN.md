# Samsung Android tablet validation plan

## Responsive UI checks
- Portrait and landscape at compact, medium and expanded widths.
- Split-screen resizing and freeform/resizable windows where supported.
- DeX/keyboard/mouse usage where supported by the device.
- Touch targets, edge gestures, system bars, display cutouts and external display.
- D-pad/focus navigation with controller connected and disconnected.

## Device capability capture
Record the exact model/product, Android build, SoC/GPU, ABI, RAM class, Vulkan API version, required extensions/features, memory budget, display refresh rates and thermal state. Do not infer GPU capability from model marketing names.

## Performance gates
- Measure UI frame pacing with Macrobenchmark/JankStats.
- Measure native runtime CPU/GPU frame times independently.
- Capture cold start, library navigation, shader-cache warmup, memory pressure and 20-minute thermal soak.
- Set per-device graphics presets based on measured Vulkan capabilities and memory budget.
- No "smooth" or FPS claim until the device test report is attached.

## Minimum matrix
1. Samsung tablet: primary target.
2. Samsung tablet with a different GPU/SoC family: portability check.
3. Non-Samsung ARM64 Android device: vendor-neutral check.
4. Android emulator: UI and lifecycle checks only, not GPU/game compatibility certification.

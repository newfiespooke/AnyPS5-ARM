# AnyPS5 Android title compatibility report

- Title / homebrew project:
- Binary SHA-256:
- Binary format and architecture:
- AnyPS5 Android commit:
- Upstream AnyPS5 commit:
- Device model / SoC:
- Android version / API:
- Vulkan device / driver:
- Display mode:
- Input device:

## Result

- Status: Not tested | Boots | Intro | In-game | Playable | Unsupported
- Reproduction steps:
- Expected result:
- Actual result:
- Logs / crash signature:
- Performance: frame-time p50 / p95 / p99, memory peak, thermal state
- Known issues:
- Implemented guest instructions / PRX exports used:
- Unsupported instructions / NIDs / syscalls encountered:

Do not publish a compatibility label without a reproducible binary hash, device details and test evidence.

# x86-64 to ARM64 translator selection

## Current decision

**Prototype Box64 as the first execution backend candidate, but do not treat it as integrated or PS5-compatible.** Keep the `X64ToA64Backend` interface independent so a custom backend remains possible.

Candidate snapshot reviewed: [ptitSeb/box64 `c8ad5c3782ca4d2d3fff662bf30474b849a2d12b`](https://github.com/ptitSeb/box64/commit/c8ad5c3782ca4d2d3fff662bf30474b849a2d12b). Repository license metadata: MIT. Re-check the license and all notices at the pinned revision before vendoring.

## Why Box64 is the first candidate

- It is a mature x86-64 Linux userspace emulator with an AArch64 dynamic recompiler.
- Its project has Android/Termux-specific build paths and documents ARM64 DynaRec.
- Its feature/configuration model includes the x86 extensions AnyPS5 may emit, but the exact generated instruction corpus still needs tests.

## Critical integration gap

Box64 is a **Linux userspace** emulator, not a drop-in Android NativeActivity runtime. Its own compile guide describes native Termux support as experimental and says it will not run Linux binaries in that mode; it documents a chroot/PRoot-style Linux environment as the practical path. FEX is also aimed at Linux-on-Linux rather than Android as a direct host runtime, although its core can potentially be reused by other projects.

Therefore the prototype must answer these questions before selecting it for production:

1. Can the AnyPS5 relinker emit a Linux x86-64 executable whose required system ABI can be supplied by a controlled guest rootfs?
2. Can the app package and launch the Box64 runtime plus a minimal, redistributable guest userspace without requiring root or system-wide `binfmt_misc` registration?
3. Can the generated executable's AVX2/FMA/BMI2 and other required instructions be handled correctly on the target ARM64 devices?
4. Can Box64's guest syscall, signal, memory and thread behavior coexist with the PS5 PRX compatibility layer?
5. Can Vulkan calls be forwarded to the Android GPU stack with a stable guest/host library boundary?

If those checks fail, evaluate using FEXCore as an embeddable translator core or building a custom DBT. Neither alternative is already integrated.

## Prototype acceptance tests

- Build the pinned Box64 revision for a reproducible ARM64 Android/Termux or Linux guest environment.
- Run a tiny original x86-64 ELF fixture that exercises integer, SSE, AVX2, FMA, BMI2, atomics, TLS, signals and threads.
- Run the AnyPS5-produced ELF with a controlled minimal guest rootfs.
- Record syscalls, loaded guest libraries, translated CPU features, memory usage, frame-time overhead and failures.
- Verify that unsupported instructions and syscalls fail with actionable logs.
- Do not mark the AnyPS5 translator milestone complete until these tests pass on real target hardware.

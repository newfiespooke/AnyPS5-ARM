# Android platform integration

## Device diagnostics

The JNI bridge reports the build ABI, Android API level, online CPU count, host page size, raw HWCAP value, and Vulkan loader/physical-device information when available. This is a capability inventory, not a performance guarantee or a compatibility verdict.

The Vulkan probe dynamically resolves the loader entry points and enumerates physical devices. It does not yet query the full extension/feature matrix, create a rendering device, compile shaders, or present frames.

## Android boundaries still required

- SAF URI permission persistence, content streaming and archive extraction limits.
- Guest file-system namespace and explicit per-title storage permissions.
- Android thread priorities, lifecycle cancellation and background-work limits.
- GameController/Joystick event normalization, hotplug and per-title mappings.
- AudioTrack/AAudio latency measurements and audio-focus handling.
- Surface lifecycle, Vulkan swapchain recreation and thermal/memory-pressure response.
- Samsung DeX, multi-window, rotation and long-duration thermal validation on physical devices.

## Security baseline

Imported executables are untrusted. Do not execute them in-process until guest memory isolation, parser fuzzing, syscall mediation, resource limits and crash containment are in place. The current ELF parser is metadata-only.

# Upstream integration and licensing policy

1. Pin the exact upstream AnyPS5 commit before importing source. Record the URL, commit hash, retrieval date and submodule revisions.
2. Read the root license and every vendored dependency license. Preserve copyright notices and source headers. Do not assume every dependency uses the same license.
3. Keep upstream code in a dedicated subtree or clearly tracked integration branch. Keep Android/Bionic changes as small, reviewable patches.
4. Do not copy code from unrelated emulators or translation projects without verifying license compatibility and attribution obligations.
5. Maintain `THIRD_PARTY_NOTICES.md` with component, upstream URL, pinned revision, license, local modifications and required notices.
6. Never commit proprietary SDK files, firmware, console keys, copyrighted game binaries, private credentials or signing keystores.
7. Keep homebrew test fixtures either original or explicitly licensed for redistribution. Store hashes and download provenance for external test inputs rather than bundling them.

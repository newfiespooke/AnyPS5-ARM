# Execution engine architecture (engineering scaffold)

## Current implementation status

This directory establishes contracts and safety boundaries. It is **not** an x86-64 to AArch64 translator and does not execute PS5 code.

Implemented and host-tested:
- `GuestCpuState`: explicit x86-64 guest GPR, RIP, RFLAGS, XMM and FS/GS base storage.
- `GuestMemory`: bounded host backing mapping with overflow-safe allocation and read/write checks. Its addresses are host pointers, not a PS5 guest virtual-address space.
- `inspect_x86_64_elf64`: validates ELF64 little-endian x86-64 headers and PT_LOAD metadata without mapping or executing the file.
- `ServiceRegistry`: explicit NID/export registry that distinguishes declarations from implemented exports.
- `UnavailableBackend`: fails closed with `backend_not_implemented` rather than running guest code.

Not implemented:
- x86-64 decoder, instruction semantics, AArch64 code emitter, code cache or DBT block linker.
- guest virtual-address map, relocations, TLS, signal/exception delivery or syscall ABI.
- PRX loader, NID database, PS5 SDK library implementations or game execution.
- shader translation, Vulkan rendering, audio/video-out or full controller mapping.

## Required DBT layers

1. **Decode**: length-safe x86-64 decoding with prefixes, ModRM/SIB, immediates, RIP-relative addressing and explicit invalid/unsupported states.
2. **Architectural semantics**: integer flags, partial-register writes, x87/SSE/AVX state, atomics, fences, exceptions and privileged-instruction rejection.
3. **AArch64 lowering**: verified instruction templates, ABI-preserving helper calls, condition-code materialization and SIMD lowering.
4. **Block management**: guest-PC keyed translation cache, invalidation, indirect-branch dispatch, relocation and instruction-budget accounting.
5. **Runtime integration**: guest address space, page permissions, signal/TLS/thread model, futex/atomics, syscall and PRX boundaries.
6. **Validation**: differential tests against a real x86-64 reference, randomized decoder tests, corpus fuzzing, sanitizer runs and reproducible device benchmarks.

## Fail-closed rules

- Unknown instructions, unsupported CPU features, unresolved NIDs and unsupported syscalls must stop with structured diagnostics.
- Never reinterpret guest pointers as host pointers without an explicit guest-memory translation.
- Never mark a PRX export implemented merely because its NID is known.
- Never load or execute imported files during metadata inspection.
- A title is not marked compatible based only on a successful ELF parse or dashboard import.

## ELF parser boundary

The parser currently accepts ELF64 little-endian `ET_EXEC` and `ET_DYN` with `EM_X86_64`, checks header/table/segment bounds, and returns load segment metadata. It does not apply relocations, map segments, validate every dynamic-table structure, or verify signatures. Treat input as untrusted and keep parser fuzzing in CI before expanding it.

# Upstream AnyPS5 feature map for Android ARM64

Reference upstream: https://github.com/boykopovar/AnyPS5
Audited snapshot: [f0228ed9ecb997f5b2839e04398994b3ebc82275](https://github.com/boykopovar/AnyPS5/commit/f0228ed9ecb997f5b2839e04398994b3ebc82275). See [UPSTREAM-PIN.md](UPSTREAM-PIN.md) for source layout and submodule inventory.

## What the PC project actually does

AnyPS5 is a PS5 executable relinker plus reimplementations of PS5 system PRX libraries. It is not a conventional console emulator and does not ship Sony firmware, keys, or proprietary libraries. The PC output is currently x86-64 Linux ELF or Windows PE (and a relinker-only macOS Mach-O path). The full runtime relies on x86-64 host CPU features, including AVX2, FMA, F16C, BMI1/BMI2, LZCNT and MOVBE.

## Feature families that the Android port must account for

| Upstream capability | Android ARM64 work required | Port status |
|---|---|---|
| ELF inspection, imports/NIDs, conversion pipeline | Reuse format analysis where architecture-neutral; add AArch64 ELF writer and relocation model | Not ported |
| x86-64 relinker/code generation | New x86-64-to-AArch64 translator or dynamic binary translation backend; preserve PS5 guest ABI | Not ported |
| AMD-specific instruction lowering (`--to-intel`) | Not sufficient for ARM64; implement x86-64 semantics directly in AArch64 backend | Not ported |
| Guest bundled PRX/module conversion and loading | Android linker/runtime loader integration, guest module lifecycle, relocations, TLS and constructors | Not ported |
| NID patcher and PRX system libraries | Build every supported library for `arm64-v8a`; audit Linux/glibc assumptions and replace with Android/Bionic adapters | Not ported |
| Shader recompiler to SPIR-V | Retain/rework CPU-side compiler for ARM64; validate SPIR-V and Android Vulkan device support | Not ported |
| Vulkan / AGC-facing graphics interfaces | Android Vulkan surface/swapchain, extension/feature gates, memory budgeting and driver workarounds | Not ported |
| VideoOut / display timing | Android Surface lifecycle, orientation, refresh-rate changes, external display and frame pacing | Not ported |
| SDL controller, keyboard and mouse input | SDL Android backend or native Android input bridge; controller hotplug, analog axes/triggers and per-title mapping | UI detects controller only; runtime input not ported |
| Audio output and codecs | Android audio backend, latency tuning, audio focus, stream lifecycle, codec integration | Not ported |
| File system, archives and storage | SAF document access, scoped storage, virtual game filesystem, archive and path semantics | File picker only |
| Network, TLS, HTTP and sockets | Bionic/Android networking, permission/lifecycle handling, TLS backend and socket compatibility | Not ported |
| USB/device services | Android USB Host permission flow and device-specific capability checks | Not ported |
| Font, text, image and media dependencies | Build compatible ARM64 versions and validate licenses/ABI | Not ported |
| Input configuration and diagnostics | Preserve compatible config format; add Android touch profiles and controller remapping | UI scaffold only |
| Performance overlay, screenshots and telemetry | Android frame-time, thermal, memory and Vulkan diagnostics | Not ported |
| Test/fuzz/regression suite | Cross-compile, host-side unit tests, Android instrumentation, device/game bring-up and fuzzing | Not ported |

This table is deliberately conservative: the presence of a feature in the PC repository does not mean it is already available on Android.

## Required native architecture

```text
Android app (Kotlin / Compose)
  ├─ responsive PS5-style tablet/phone dashboard
  ├─ SAF library + persisted URI permissions
  ├─ controller/touch profile and overlay
  └─ diagnostics / logs / per-title compatibility
          │ JNI boundary
          ▼
Android native host (C++20, NDK, arm64-v8a)
  ├─ AnyPS5 architecture-neutral parsing/relinking pieces
  ├─ x86-64 guest decoder + AArch64 code generator / DBT
  ├─ PS5 guest ABI, exceptions, TLS, memory and syscalls
  ├─ Android/Bionic compatibility layer
  ├─ PRX loader + ARM64 PRX implementations
  ├─ shader compiler → SPIR-V → Android Vulkan
  ├─ SDL/Android input, audio and window/surface backends
  └─ diagnostics, caches, test harness
```

## ARM64 translation requirements

A genuine port cannot be achieved by changing CMake's target architecture or compiling the existing x86-64 output for ARM64. PS5 executables contain x86-64 machine code. The port needs an execution strategy:

1. **Static translation/relinking:** decode x86-64 instructions, build control-flow and relocation metadata, translate supported instructions into AArch64, and rewrite calls/branches/data references.
2. **Dynamic binary translation (DBT):** translate basic blocks at runtime, maintain guest register/flags state, handle indirect branches and invalidate code safely. This may be required for self-modifying/JIT code and dynamic modules.
3. **Guest ABI compatibility:** implement x86-64 register/stack conventions, SysV guest calls, vector/FPU state, condition flags, atomics, TLS, signal/exception behavior, unwind data and guest address-space semantics.
4. **System-library ABI:** port PRX exports and NID binding to ARM64 while preserving guest-visible structures, alignment, calling conventions and error behavior.
5. **Android host adaptation:** Bionic is not glibc. Avoid assuming desktop Linux syscalls, procfs access, executable-memory permissions, unrestricted filesystem paths, or desktop windowing/audio devices.

The upstream `core/Decoder` directory contains JPEG and PNG decoder areas, not a guest x86-64 CPU instruction decoder. The upstream `--to-intel` path only lowers selected AMD-specific instructions to Intel-compatible x86-64. It is not an ARM translator and cannot be repurposed as one without a new backend.

## Samsung tablet strategy

The app is configured for `arm64-v8a` and remains resizable/orientation-neutral. Device capability must be discovered at runtime, not guessed from the Samsung brand:

- Query Android API level, ABI, RAM class, available memory, CPU features, Vulkan version/extensions/features, device-local memory budget and surface formats.
- Use capability tiers rather than model-name allowlists: Vulkan feature set and memory budget determine graphics options.
- Support portrait and landscape, split-screen/resizing, keyboard/mouse, Bluetooth/USB gamepads, touch overlays and external display where Android exposes them.
- Treat Samsung DeX and taskbar/windowing as optional presentation modes, not prerequisites.
- Handle thermal status and sustained-performance limits; expose conservative, balanced and performance profiles.
- Test on the user's Samsung tablet model plus at least one lower-memory ARM64 device and one non-Samsung Android device.

## Compatibility and legal constraints

- Preserve the upstream GPL-2.0 licensing terms and required notices for any derivative work; verify the exact license grant and headers before redistributing modifications.
- Preserve each third-party dependency's own license and attribution.
- Do not package PS5 firmware, cryptographic keys, proprietary Sony libraries or copyrighted game data.
- Start bring-up with homebrew and test executables supplied lawfully by contributors.
- Report unsupported functions explicitly; never fake a successful implementation.

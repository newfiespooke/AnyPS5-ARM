# Upstream AnyPS5 source pin

- Project: [boykopovar/AnyPS5](https://github.com/boykopovar/AnyPS5)
- Purpose: automatic PS5 executable porting tool for Linux and Windows (upstream project description).
- Audited snapshot: `f0228ed9ecb997f5b2839e04398994b3ebc82275`
- Snapshot commit URL: https://github.com/boykopovar/AnyPS5/commit/f0228ed9ecb997f5b2839e04398994b3ebc82275
- Default branch at audit: `main`
- Repository license metadata: GPL-2.0; verify each source file and bundled dependency before copying or linking code.
- Integration status: **audited and pinned for planning only; upstream source has not been vendored into this Android project**.

## Source layout observed at the pinned snapshot

- `core/Decoder`: JPEG and PNG decoder areas; this is not the x86-64 CPU instruction translator.
- `core/relinker`: relinker implementation, CLI, code generation, ELF patching, fuzzing and I/O areas.
- `core/libs`: NID data, PRX/system-library implementations and shared type definitions.
- `core/shader/recompiler`: shader translation/recompilation area.
- `3rdparty` and `zlib`: external dependencies declared through Git submodules.

## Submodule inventory

The upstream `.gitmodules` file declares these dependencies. Each dependency must be pinned and license-audited before Android integration:

- jxrlib
- libfvad
- SDL2
- LibreSSL
- Vulkan-Headers
- SPIRV-Headers
- SPIRV-Tools
- glslang
- VulkanMemoryAllocator
- LibAtrac9
- ffmpeg-core
- opus
- freetype
- harfbuzz
- stb
- tracy
- mimalloc
- libjpeg-turbo
- libusb-cmake
- mbedtls
- zstd
- ZArchive
- vgmstream
- ogg
- vorbis
- nghttp2
- quickjs
- zlib
- sqlite
- fontconfig
- curl

## Next integration action

Create a dedicated `upstream/AnyPS5` subtree at the pinned revision with all submodule SHAs recorded. Do not import the desktop top-level build wholesale into Android. Start with a dependency graph and compile-time feature matrix, then port the smallest architecture-neutral pieces behind Android/Bionic adapters. Keep the original desktop build reproducible.

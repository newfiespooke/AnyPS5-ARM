# Contributing to AnyPS5 Android Edition

Thanks for helping build the Android ARM64 port. The project is early-stage; the most useful contributions are small, testable pieces with clear evidence.

## Before starting

1. Read `README.md`, `PORTING-ROADMAP.md` and the relevant architecture document.
2. Open or find an issue describing the proposed change before starting large work.
3. Do not assume the Android app can run upstream desktop output. The guest ABI, translation runtime and system-library compatibility are separate engineering tasks.

## Engineering rules

- Keep upstream source changes isolated and pin every upstream commit and submodule SHA.
- Preserve the license and notices for AnyPS5 and every third-party component.
- Never commit proprietary firmware, console keys, commercial game binaries, signing keystores, or personal data.
- Imported executable files are untrusted. Parsers must be bounds-checked and fuzzable; do not execute imported files in the UI process.
- Unsupported guest instructions, NIDs, syscalls and runtime features must fail explicitly. Do not stub success responses.
- Keep Kotlin UI work off the native execution path. Native operations must not block the main thread.
- Add host-side unit tests for portable C++ logic and device evidence for Android-specific behavior.

## Validation

Run the native core tests:

```bash
cmake -S app/src/main/cpp -B build/native-tests -DANYPS5_BUILD_NATIVE_TESTS=ON
cmake --build build/native-tests --target anyps5_runtime_tests --parallel
ctest --test-dir build/native-tests --output-on-failure
```

If using Clang with libFuzzer, build the ELF parser fuzzer:

```bash
cmake -S app/src/main/cpp -B build/elf-fuzz -DANYPS5_BUILD_ELF_FUZZER=ON -DCMAKE_CXX_COMPILER=clang++
cmake --build build/elf-fuzz --target anyps5_elf_fuzzer --parallel
```

For Android changes, attach the Android API level, device model, SoC/GPU, app version, logs and a concise reproduction. Do not claim Samsung compatibility without physical-device testing.

## Pull requests

- Explain the problem and the implementation.
- State which milestone the change advances.
- List commands run and their results.
- Mark work as implemented, partial, experimental or untested.
- Include relevant test fixtures only when they are original or licensed for redistribution.

#pragma once

#include <cstdint>
#include <string_view>

namespace anyps5::platform {

enum class CpuArchitecture : std::uint8_t {
    Arm32,
    Arm64,
    X86,
    X86_64,
    Unknown,
};

enum class OperatingSystem : std::uint8_t {
    Android,
    Linux,
    MacOS,
    Windows,
    Unknown,
};

struct HostInfo final {
    CpuArchitecture architecture{CpuArchitecture::Unknown};
    OperatingSystem operatingSystem{OperatingSystem::Unknown};
    std::uint8_t pointerBits{0};

    [[nodiscard]] constexpr bool is64Bit() const noexcept {
        return pointerBits == 64;
    }
};

// Reports the architecture/OS this binary was compiled for. It does not probe
// optional runtime CPU features and does not describe the emulated guest.
[[nodiscard]] HostInfo detectHost() noexcept;
[[nodiscard]] std::string_view toString(CpuArchitecture value) noexcept;
[[nodiscard]] std::string_view toString(OperatingSystem value) noexcept;

} // namespace anyps5::platform

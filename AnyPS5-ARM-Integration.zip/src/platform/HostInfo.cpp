#include "platform/HostInfo.hpp"

#include <climits>

namespace anyps5::platform {
namespace {

constexpr CpuArchitecture compiledArchitecture() noexcept {
#if defined(__aarch64__) || defined(_M_ARM64)
    return CpuArchitecture::Arm64;
#elif defined(__arm__) || defined(_M_ARM)
    return CpuArchitecture::Arm32;
#elif defined(__x86_64__) || defined(_M_X64)
    return CpuArchitecture::X86_64;
#elif defined(__i386__) || defined(_M_IX86)
    return CpuArchitecture::X86;
#else
    return CpuArchitecture::Unknown;
#endif
}

constexpr OperatingSystem compiledOperatingSystem() noexcept {
#if defined(__ANDROID__)
    return OperatingSystem::Android;
#elif defined(_WIN32)
    return OperatingSystem::Windows;
#elif defined(__APPLE__) && defined(__MACH__)
    return OperatingSystem::MacOS;
#elif defined(__linux__)
    return OperatingSystem::Linux;
#else
    return OperatingSystem::Unknown;
#endif
}

} // namespace

HostInfo detectHost() noexcept {
    return HostInfo{
        .architecture = compiledArchitecture(),
        .operatingSystem = compiledOperatingSystem(),
        .pointerBits = static_cast<std::uint8_t>(sizeof(void*) * CHAR_BIT),
    };
}

std::string_view toString(CpuArchitecture value) noexcept {
    switch (value) {
    case CpuArchitecture::Arm32: return "arm32";
    case CpuArchitecture::Arm64: return "arm64";
    case CpuArchitecture::X86: return "x86";
    case CpuArchitecture::X86_64: return "x86_64";
    case CpuArchitecture::Unknown: return "unknown";
    }
    return "unknown";
}

std::string_view toString(OperatingSystem value) noexcept {
    switch (value) {
    case OperatingSystem::Android: return "android";
    case OperatingSystem::Linux: return "linux";
    case OperatingSystem::MacOS: return "macos";
    case OperatingSystem::Windows: return "windows";
    case OperatingSystem::Unknown: return "unknown";
    }
    return "unknown";
}

} // namespace anyps5::platform

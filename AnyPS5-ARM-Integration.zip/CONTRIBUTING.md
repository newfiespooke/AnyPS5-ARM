# Contributing to AnyPS5 ARM64

Contributions are welcome. Keep changes small, testable, and tied to an explicit porting milestone.

## Before opening a change

1. Read `AGENTS.md` and the relevant skill in `skills/`.
2. Read the architecture and status documents.
3. Identify the exact host ABI and guest interface affected.
4. Reproduce the current baseline build/tests.
5. Open an issue for large architecture changes or new external runtime dependencies.

## Code requirements

- C++20 for shared native code unless the upstream project requires otherwise.
- Keep Android/JNI code separate from portable runtime code.
- No hidden guest-to-host pointer casts; use checked wrappers.
- Test error paths and malformed inputs.
- Record ABI and structure-layout evidence for PS5 interface work.
- Do not claim hardware support from emulator-only testing.

## External dependencies and upstream source

Every imported dependency needs an exact version/commit, license, notices, build recipe, patch list, test evidence and update policy. Do not vendor complete translation runtimes without an architecture and licensing review.

The ARM companion repository's `LICENSE` is AGPL-3.0; upstream AnyPS5 states that it is GPL version 2 only. Do not copy or link upstream source into a combined build until the compatibility issue is reviewed and permission is obtained where needed. See `docs/licensing/LICENSING-GATE.md`.

## Legal and security boundaries

Do not submit firmware, cryptographic keys, proprietary system modules, commercial game data or instructions to bypass platform security. Tests should use synthetic fixtures or legally obtained user-supplied inputs. Do not weaken sandboxing or code-memory protections to make a test pass.

## Reporting results

Update `docs/porting/COMPATIBILITY-MATRIX.md` with the status vocabulary and evidence. Distinguish `IMPLEMENTED_UNTESTED` from `TESTED_PASS`. Include exact device/OS/SoC/GPU/driver details for physical-device claims.

# AnyPS5 ARM64 agent instructions

Read the relevant skill before performing a task:

- Native ARM/C++/Android work: `skills/arm-software-engineering.skill`.
- x86/x64 source and ABI migration: `skills/x86-x64-to-arm-porting.skill`.
- CPU/API/graphics/audio translation runtime work: `skills/translation-layers-to-arm.skill`.
- Tests, evidence, fuzzing, security, and release claims: `skills/translation-runtime-validation.skill`.
- AnyPS5-specific architecture and sequencing: `skills/anyps5-arm64-porting.skill`.

## Non-negotiable project facts

1. Upstream `newfiespooke/AnyPS5` currently documents and configures x86-64 output. Do not describe it as an ARM64 port.
2. Upstream `--to-intel` lowers AMD-specific instructions to Intel-compatible instructions; it does not translate x86-64 to AArch64.
3. The existing upstream design is a relinker plus host-native PRX/system-library implementations and a shader recompiler. Do not silently replace that model with Wine or Proton.
4. The PS5 guest, host ISA, host operating system, host ABI, and executable format must be recorded independently.
5. Wine/Proton implement Windows compatibility; Box64/FEX target Linux x86 userspace execution models; DXVK/VKD3D-Proton translate Direct3D APIs. They are not interchangeable and none is a PS5 emulator.
6. Android uses the Android NDK and Bionic userspace. A Linux/glibc binary is not automatically an Android `arm64-v8a` binary.
7. Never bundle or request proprietary firmware, keys, system modules, or game content. Work with legally obtained user-provided inputs and public interface descriptions.

## Workflow

1. Inspect the repository, license, build graph, dependencies, and current tests.
2. Reproduce a baseline build before changing upstream-derived code.
3. Update `docs/porting/COMPATIBILITY-MATRIX.md` when capability status changes.
4. Make one narrow, reversible change at a time.
5. Add tests with each implementation change.
6. Run the exact build and test commands for the target ABI.
7. Distinguish compile-time host detection from runtime CPU feature detection.
8. Report the precise level tested: desktop host, Android emulator, or physical device/SoC.
9. Never report a stub, launcher, UI, metadata parser, or APK as a functioning PS5 execution runtime.
10. The ARM companion repository is AGPL-3.0, while the upstream AnyPS5 README declares GPL-2-only. Do not copy, link, or distribute combined upstream code until the licensing question is resolved with the relevant rights holders. Follow `docs/licensing/LICENSING-GATE.md`.

## Architecture rules

- Keep x86-64 guest state separate from AArch64 host state.
- Define and test the guest calling convention and ARM64 host bridge explicitly.
- Do not mix guest pointers with host pointers without checked translation.
- Use a reference interpreter or other independently validated reference path before optimizing a JIT.
- Make generated code memory W^X; do not leave executable pages writable.
- Keep graphics translation, guest CPU execution, and system-library compatibility independently switchable and testable.
- Reuse upstream code only after verifying build compatibility, dependency licensing, and test coverage.

## Change hygiene

- Preserve working code and project conventions.
- Do not add binary blobs, firmware, keys, game assets, or opaque downloads.
- Pin any external runtime to an exact release/tag/commit and record the license.
- Do not invent test results, performance numbers, device compatibility, or supported games.

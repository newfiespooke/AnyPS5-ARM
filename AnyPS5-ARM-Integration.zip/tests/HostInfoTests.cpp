#include "platform/HostInfo.hpp"

#include <cstdlib>
#include <iostream>

namespace {
void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}
} // namespace

int main() {
    const auto host = anyps5::platform::detectHost();
    require(host.architecture != anyps5::platform::CpuArchitecture::Unknown,
            "compiled CPU architecture must be classified");
    require(host.operatingSystem != anyps5::platform::OperatingSystem::Unknown,
            "compiled operating system must be classified");
    require(host.pointerBits == 32 || host.pointerBits == 64,
            "pointer width must be 32 or 64 bits");
    require(host.is64Bit() == (host.pointerBits == 64),
            "is64Bit must agree with pointer width");
    require(anyps5::platform::toString(host.architecture) != "unknown",
            "architecture must have a stable string representation");
    require(anyps5::platform::toString(host.operatingSystem) != "unknown",
            "OS must have a stable string representation");
    return 0;
}

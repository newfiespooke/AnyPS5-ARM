# AnyPS5 ARM64

**An experimental ARM64/Android porting companion for [AnyPS5](https://github.com/newfiespooke/AnyPS5).**

This repository is the place to develop and validate the Android ARM64 host side of AnyPS5. The upstream project remains the reference for PS5 executable relinking, system PRX compatibility libraries, RDNA shader recompilation, and the existing Linux/Windows desktop implementation.

> **Development status:** early foundation only. A native ARM64 host probe and the engineering/porting specifications are provided here. This repository does **not** yet execute PS5 software on ARM64, and an APK or GUI build must not be described as PS5 compatibility.

## Why a separate ARM64 port is needed

The upstream build currently produces **x86-64** output. Its optional `--to-intel` path lowers AMD-specific instructions to Intel-compatible instructions; it is not an x86-64-to-AArch64 translator. The upstream full macOS build is also configured for x86-64. Running the relinker-only tool on Apple Silicon does not change the architecture of its converted output.

A PS5-to-Android port therefore needs more than changing the ABI or packaging an APK. It needs an ARM64 host build, a guest x86-64 execution strategy, a guest ABI/runtime bridge, Android platform adapters, and independently validated graphics/audio/input paths.

See [verified status](docs/STATUS.md), [architecture](docs/architecture/ARM64-PORTING-ARCHITECTURE.md), and the [porting plan](docs/porting/PORTING-PLAN.md).

## First buildable component: host probe

The initial C++20 component reports the architecture and operating system that the binary was **compiled for**. It does not infer optional CPU features and does not execute guest code.

Native host build:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./build/anyps5-host-info
```

Android ARM64 cross-build (requires Android SDK and NDK):

```sh
cmake -S . -B build-android-arm64 \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_ROOT/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-26 \
  -DCMAKE_BUILD_TYPE=Release
cmake --build build-android-arm64 --parallel
```

The native host build can be tested on desktop CI. The Android command must be run with an installed NDK; it has not been represented as executed unless CI or a developer supplies build evidence.

## Engineering rules

- Keep the PS5 guest architecture, host CPU architecture, host OS, and host ABI as separate concepts.
- Preserve the upstream project as a pinned reference/dependency; document every local patch.
- Treat Wine/Proton, Box64/FEX, QEMU, DXVK, and VKD3D-Proton as separate technologies with different guest and OS assumptions. None is a drop-in PS5 runtime.
- Implement CPU translation, guest ABI, PRX/system services, graphics, audio, input, and Android lifecycle as separately testable subsystems.
- Do not bundle firmware, cryptographic keys, proprietary system modules, or commercial game files.
- Never claim functionality without reproducible tests and evidence from the stated target device.

## Repository map

- `AGENTS.md` — instructions for coding agents working in this repository.
- `skills/` — reusable ARM, x86-to-ARM, translation-layer, validation, and AnyPS5-specific skills.
- `docs/` — architecture, compatibility, porting, integration, and validation plans.
- `src/platform/` — compile-target host information.
- `tools/host-info/` — small host-probe CLI.
- `tests/` — initial host-probe tests.

## Upstream references

- [AnyPS5](https://github.com/newfiespooke/AnyPS5)
- [Upstream architecture](https://github.com/newfiespooke/AnyPS5/blob/main/docs/dev/ARCHITECTURE.md)
- [Upstream build instructions](https://github.com/newfiespooke/AnyPS5/blob/main/docs/dev/BUILD.md)
- [Android NDK ABI guide](https://developer.android.com/ndk/guides/abis)
- [Android NDK CMake guide](https://developer.android.com/ndk/guides/cmake)

## Licensing gate

The existing `LICENSE` in this ARM companion repository declares **GNU AGPL version 3**. The upstream AnyPS5 README declares **GNU GPL version 2 only**. Do not copy, link, or distribute a combined work using upstream source until the rights holders and project maintainers have resolved that compatibility question. Keep the repositories and any prototype components separate in the meantime. See [the licensing gate](docs/licensing/LICENSING-GATE.md). Third-party components retain their own licenses and notices.

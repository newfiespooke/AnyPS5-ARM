#!/usr/bin/env sh
set -eu
cmake -S . -B build-host -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build-host --parallel
ctest --test-dir build-host --output-on-failure
./build-host/anyps5-host-info

# Translation Technology Integration Decisions

This project has a PS5 guest model, not a Windows guest model or a generic Linux x86 userspace model. Evaluate every upstream technology against the guest ISA, guest ABI, host OS, host ABI and license.

| Technology | What it provides | Potential value | Why it is not a drop-in AnyPS5 solution |
|---|---|---|---|
| Wine | Windows API compatibility | Design patterns only if a future Windows guest is added | AnyPS5 needs PS5 runtime/system interfaces, not Win32 APIs |
| Proton | Wine-based Steam compatibility integration | No direct role in PS5 guest compatibility | Steam/Windows compatibility stack, not PS5 runtime |
| Box64 | x86-64 Linux userspace execution on ARM64 | Study DBT, decoder, code-cache and library-wrapper architecture; evaluate reusable components carefully | Linux userspace/syscall and loader assumptions do not implement PS5 ABI/services |
| FEX | x86/x86-64 userspace execution on ARM64 Linux | Study DBT, IR, JIT and test strategies; evaluate source component/license fit | Linux userspace model is not a PS5 kernel, PRX or system-library implementation |
| QEMU TCG | CPU emulation/dynamic translation | Reference implementation, prototype or comparison candidate after license/performance audit | QEMU user-mode syscall forwarding is not PS5 system compatibility; full-system QEMU is a different design |
| DXVK | Direct3D 8/9/10/11 to Vulkan | Not a direct PS5 renderer dependency | PS5 guest graphics interface is not Direct3D |
| VKD3D-Proton | Direct3D 12 to Vulkan | Not a direct PS5 renderer dependency | PS5 graphics commands/shaders require their own translation path |
| Vulkan | Host graphics API | Android GPU backend candidate | Vulkan presence alone does not guarantee required extensions/features/performance |

## Decision rules

1. Prefer reusing upstream AnyPS5 modules where they are platform-neutral and their assumptions are explicit.
2. For instruction translation, compare a maintained DBT backend against a small reference interpreter. Record decoder coverage, licensing, Android/NDK portability, signal/fault integration, self-modifying-code behavior and performance.
3. Do not embed an entire upstream runtime until its host-OS/ABI assumptions are understood.
4. Keep PS5 guest API/system-library implementation independent from Windows compatibility projects.
5. Keep Direct3D translators out of the PS5 graphics path unless a clearly defined Direct3D guest interface is introduced.
6. Pin every external component to a release/tag/commit and record its license, notices, patches, test commands and security update process.

## Upstream projects to evaluate

- [FEX](https://github.com/FEX-Emu/FEX)
- [Box64](https://github.com/ptitSeb/box64)
- [QEMU](https://www.qemu.org/)
- [Wine](https://gitlab.winehq.org/wine/wine)
- [Proton](https://github.com/ValveSoftware/Proton)
- [DXVK](https://github.com/doitsujin/dxvk)
- [VKD3D-Proton](https://github.com/HansKristian-Work/vkd3d-proton)
- [Android NDK ABI guide](https://developer.android.com/ndk/guides/abis)

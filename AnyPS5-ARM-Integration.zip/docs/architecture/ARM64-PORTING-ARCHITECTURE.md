# AnyPS5 ARM64 Porting Architecture

## 1. Target model

The port has two independent machine architectures:

- **Guest:** PS5 application code and modules, which the upstream project currently handles through an x86-64-oriented conversion/runtime path. Confirm the actual ISA and ABI per input module.
- **Host:** Android running on AArch64 (`arm64-v8a`) through the Android NDK and Bionic.

Do not confuse guest executable format, guest ABI, host executable format, host ABI, or host CPU instruction set. AArch64 is not an ABI, Android `arm64-v8a` is not generic Linux AArch64, and a native ARM64 APK does not prove guest x86-64 code can execute.

## 2. Proposed architecture

```text
       Legally obtained PS5 test input
                     |
                     v
         Container / executable inspector
                     |
                     v
          Guest module loader / relinker
                     |
                     v
       Guest address-space + memory model
                     |
                     v
       x86-64 guest execution subsystem
       +-------------------------------+
       | decoder -> guest IR -> checks  |
       | interpreter/reference path    |
       | optimizer -> AArch64 JIT       |
       | code cache + invalidation      |
       +-------------------------------+
                     |
                     v
       Guest ABI / callback / fault bridge
                     |
           PS5 PRX and system services
                     |
       +-------------+-------------------------+
       |             |            |             |
       v             v            v             v
    Graphics       Audio        Input      Filesystem/network
       |
       v
  PS5 graphics command/shader processing
       |
       v
  RDNA shader translation -> SPIR-V
       |
       v
  Android Vulkan device/driver
```

This is the target design, not a statement that these components exist in this repository today.

## 3. CPU execution subsystem

Keep the guest state explicit and independent of host registers. At minimum, the design must account for x86-64 general registers, RIP, RFLAGS, segment/base state actually used by the guest, floating-point/vector state, exception state, and memory-ordering behavior.

Recommended development order:

1. Define an ISA/feature baseline from inspected test modules.
2. Integrate a decoder and validate instruction boundaries.
3. Implement a deterministic reference interpreter for a narrow instruction subset.
4. Define a typed intermediate representation (IR).
5. Add AArch64 code generation for instructions already covered by conformance tests.
6. Implement block caching, linking, invalidation, and runtime dispatch.
7. Add fault/signal mapping, debug symbols, logging and safe deoptimization.

A JIT must use write-xor-execute memory transitions, validate all source code ranges, and define behavior for modified/self-generated code before claiming correctness.

## 4. Guest ABI bridge

The guest calling convention must not be treated as AAPCS64. Define explicit thunks for guest calls into host PRX implementations and host callbacks into guest functions. Document register arguments, stack layout, alignment, preserved registers, return values, aggregate passing, varargs, TLS, unwind behavior and exception propagation. Use fixed-width types for guest data structures; never copy guest structures into host structures without validated layout conversion.

## 5. PRX/system library layer

Keep each guest module/export implementation traceable to evidence:

- NID/export identifier.
- Function signature and structure layout evidence.
- Host implementation.
- Guest-to-host marshalling rules.
- Error/return semantics.
- Unit/integration test.
- Confidence and unresolved assumptions.

Do not mark guessed signatures as confirmed. Preserve the upstream project's strict error behavior unless a documented compatibility requirement justifies a different policy.

## 6. Graphics path

The upstream documentation describes an RDNA-to-IR-to-SPIR-V shader recompiler and Vulkan pipeline. The ARM port must audit each stage for ARM/Android compiler portability, then validate output with SPIR-V tools and on actual Android drivers. At runtime, collect required Vulkan API version, extensions, feature bits, format support, descriptor limits, subgroup properties, queue capabilities, shared-memory limits and driver identity.

A device that exposes Vulkan is not automatically compatible with every pipeline or shader feature. Create capability tiers and fail with actionable diagnostics when a required feature is absent.

## 7. Android host adapters

Keep Android-specific code at the platform boundary:

- NDK toolchain and `arm64-v8a` ABI.
- JNI entry points and Java/Kotlin lifecycle integration.
- Bionic/POSIX differences from desktop Linux.
- Activity recreation, foreground/background and surface lifecycle.
- Scoped storage and permission-aware user-selected files.
- Vulkan surface/swapchain recreation.
- Android audio APIs and latency handling.
- Controller discovery, input focus and haptics.
- Crash logs, thermal/battery observations and memory limits.

Never assume a Linux/glibc dependency builds unchanged against Android/Bionic.

## 8. Upstream integration strategy

Do not copy the full upstream repository blindly into this shell. Pin a source commit, record license/submodules, reproduce baseline tests, then integrate portable components behind target-aware CMake options. Keep guest architecture variables separate from host target variables. Audit CMake hard-coded architecture, dependency build flags, assembly, syscalls, threading, memory mapping, JIT permissions, graphics/window-system and audio code.

# AnyPS5 ARM64 Porting Status

## Relationship to upstream

This repository is the Android/ARM64 porting companion for [AnyPS5](https://github.com/newfiespooke/AnyPS5). Upstream remains the reference for executable relinking, PRX compatibility libraries, shader recompilation, and existing desktop behavior.

## Verified upstream facts at inspection time

- The upstream README describes AnyPS5 as an executable-porting tool for Linux and Windows.
- The upstream build guide says converted output is x86-64 (Linux ELF by default, Windows PE or macOS Mach-O by option).
- The upstream CMake configuration sets `ARCHITECTURE` to `x86_64` and restricts its full macOS build to x86-64.
- `--to-intel` lowers AMD-specific instructions to Intel-compatible instructions; it is not an x86-64-to-AArch64 translator.
- The upstream architecture documentation describes a relinker, host-native PRX/system-library implementations, and an RDNA-to-SPIR-V shader path.

References: [README](https://github.com/newfiespooke/AnyPS5/blob/main/README.md), [build guide](https://github.com/newfiespooke/AnyPS5/blob/main/docs/dev/BUILD.md), [architecture](https://github.com/newfiespooke/AnyPS5/blob/main/docs/dev/ARCHITECTURE.md), [CMakeLists](https://github.com/newfiespooke/AnyPS5/blob/main/CMakeLists.txt).

These are repository facts, not a claim that an Android port has already been implemented. Re-check upstream before each integration milestone.

## Licensing status

The `LICENSE` file in this companion repository identifies GNU AGPL version 3. The upstream AnyPS5 README identifies GNU GPL version 2 only. This is a project integration blocker for copying or linking upstream source into a combined work until the relevant rights holders and maintainers resolve compatibility. The current host-probe foundation is independently authored and does not import upstream source. See `docs/licensing/LICENSING-GATE.md`.

## ARM64 status at this foundation milestone

| Area | Status | Evidence |
|---|---|---|
| Host compile-target probe | IMPLEMENTED | C++20 source and native unit test in this repository |
| Android NDK build | NOT_ASSESSED | NDK/Android build not run in this environment |
| Android GUI/JNI lifecycle | NOT_IMPLEMENTED | No Android app integration in this foundation |
| Upstream core integration | NOT_IMPLEMENTED | Design and audit plan only |
| Guest x86-64 execution on AArch64 | NOT_IMPLEMENTED | No translator/interpreter implemented |
| Guest memory/ABI bridge | NOT_IMPLEMENTED | Design work remains |
| PS5 PRX/system service compatibility on ARM64 | NOT_IMPLEMENTED | Requires per-interface port and tests |
| PS5 graphics path to Android Vulkan | NOT_IMPLEMENTED | Upstream shader stages need platform audit and device validation |
| Android audio/controller/storage adapters | NOT_IMPLEMENTED | Requirements documented; code not integrated |
| Physical Android device test | NOT_ASSESSED | No device evidence attached |

## Important interpretation

A successful native host-probe build demonstrates only that this small C++ component compiles and reports the host build target. It does not demonstrate PS5 executable loading, guest instruction execution, PRX compatibility, or game compatibility.

## Next gate

Build and install a minimal `arm64-v8a` native Android library on a physical device, capture device/SoC/Vulkan capability information, and then begin the upstream dependency/architecture audit.

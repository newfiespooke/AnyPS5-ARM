# Licensing Gate: AnyPS5 Upstream and ARM Companion

## Observed repository notices

- The existing `LICENSE` in `newfiespooke/AnyPS5-ARM` begins with **GNU Affero General Public License, Version 3**.
- The upstream `newfiespooke/AnyPS5` README states: **GNU General Public License version 2 only**.

References:
- [AnyPS5-ARM repository](https://github.com/newfiespooke/AnyPS5-ARM) (inspect its existing `LICENSE` file)
- [AnyPS5 upstream README](https://github.com/newfiespooke/AnyPS5/blob/main/README.md)
- [GNU GPL FAQ: GPLv2 and GPLv3 compatibility](https://www.gnu.org/licenses/gpl-faq.html#v2v3Compatibility)
- [GNU license compatibility guidance](https://www.gnu.org/licenses/license-compatibility.html)

## Why this is a gate

The Free Software Foundation explains that GPLv2 and GPLv3 are incompatible for combining code into one covered work, and that AGPLv3 is a separate license series rather than a later version of GPLv2. The precise legal result depends on the actual form of integration and the complete notices and permissions for all code involved.

Do not assume that code declared GPL-2-only can be copied into, linked into, or redistributed as part of this AGPL-3.0 repository. Do not change notices or relicense upstream contributions. A compatibility solution may require explicit additional permission from the relevant copyright holders, a separate-process boundary, a different repository/license arrangement, or another approach reviewed by qualified counsel.

## Required actions before upstream source integration

- [ ] Inspect the full `LICENSE` and file-level notices in both repositories.
- [ ] Identify the exact upstream files, commits, submodules and third-party dependencies proposed for reuse.
- [ ] Determine whether the planned integration creates a combined/derivative work or genuinely separate programs.
- [ ] Obtain written permission or another documented licensing basis where needed.
- [ ] Record the decision and required notices before enabling the integration in a distributable build.

## Current scope

The initial host-probe source in this integration bundle is independently authored and does not copy upstream AnyPS5 code. The architecture documents describe a future integration plan, not a claim that upstream source has been merged. Keep this separation until the gate is resolved.

This document is an engineering risk register, not legal advice.

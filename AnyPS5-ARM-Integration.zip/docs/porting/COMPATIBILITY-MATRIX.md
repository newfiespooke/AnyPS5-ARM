# AnyPS5 ARM64 Compatibility Matrix

Status vocabulary: `NOT_ASSESSED`, `BLOCKED`, `NOT_IMPLEMENTED`, `IMPLEMENTED_UNTESTED`, `TESTED_PASS`, `TESTED_PARTIAL`, `TESTED_FAIL`, `NOT_APPLICABLE`.

Update this file only with evidence. Add source commit, build command, device, OS, CPU, GPU/driver, test name, log/artifact and limitations whenever a status changes.

## Target tuple

| Dimension | Intended target | Verified evidence |
|---|---|---|
| Guest ISA | x86-64, per-module verification required | Upstream build/documentation currently uses x86-64 output |
| Host ISA | AArch64 / ARM64 | Intended target; physical-device verification pending |
| Host ABI | Android `arm64-v8a` | NDK target configured in documented command; build not yet assessed |
| Host OS | Android | Android app integration not yet implemented in this foundation |
| Host userspace | Bionic | Android NDK target requirement |
| Guest binary format | Inspect per input; do not assume every file is plain ELF | Pending format-specific test fixtures |
| Graphics host API | Vulkan | Planned; driver capabilities must be queried per device |

## Feature matrix

| Feature | Status | Evidence / blocker |
|---|---|---|
| Compile-target host probe | IMPLEMENTED | Native CMake build and unit test in this bundle |
| Android `arm64-v8a` compile | NOT_ASSESSED | Requires NDK build run |
| Android JNI/library loading | NOT_IMPLEMENTED | No Android application shell in this bundle |
| Upstream AnyPS5 core integration | NOT_IMPLEMENTED | Requires pinned-source audit |
| Guest executable/package loader on ARM64 | NOT_IMPLEMENTED | Guest/host memory and relocation design required |
| x86-64 decoder | NOT_IMPLEMENTED | No decoder dependency selected/pinned |
| x86-64 interpreter/reference path | NOT_IMPLEMENTED | Required for baseline semantic tests |
| AArch64 JIT/code generator | NOT_IMPLEMENTED | Requires tested IR and code cache design |
| Guest CPU state/fault semantics | NOT_IMPLEMENTED | Design and implementation required |
| Guest ABI bridge | NOT_IMPLEMENTED | Guest calling convention and marshalling not verified |
| PS5 PRX/system services on ARM64 | NOT_IMPLEMENTED | Per-NID signature and integration work required |
| Guest memory/atomics/threading | NOT_IMPLEMENTED | Requires guest address-space model and conformance tests |
| RDNA shader recompiler on Android | NOT_ASSESSED | Upstream stages exist; Android dependency and driver audit pending |
| Android Vulkan device tiering | NOT_IMPLEMENTED | No runtime capability collector yet |
| Audio backend | NOT_IMPLEMENTED | Android audio integration pending |
| Controller/input backend | NOT_ASSESSED | Requirements exist upstream; Android device test pending |
| Storage/network adaptation | NOT_IMPLEMENTED | Android permission and API mapping pending |
| Physical device bring-up | NOT_ASSESSED | No device logs attached |
| Commercial game compatibility | NOT_ASSESSED | No title compatibility claims permitted without evidence |

## Device evidence

| Manufacturer/model | SoC | Android build | ABI | GPU/driver | Test commit | Result/log |
|---|---|---|---|---|---|---|
| TODO | TODO | TODO | arm64-v8a | TODO | TODO | TODO |

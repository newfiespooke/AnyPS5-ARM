# AnyPS5 ARM64 Porting Plan

## Goal

Create a native Android `arm64-v8a` host for an experimental AnyPS5 port. The plan does not assume full PS5 execution is currently available.

## Work packages and acceptance gates

### WP0 — Baseline, licensing and provenance
- [ ] Record upstream AnyPS5 commit SHA and license.
- [ ] Record this companion repository commit SHA.
- [ ] Reproduce upstream relinker-only build and tests.
- [ ] Reproduce upstream full desktop build where supported.
- [ ] Record exact architecture and output format of each artifact.
- **Gate:** build logs, test report, dependency/license inventory and immutable source references are saved.

### WP1 — Android ARM64 host foundation
- [x] Add compile-target host-information library and CLI.
- [x] Add native unit test for host information.
- [ ] Build with Android NDK for `arm64-v8a`.
- [ ] Load the native library through an Android app/JNI entry point.
- [ ] Test install, launch, surface loss/recreation, background and foreground transitions on a physical device.
- **Gate:** a physical ARM64 device runs a native library and emits a reproducible device report.

### WP2 — Upstream dependency and portability audit
- [ ] Audit CMake and compile definitions for guest/host architecture conflation.
- [ ] Audit SDL2, FFmpeg, Vulkan-Headers, SPIR-V, glslang, SPIRV-Tools, FreeType, libusb and all other dependencies for Android support.
- [ ] Separate desktop-only dependencies from portable core.
- [ ] Add explicit host-platform and guest-ISA CMake variables.
- [ ] Preserve upstream tests and conventions.
- **Gate:** a documented, reproducible Android core build; no claim of guest execution yet.

### WP3 — Guest input, module loading and memory
- [ ] Inspect and validate package/executable/module metadata.
- [ ] Document guest file format, relocations, imports and module initialization.
- [ ] Define guest address-space reservation, page permissions and checked accessors.
- [ ] Add malformed-input, boundary, fuzz and regression tests.
- **Gate:** synthetic legally created fixtures load and validate deterministically.

### WP4 — x86-64 guest execution on ARM64
- [ ] Inventory required x86-64 instructions and optional ISA features from test fixtures.
- [ ] Integrate a decoder with license and version pinned.
- [ ] Define guest CPU state and exception model.
- [ ] Implement an interpreter/reference engine for a narrow tested subset.
- [ ] Add differential instruction conformance tests.
- [ ] Define IR and AArch64 backend.
- [ ] Add code cache, block linking, invalidation and dispatch.
- [ ] Enforce W^X and test self-modifying code behavior if required.
- **Gate:** a synthetic x86-64 test program passes the declared conformance suite on physical ARM64 hardware.

### WP5 — ABI and runtime services
- [ ] Define guest-to-host and host-to-guest ABI thunks.
- [ ] Implement stack/register/structure marshalling.
- [ ] Implement thread, TLS, atomics, synchronization and fault handling.
- [ ] Port PRX interfaces one by one with signature evidence.
- **Gate:** test modules pass interface-specific unit and integration suites.

### WP6 — Graphics and multimedia
- [ ] Port shader front end/recompiler stages independently.
- [ ] Validate generated SPIR-V.
- [ ] Implement Vulkan capability discovery and tiered device support.
- [ ] Validate pipeline creation, descriptor behavior, synchronization and presentation.
- [ ] Implement Android audio, controller and input adapters.
- **Gate:** dedicated graphics/audio/input tests pass on named device/driver combinations.

### WP7 — Application bring-up and release
- [ ] Integrate Android UI/JNI/lifecycle.
- [ ] Test purpose-built synthetic modules and legally obtained homebrew fixtures.
- [ ] Run regression, fuzz, sanitizer and performance suites.
- [ ] Publish compatibility matrix, known limitations, dependency notices and checksums.
- **Gate:** release claims are supported by logs, device matrix and repeatable tests.

## Priority order

1. Keep the host-probe slice buildable.
2. Make the Android NDK host build reproducible.
3. Audit upstream component portability.
4. Choose guest CPU translator based on measured requirements and license.
5. Build ABI/memory tests before game bring-up.
6. Port graphics only after the CPU/runtime path is measurable.

Do not skip a gate by relabeling a launcher, APK, mock, stub, or metadata parser as a compatibility runtime.

# Initial Test Report

Date: 2026-11-09
Scope: host-probe foundation only

## Environment

- Build host: Linux x86-64
- Compiler: GNU C++ 14.2.0
- CMake: 3.31.6
- C++ language mode: C++20

## Command

```sh
./scripts/build-host.sh
```

## Result

- CMake configure: PASS
- Native C++ compilation: PASS
- `anyps5-platform-tests`: PASS (1/1)
- Host probe output: `compiled_architecture=x86_64`, `compiled_os=linux`, `pointer_bits=64`, `scope=compile_target_only`

## Not tested

- Android NDK cross-compilation: NOT RUN (no Android NDK configured in this environment)
- Android emulator: NOT RUN
- Physical ARM64 device: NOT RUN
- Upstream AnyPS5 integration: NOT RUN
- PS5 guest instruction execution, ABI, PRX services, graphics, audio or title compatibility: NOT IMPLEMENTED / NOT TESTED

This report must not be used to imply ARM64 or PS5 compatibility. The host probe reports the architecture for which the current binary was compiled.

# AnyPS5 ARM64 Validation Plan

## Evidence rule

Each test record must include source commit, build type, compiler/NDK version, command, target ABI, device/emulator identifier, OS build, SoC/CPU, GPU/driver where relevant, result, log path and known limitations.

## Test layers

### Host and build
- Native CMake configure/build/test.
- Android NDK `arm64-v8a` configure/build.
- APK install and native library load.
- ABI inspection of packaged `.so` files.
- Dependency and symbol audit; ensure no accidental x86-64 desktop dependency.

### Input parsing and guest memory
- Truncated and malformed headers.
- Integer overflow and out-of-range offsets.
- Invalid alignment and overlapping regions.
- Relocation/import table boundaries.
- Guest pointer conversion and page permission transitions.
- Fuzz parsers with generated synthetic fixtures.

### CPU translation
- Single-instruction semantic tests.
- Register and flag preservation.
- Arithmetic edge cases and undefined/unsupported instructions.
- Floating-point rounding, denormals, NaNs and exceptions.
- SIMD lane behavior and alignment.
- Atomics and memory-ordering tests.
- Branch, call/return, stack, and fault behavior.
- Differential comparison against a trusted reference engine.

### ABI/runtime
- Guest-to-host calls and host callbacks.
- Stack alignment and preserved-register checks.
- Aggregate arguments/returns and varargs where required.
- TLS, threads, synchronization, signals/exceptions and cancellation.
- Library loading, initialization, recursion and unload/reload.

### Graphics/media/input
- SPIR-V validation.
- Vulkan feature/extension/format/limit checks.
- Shader and pipeline creation under multiple drivers.
- Surface loss/recreation and swapchain lifecycle.
- Audio format, timing, underrun and latency tests.
- Controller discovery, focus changes, axis/button mapping and haptics.

### Security/performance
- Parser fuzzing and sanitizer runs.
- JIT W^X and code-cache invalidation tests.
- Memory/resource leak checks.
- Crash recovery and malformed guest input rejection.
- Performance benchmarks on named devices with warm-up, repeated runs and thermal state recorded.

## Release gate

No release may claim PS5 execution compatibility unless a purpose-built test suite verifies loading, guest instruction execution, ABI bridging, required PS5 services, graphics, audio/input, and app lifecycle on a named physical ARM64 device. A UI demo, successful APK build, host probe, or one synthetic parser fixture is not sufficient.

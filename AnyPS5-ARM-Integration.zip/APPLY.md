# Apply this integration bundle

This ZIP is an overlay for the existing `newfiespooke/AnyPS5-ARM` repository. It preserves the repository's existing `LICENSE` file and adds or replaces only the paths included here. The overlay's top-level paths are intended to be extracted directly into the root of the cloned repository.

From a local clone of that repository:

```sh
unzip -o AnyPS5-ARM-Integration.zip -d .
git status --short
git add README.md AGENTS.md CONTRIBUTING.md CMakeLists.txt .gitignore .github docs skills src tools tests scripts
 git commit -m "feat: add ARM64 porting foundation and engineering skills"
```

Review the diff before committing. The host-probe component is a small compile-target detector, not a PS5 emulator or x86-64 translator. Run `./scripts/build-host.sh` on a host with CMake and a C++20 compiler. Run `./scripts/build-android-arm64.sh` only with the Android NDK installed.

## Summary

Describe the subsystem and milestone this change advances.

## Architecture impact

- [ ] Guest ISA/ABI impact documented
- [ ] Host OS/ABI impact documented
- [ ] Android-specific code remains isolated
- [ ] External dependencies and licenses reviewed

## Validation

- [ ] Native build/tests
- [ ] Android NDK `arm64-v8a` build
- [ ] Emulator test (identify image)
- [ ] Physical ARM64 device test (identify model/SoC/OS/GPU/driver)
- [ ] Compatibility matrix updated

## Claims and limitations

List exactly what was tested and what remains unimplemented or unverified. Do not claim PS5 compatibility from a build/package/UI-only test.

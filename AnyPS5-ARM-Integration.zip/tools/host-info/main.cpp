#include "platform/HostInfo.hpp"

#include <iostream>

int main() {
    const auto host = anyps5::platform::detectHost();
    std::cout << "AnyPS5 ARM host probe\n"
              << "compiled_architecture=" << anyps5::platform::toString(host.architecture) << '\n'
              << "compiled_os=" << anyps5::platform::toString(host.operatingSystem) << '\n'
              << "pointer_bits=" << static_cast<unsigned>(host.pointerBits) << '\n'
              << "is_64_bit=" << (host.is64Bit() ? "true" : "false") << '\n'
              << "scope=compile_target_only\n";

    if (host.architecture == anyps5::platform::CpuArchitecture::Unknown ||
        host.operatingSystem == anyps5::platform::OperatingSystem::Unknown ||
        host.pointerBits == 0) {
        std::cerr << "Host target could not be classified by this build.\n";
        return 2;
    }
    return 0;
}

---
name: anyps5-compatibility-engineering
description: Project-specific workflow for building AnyPS5 as an Android ARM64 application focused on lawful interoperability research, independent compatibility components, controller/input support, media/rendering experiments, and measurable device performance. Use alongside relevant upstream Android skills and the defensive reverse-engineer skill. Do not use for DRM circumvention, authentication bypass, extraction of secrets, exploitation, or unauthorized redistribution.
---

# AnyPS5 compatibility engineering

## Mission

Build a contributor-friendly Android application and research framework for independently implemented, lawful interoperability components. The project must distinguish verified compatibility from hypotheses and must never imply that arbitrary PS5 games can run natively on Android.

## Non-negotiable platform facts

- PS5 software targets a proprietary console environment built around AMD64/x86-64 CPU architecture and Sony-specific system interfaces.
- Android ARM64 devices use AArch64 and Android/Bionic APIs. CPU ISA, operating-system ABI, graphics stack, security model, and platform services differ.
- A direct native port requires source code and rights to port, or a separately engineered compatibility/runtime layer. A binary rename, APK wrapper, or ABI manifest change is not a port.
- Do not claim PS5 game execution unless a specific title/build has been lawfully tested and evidence is published.

## Workstreams

1. **Android shell and UX**: Compose-based library, settings, device diagnostics, controller mapping, logs, and accessibility. Use `adaptive`, `edge-to-edge`, `jetpack-compose-performance`, `navigation-3`, `navigation-event`, and `testing-setup`.
2. **Native ARM64 foundation**: Kotlin/JNI boundary, C/C++ modules, NDK toolchain, CMake, ABI checks, crash-safe interfaces, and reproducible builds. Keep platform-independent code separate from Android-specific adapters.
3. **Input and controller interoperability**: Use Android-supported game-controller APIs and documented device interfaces. Record device model, Android version, mapping, polling behavior, latency, and test results. Do not impersonate a console or bypass access controls.
4. **Graphics and media research**: Prototype using public Android graphics APIs (Vulkan/OpenGL ES) and Media3 only where appropriate. Treat proprietary PS5 graphics commands, shader formats, and runtime services as undocumented until supported by authorized evidence.
5. **Compatibility research**: Use the defensive `reverse-engineer` workflow only for software, firmware, and interfaces the project owns, is licensed to analyze, or is explicitly authorized to assess. Prefer published documentation, open-source implementations, and clean-room specifications.
6. **Performance and stability**: Use `android-profiler`, `anr-audit-and-fix`, and `jetpack-compose-performance`; capture Perfetto traces and report CPU/GPU/memory/thermal/latency measurements on named devices.
7. **Security and release**: Use `android-intent-security`, `android-permissions-security`, `r8-analyzer`, `testing-setup`, and applicable Play policy guidance. Minimize permissions, protect IPC, and never store console passwords, tokens, or keys.

## Research workflow

### A. Intake and authorization

For every target component, record: owner, source, license, authorization basis, version/hash, intended interoperability question, allowed methods, and prohibited actions. Stop if authorization is unclear.

### B. Public-source reconnaissance

Start with public specifications, official Android documentation, open-source projects, published patents or talks where relevant, and vendor-supported interfaces. Record citations, versions, and dates. Avoid speculative statements about internal PS5 behavior.

### C. Compatibility hypothesis

Write a testable statement, for example: “This Android controller mapping exposes the expected button events on device X.” Do not write broad claims such as “PS5 compatible” without a defined test matrix.

### D. Independent implementation

Implement clean-room adapters against documented or authorized interfaces. Separate interfaces, platform adapters, native core, UI, and test fixtures. Do not copy proprietary code or assets.

### E. Verification

For each feature, publish: environment, device/OS/build, test inputs, expected result, observed result, logs/traces, known limitations, and reproducibility steps. Use automated tests where possible.

### F. Release gate

Require passing tests, license review, dependency inventory, security review, performance baseline, and a clear compatibility statement. Mark unsupported features explicitly.

## Repository architecture (proposed)

- `app/`: Android application, Compose UI, settings, device diagnostics.
- `core/`: platform-independent models and interfaces.
- `native/`: C/C++ ARM64 modules built with Android NDK/CMake.
- `platform/android/`: JNI, Android input, storage, graphics, and lifecycle adapters.
- `compat/`: independently implemented, documented compatibility components.
- `research/`: public-source notes, authorization records, hypotheses, and sanitized findings.
- `tests/`: unit, instrumentation, native, UI, and device-matrix tests.
- `docs/`: architecture decisions, supported feature matrix, build instructions, and contributor guide.

This is a proposed structure, not a claim that these directories already exist.

## Required research note template

- Component / feature and version
- Source URL or artifact hash
- Authorization and license basis
- Target question and scope
- Architecture / ABI / API assumptions
- Hypothesis and evidence for/against
- Test environment and exact steps
- Results, logs, traces, and reproducibility
- Limitations and confidence level
- Next action / reviewer

## Contributor rules

- Every PR has a narrow scope and tests or a documented reason tests are not feasible.
- No credentials, private keys, proprietary game files, console firmware dumps, or user data in issues/PRs.
- Do not submit DRM/access-control circumvention, exploit code, or instructions to defeat authentication.
- Label research claims as `verified`, `observed`, `hypothesis`, or `unknown`.
- Preserve upstream skill files; put project-specific changes in `anyps5/` or project modules.

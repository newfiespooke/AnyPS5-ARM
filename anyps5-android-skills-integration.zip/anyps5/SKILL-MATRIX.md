# Skill integration matrix

All **36** upstream skills are included unchanged under `skills/`. This matrix explains when AnyPS5 should load each one. “Direct” means useful to the core Android application or native runtime; “Conditional” means only for an optional feature or distribution path; “Not applicable” means retain but do not use for the current core target.

| Skill | Status | AnyPS5 application |
|---|---|---|
| `adaptive` | DIRECT | Adaptive layouts for device-size variation, game library UI, controller-aware navigation, and landscape/tablet layouts. |
| `agp-9-upgrade` | DIRECT | Build-system maintenance and migration; apply only after checking the project AGP/Kotlin compatibility. |
| `android-cli` | DIRECT | Android project creation, SDK/emulator/device management, install/run, screenshots, and official docs lookup. |
| `android-for-cars-parked-apps` | NOT APPLICABLE | Car-specific UX and driver-distraction rules do not map to PS5 compatibility. Retain only for a future car product. |
| `android-intent-security` | DIRECT | Secure exported components and incoming intents in the AnyPS5 Android app. |
| `android-permissions-security` | DIRECT | Permission minimization, Binder/IPC boundaries, and component security. |
| `android-profiler` | DIRECT | Perfetto, CPU/GPU/memory/power/IPC profiling for rendering, streaming, input latency, and native bridges. |
| `anr-audit-and-fix` | DIRECT | Prevent and diagnose ANRs in long-running native, streaming, storage, and device-communication workflows. |
| `appfunctions` | CONDITIONAL | Expose safe app workflows to Android system agents; not a PS5 compatibility layer. |
| `camerax` | NOT APPLICABLE | Camera capture APIs do not contribute to console/game compatibility. |
| `display-glasses-with-jetpack-compose-glimmer` | NOT APPLICABLE | XR display-glasses UI is outside the current phone/tablet target. |
| `edge-to-edge` | DIRECT | Modern Android system-bar/inset behavior for immersive landscape interfaces. |
| `engage-sdk-integration` | NOT APPLICABLE | Android Engage surfaces are not required for the core compatibility stack. |
| `glance-appwidget-updates-and-memory` | CONDITIONAL | Optional home-screen status widgets; unrelated to runtime compatibility. |
| `glance-canonical-layouts` | CONDITIONAL | Optional home-screen widgets for library/download/session status. |
| `ink-app-builder` | NOT APPLICABLE | Stylus/ink features are not part of the core project. |
| `ink-custom-brush-builder` | NOT APPLICABLE | Custom stylus brushes are not part of the core project. |
| `jetpack-compose-performance` | DIRECT | Compose UI performance and state stability for library, settings, controller mapping, and overlays. |
| `leanback-to-compose-tv-migration` | CONDITIONAL | Useful only if AnyPS5 adds Android TV/Google TV browsing; TV support is not PS5 emulation. |
| `litert-lm` | CONDITIONAL | Optional on-device language-model features for metadata/help; not required for compatibility. |
| `litert-runtime` | CONDITIONAL | Optional on-device ML inference; not a graphics or CPU instruction translator. |
| `media3-cast-integration` | CONDITIONAL | Optional casting/media playback support; not PS5 game streaming compatibility. |
| `migrate-xml-views-to-jetpack-compose` | DIRECT | Migrate legacy UI surfaces to Compose where it improves maintainability. |
| `ml-kit-genai-prompt-api` | CONDITIONAL | Optional AI-assisted metadata/help workflows; keep off the critical runtime path. |
| `mlkit-agent-api` | CONDITIONAL | Optional ML Kit agent integrations; not part of console protocol implementation. |
| `navigation-3` | DIRECT | Structure multi-screen navigation and restore state across device changes. |
| `navigation-event` | DIRECT | Consistent navigation/input event handling, including keyboard/controller focus paths where supported. |
| `play-billing-library-version-upgrade` | NOT APPLICABLE | Billing SDK upgrades are not part of the compatibility layer; revisit only if monetization is added. |
| `play-policy-insights` | CONDITIONAL | Use when preparing Play distribution and policy review; does not validate PS5 interoperability. |
| `projected-hardware` | NOT APPLICABLE | Projected hardware APIs are not part of the current target. |
| `r8-analyzer` | DIRECT | Inspect shrinking/obfuscation and keep rules for release builds; preserve JNI/reflection entry points. |
| `restore-credentials` | CONDITIONAL | Optional account/session restoration; must not store or replay console credentials. |
| `testing-setup` | DIRECT | Unit, instrumentation, UI, screenshot, native integration, and device-matrix testing. |
| `verified-email` | CONDITIONAL | Optional account verification for AnyPS5 services; unrelated to PS5 account authentication. |
| `wear-compose-m3` | NOT APPLICABLE | Wear OS UI is outside the current target. |
| `wear-widgets` | NOT APPLICABLE | Wear OS widgets are outside the current target. |

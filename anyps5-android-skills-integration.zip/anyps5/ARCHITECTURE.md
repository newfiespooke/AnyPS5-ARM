# AnyPS5 proposed architecture

## Reality check

PS5 game software is not an Android ARM64 application. PS5's CPU ISA/platform ABI, OS services, security model, GPU driver/runtime, and proprietary system APIs differ from Android ARM64. A generic direct port of commercial PS5 binaries is not a realistic engineering target.

## Feasible project direction

Build an Android-native host application plus independently implemented interoperability components. Initial milestones should be modest and measurable:

1. Android app shell, diagnostics, and controller support.
2. Native ARM64 module and reproducible NDK build pipeline.
3. Documented media/input experiments using public Android APIs.
4. Compatibility research against open-source or explicitly authorized components.
5. A per-feature compatibility matrix with device/build evidence.

## Layering

- UI: Kotlin + Jetpack Compose.
- App services: lifecycle, storage, permissions, input discovery, logs.
- Native boundary: JNI with versioned C ABI and strict ownership rules.
- Native core: portable C/C++ code; avoid assuming x86-64 semantics.
- Graphics: Android-supported Vulkan/OpenGL ES abstractions.
- Compatibility adapters: clean-room modules implementing documented interfaces only.
- Test harness: JVM tests, Android instrumentation, native tests, device lab, Perfetto.

## Explicit non-goals

- Running arbitrary PS5 commercial game binaries on ARM64.
- Bypassing PS5 secure boot, DRM, account authentication, or access controls.
- Extracting or redistributing proprietary firmware, keys, game assets, or source.
- Claiming compatibility without repeatable tests.

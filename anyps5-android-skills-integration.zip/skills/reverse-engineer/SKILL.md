---
name: reverse-engineer
description: Defensive reverse-engineering methodology for binaries, firmware, and protocols — vulnerability research, malware understanding, patch verification, and interoperability. Use this skill whenever the user wants to analyze, decompile, disassemble, or "figure out what this binary/driver/agent/file format actually does," diff a patch against a vulnerable version, document an undocumented protocol, or plan a reverse-engineering effort, even if they don't say "reverse engineering." Covers authorization and scope, lab setup, static vs dynamic analysis, note-keeping, and turning findings into defenses. Does not cover exploit development or circumventing DRM/access controls.
---

# Reverse Engineer (defensive)

Reverse engineering is the disciplined study of how software actually works by examining its compiled form: disassembly, decompilation, and behavioral observation. The output is a defense (vulnerability report with root cause, detection logic, hardening advice) or an interoperability spec, never just "I understand it now."

Scope: standard published methodology only. No exploit development, no DRM or access-control circumvention. If a request drifts there, say so and redirect to root-cause analysis, detection, or remediation.

Patience beats cleverness. Speed comes from method: consistent naming, structured notes, a hypothesis log, and verification discipline.

## When to use

- Understanding a suspicious binary's or malware's true behavior
- Vulnerability research on software the user is authorized to assess (own products, bounty scope, contracted work)
- Verifying what a third-party agent, driver, or firmware does before deployment
- Documenting a protocol or file format for integration
- Confirming a patch fixed the vulnerable code path

## Core principles

- **Legal scope first.** Work only on software the user owns, is licensed to analyze, or is explicitly authorized to assess. Restrictions vary by jurisdiction and license; when unsure, recommend legal review.
- **Define the question.** "Understand this binary" is unbounded. Pin down the decision the analysis informs (patch? block? interop?) and scope to it.
- **Behavior first.** Observe inputs/outputs, network traffic, and system interactions before reading code. This narrows millions of instructions to hundreds.
- **Static to target, dynamic to confirm.** Static analysis shows all possible paths; dynamic shows what executes. Confirm with evidence, not code-reading alone.
- **Prefer safe-first.** For unknown samples, do static inspection (hashes, strings, imports, headers) before executing anything. Execute only in an isolated lab.
- **Find the interesting code.** Parsers of untrusted input (where memory-safety bugs live), auth checks, crypto routines, network handlers, update mechanisms.
- **Library identification first.** Signature matching removes thousands of library functions so you can focus on the author's code.
- **Cross-references are the map.** Follow who calls a function, who writes a memory location, where a string is used, before reading linearly.
- **Version diffing.** Diff the vulnerable version against the fixed one; the patch points at the bug.
- **Document as you go.** Names, structures, protocol fields. Unnoted work gets redone.

## Workflow

1. **Authorization and scope.** Confirm in writing what may be analyzed and how output will be used. Set up an isolated lab (VM, snapshots, no production network).
2. **Recon.** File type, architecture, compiler/packer identification, hashes, strings, imports/exports. Check for known versions and published CVEs; don't reverse what's already documented. Always read strings and imports first.
3. **Behavioral baseline.** Run it safely in the lab; capture file, registry, network, and API activity. Note trust-boundary crossings: network input, file parsing, IPC.
4. **Targeted static analysis.** Load into a disassembler/decompiler; rename functions, recover structures, trace data flow from untrusted inputs to dangerous sinks (memory copies, format strings, deserialization, command execution).
5. **Dynamic confirmation.** Breakpoints and tracing to verify hypotheses about the interesting or vulnerable path.
6. **Report defensively.** Vuln research: affected versions, root cause, trigger conditions, impact, remediation (patch guidance, mitigations, detection). Malware: capabilities and IOCs. Interop: documented format/protocol spec.

## Analysis notes template

Use this structure for notes and reports:

- Binary identity: name, version, hash, source
- Authorization reference
- Behavioral summary
- Key functions/structures recovered (addresses/offsets)
- Trust boundaries and untrusted-input entry points
- Hypothesis log: claim, evidence for, evidence against, status
- Findings: description, evidence, severity, recommended action

## Pitfalls

- **Skipping authorization.** Get clearance first, especially for commercial software.
- **Boiling the ocean.** Target parser/auth/network code, not the whole binary.
- **Trusting the decompiler.** It approximates; verify critical logic against disassembly and dynamic traces.
- **No notes.** Undocumented RE is write-only work.
- **Findings without remediation.** A crash PoC without root cause and fix guidance is half a deliverable.
- **Leaking artifacts.** Reversed code, keys, and protocol details are as sensitive as the input; handle under the same authorization.
- **Misidentifying the toolchain.** Verify packer/compiler identification before deep static work.
- **First-hypothesis bias.** Actively look for disconfirming evidence.
- **Skipping strings and imports.** Ten minutes there often beats ten hours of disassembly.

## Sustaining the practice

- Keep a knowledge base of reversed protocols, formats, and techniques
- Contribute sanitized findings to runbooks and detection logic
- Version your scripts and tooling
- Re-verify old conclusions when new versions or samples appear
- Track: turnaround by complexity, % findings with confirmed root cause, hypothesis confirmation rate, notes completeness (could another analyst pick them up?)

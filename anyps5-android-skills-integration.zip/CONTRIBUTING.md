# Contributing to AnyPS5

Thanks for helping build AnyPS5. The project is intended to be open to contributions through reviewed pull requests.

## Before opening a PR

1. Read `README.md`, `anyps5/SKILL.md`, and `anyps5/ARCHITECTURE.md`.
2. Choose a focused issue or describe the exact feature and its test plan.
3. Confirm that code, assets, protocols, and test artifacts are licensed for the intended use.
4. Do not include proprietary game files, console firmware dumps, credentials, tokens, keys, or personal data.

## Pull request checklist

- [ ] Scope and user-visible behavior are described.
- [ ] Tests are added or the reason they cannot be added is explained.
- [ ] Device model, Android version, ABI, and build variant are recorded when relevant.
- [ ] Performance claims include trace/measurement context.
- [ ] Security and permission implications are reviewed.
- [ ] Compatibility claims are labelled verified / observed / hypothesis / unknown.
- [ ] Third-party licenses and attribution are preserved.

## Suggested issue labels

`good first issue`, `android-ui`, `native-arm64`, `controller-input`, `graphics`, `profiling`, `testing`, `documentation`, `research`, `needs-device-test`.

## Research and safety boundary

Contributions must focus on authorized interoperability and defensive analysis. Do not submit DRM circumvention, authentication bypass, exploit development, or unauthorized extraction/redistribution of proprietary material.

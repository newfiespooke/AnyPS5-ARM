# AnyPS5 Android Skills Integration Kit

This kit integrates the 36 Android Skills from `android-skills-1.0.1.txplugin` into the AnyPS5 development workflow. The upstream skill directories and their reference material are preserved under `skills/`; AnyPS5-specific guidance is added under `anyps5/`.

## What is included

- All 36 upstream skill directories and their bundled references.
- The upstream Android Skills license in `third_party/`.
- `anyps5/SKILL.md`: project-specific compatibility research and engineering workflow.
- `anyps5/SKILL-MATRIX.md`: disposition and use of all 36 skills.
- `anyps5/ARCHITECTURE.md`: realistic platform constraints and proposed architecture.
- `CONTRIBUTING.md`: contributor workflow and evidence standards.

## Important platform reality

PS5 software targets a proprietary AMD64/x86-64 console platform and platform-specific APIs; Android phones/tablets commonly target ARM64. A PS5 game binary is **not** a native Android ARM64 app and cannot be made one by simply copying files or changing an ABI setting. A lawful compatibility project must focus on independently implemented components, documented interfaces, user-owned test material, and authorized interoperability. Exact game compatibility is not promised.

## How to use the skills

Load the upstream skill when its topic is relevant, then apply the AnyPS5 overlay in `anyps5/SKILL.md`. The overlay supplies project scope, target architecture, evidence requirements, and PS5-specific test planning. Skills marked `NOT APPLICABLE` remain in the imported set for completeness but should not be invoked for the current core product.

## Android CLI package note

The source plugin contains an ARM64 Android CLI binary and launcher. This kit intentionally does not redistribute that executable; it preserves the 36 skills and their references. Install the CLI from its original trusted package/source on a compatible ARM64 environment and verify checksums before use.

## Provenance

Upstream source: Android Skills plugin package `android-skills-1.0.1.txplugin`, version 1.0.1, publisher TaiXu; the manifest describes 36 Google Android skills sourced from `google/android/skills` and licensed Apache-2.0. This kit preserves the bundled skill files and adds project-specific guidance.

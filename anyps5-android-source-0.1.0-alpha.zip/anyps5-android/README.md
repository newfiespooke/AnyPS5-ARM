# AnyPS5 for Android

An independent Android-native launcher shell for the AnyPS5 compatibility project. The current alpha delivers the red/black PS5-inspired dashboard, touch-first UI, basic Android game-controller key navigation, and a Storage Access Framework file picker.

> **Important:** This is an early launcher/UI port, not a working PS5 game emulator or compatibility runtime. It does not decrypt PS5 dumps, contain Sony firmware/keys, translate x86-64 code, or launch PS5 games yet. The runtime bridge, ARM64 translation, PS5 system-library reimplementation, Vulkan renderer, and per-title compatibility are separate engineering milestones.

## Build an APK

Requirements: JDK 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. Push this project to a GitHub repository and run **Actions → Build Android APK**. The resulting debug APK is uploaded as an Actions artifact.

## Input

- Touch: tap tiles and buttons; horizontal lists can be swiped.
- Gamepad: D-pad navigation, A/Enter select, B/Back return, X opens import, Y/Start opens settings.
- The UI does not yet forward controller state to a PS5 runtime.

## Current status

- [x] Native Android app shell (Kotlin + Jetpack Compose)
- [x] Red adaptive launcher icon
- [x] PS5-inspired dashboard and library
- [x] Touch controls
- [x] Basic controller/keyboard navigation
- [x] Import picker for user-selected files
- [ ] PS5 executable parsing / SELF handling
- [ ] x86-64 to ARM64 translation layer
- [ ] Android-compatible PS5 system libraries
- [ ] Vulkan renderer and shader pipeline
- [ ] Actual game launch and compatibility testing

## Project relationship

AnyPS5 upstream is GPL-2.0-only. This Android UI scaffold is independently written and does not copy upstream source. When integrating upstream GPL-2.0-only code, preserve its license and notices and review the obligations for the combined distribution. AnyPS5 is independent and is not affiliated with or endorsed by Sony Interactive Entertainment.

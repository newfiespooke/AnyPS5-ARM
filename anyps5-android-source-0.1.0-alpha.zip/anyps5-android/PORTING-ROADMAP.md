# Android port roadmap

## Phase 0: launcher shell (this alpha)
Native Compose dashboard, input navigation, file import, diagnostics placeholder, adaptive red icon.

## Phase 1: Android device capability layer
Detect ABI, Android API level, Vulkan instance/device/extensions, memory budget, storage permissions and controller devices. Produce a diagnostics report without attempting to run game code.

## Phase 2: file and metadata pipeline
Read user-selected files through persisted SAF URI permissions. Implement safe metadata inspection and title-library records. Do not bundle firmware, keys or proprietary files.

## Phase 3: compatibility runtime research
Evaluate a maintained x86-64-to-ARM64 translation approach, Android/Bionic integration, and the upstream PS5 system-library surface. Keep this behind a clean JNI boundary. Do not assume macOS-specific AnyPS5-ARM code can be reused unchanged on Android.

## Phase 4: graphics and input
Prototype Vulkan device selection, SPIR-V validation/recompilation path, controller mapping (including analog axes/triggers), touch overlay profiles and per-title input configuration.

## Phase 5: controlled bring-up
Use legally obtained homebrew/test binaries first. Add one title at a time with reproducible device/build logs and compatibility reports.

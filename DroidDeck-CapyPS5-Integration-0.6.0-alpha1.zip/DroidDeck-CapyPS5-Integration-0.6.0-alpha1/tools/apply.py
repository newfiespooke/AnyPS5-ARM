#!/usr/bin/env python3
"""Apply the CapyPS5 companion integration to a DroidDeck source checkout."""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

PATCH_MARKER = "DROIDDECK_CAPYPS5_INTEGRATION_060A1"


def replace_once(path: Path, old: str, new: str, *, already: str | None = None) -> None:
    text = path.read_text(encoding="utf-8")
    if already and already in text:
        print(f"already patched: {path.relative_to(REPO)}")
        return
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"Expected exactly one patch anchor in {path.relative_to(REPO)}, found {count}. "
            "This checkout may have changed; no further files will be patched."
        )
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"patched: {path.relative_to(REPO)}")


def copy_overlay(source_root: Path, repo_root: Path, relative: str) -> None:
    source = source_root / relative
    target = repo_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        existing = target.read_text(encoding="utf-8", errors="ignore")
        incoming = source.read_text(encoding="utf-8", errors="ignore")
        if existing == incoming:
            print(f"already present: {relative}")
            return
        raise RuntimeError(f"Refusing to overwrite existing file: {relative}")
    shutil.copy2(source, target)
    print(f"added: {relative}")


def apply(source_root: Path, repo_root: Path) -> None:
    required = [
        "app/src/main/AndroidManifest.xml",
        "app/build.gradle",
        "app/src/main/java/com/droiddeck/launcher/MainActivity.kt",
        "app/src/main/java/com/droiddeck/launcher/ui/FrontEndScreen.kt",
        "app/src/main/java/com/droiddeck/launcher/ui/FrontEndContent.kt",
        "app/src/main/java/com/droiddeck/launcher/ui/FrontEndRail.kt",
        "app/src/main/java/com/droiddeck/launcher/ui/FrontEndSetup.kt",
        "app/src/main/res/values/strings.xml",
    ]
    missing = [p for p in required if not (repo_root / p).is_file()]
    if missing:
        raise RuntimeError("Not a supported DroidDeck checkout; missing: " + ", ".join(missing))

    # Add the independent companion bridge and UI first. All source files are separate
    # from CapyPS5 and are safe to remove as a unit if this experimental feature is reverted.
    for relative in [
        "app/src/main/java/com/droiddeck/launcher/capyps5/CapyPs5Bridge.kt",
        "app/src/main/java/com/droiddeck/launcher/ui/CapyPs5Page.kt",
        "app/src/test/java/com/droiddeck/launcher/capyps5/CapyPs5ScannerTest.kt",
    ]:
        copy_overlay(source_root, repo_root, relative)

    gradle = repo_root / "app/build.gradle"
    replace_once(
        gradle,
        '        versionCode 14\n        versionName "0.5.0"\n',
        '        versionCode 15\n        versionName "0.6.0-alpha1" // ' + PATCH_MARKER + '\n',
        already='versionName "0.6.0-alpha1"',
    )

    manifest = repo_root / "app/src/main/AndroidManifest.xml"
    replace_once(
        manifest,
        '    xmlns:tools="http://schemas.android.com/tools">\n',
        '    xmlns:tools="http://schemas.android.com/tools">\n\n'
        '    <queries>\n'
        '        <package android:name="org.capyps5.emulator" />\n'
        '    </queries>\n',
        already='package android:name="org.capyps5.emulator"',
    )

    frontend_screen = repo_root / "app/src/main/java/com/droiddeck/launcher/ui/FrontEndScreen.kt"
    replace_once(
        frontend_screen,
        '    val onRoms: () -> Unit,\n',
        '    val onRoms: () -> Unit,\n'
        '    val onCapyPs5: () -> Unit = {}, // ' + PATCH_MARKER + '\n',
        already="val onCapyPs5: () -> Unit",
    )

    main_activity = repo_root / "app/src/main/java/com/droiddeck/launcher/MainActivity.kt"
    replace_once(
        main_activity,
        '                        onRoms = { showRoms = true },\n',
        '                        onCapyPs5 = { navRequest = "capyps5" },\n'
        '                        onRoms = { showRoms = true },\n',
        already='onCapyPs5 = { navRequest = "capyps5" }',
    )

    content = repo_root / "app/src/main/java/com/droiddeck/launcher/ui/FrontEndContent.kt"
    replace_once(
        content,
        '    if (selected == "setup") {\n',
        '    if (selected == "capyps5") {\n'
        '        CapyPs5Page(modifier)\n'
        '        return\n'
        '    }\n'
        '    if (selected == "setup") {\n',
        already='CapyPs5Page(modifier)',
    )

    rail = repo_root / "app/src/main/java/com/droiddeck/launcher/ui/FrontEndRail.kt"
    replace_once(
        rail,
        'import androidx.compose.material.icons.outlined.VideoLibrary\n',
        'import androidx.compose.material.icons.outlined.VideoLibrary\n'
        'import androidx.compose.material.icons.outlined.VideogameAsset\n',
        already='import androidx.compose.material.icons.outlined.VideogameAsset',
    )
    replace_once(
        rail,
        '        val count = 6 + (if (s.gameStoresEnabled) 1 else 0) + (if (s.isHomeApp) 1 else 0)\n',
        '        val count = 7 + (if (s.gameStoresEnabled) 1 else 0) + (if (s.isHomeApp) 1 else 0)\n',
        already='val count = 7 + (if (s.gameStoresEnabled)',
    )
    replace_once(
        rail,
        '            add("steam"); add("games")\n',
        '            add("steam"); add("games"); add("capyps5")\n',
        already='add("steam"); add("games"); add("capyps5")',
    )
    replace_once(
        rail,
        '            RailItem(stringResource(R.string.rail_games), Icons.Outlined.VideoLibrary, "games", shown == "games", compact, iconOnly, fit, place = place, onFocus = { onFocusSelect("games") }) { onSelect("games") }\n',
        '            RailItem(stringResource(R.string.rail_games), Icons.Outlined.VideoLibrary, "games", shown == "games", compact, iconOnly, fit, place = place, onFocus = { onFocusSelect("games") }) { onSelect("games") }\n'
        '            RailItem(stringResource(R.string.rail_capyps5), Icons.Outlined.VideogameAsset, "capyps5", shown == "capyps5", compact, iconOnly, fit, place = place, onFocus = { onFocusSelect("capyps5") }) { onSelect("capyps5") }\n',
        already='RailItem(stringResource(R.string.rail_capyps5)',
    )

    setup = repo_root / "app/src/main/java/com/droiddeck/launcher/ui/FrontEndSetup.kt"
    replace_once(
        setup,
        '                        SettingsGroup(stringResource(R.string.setup_runtime)) { runtimeCheck(false) }\n',
        '                        SettingsGroup(stringResource(R.string.setup_runtime)) { runtimeCheck(false) }\n'
        '                        SettingsGroup(stringResource(R.string.capyps5_setup_group)) {\n'
        '                            SettingsRow(stringResource(R.string.capyps5_setup_title), stringResource(R.string.capyps5_setup_hint)) {\n'
        '                                SecondaryButton(stringResource(R.string.capyps5_open_library), compact = true, onClick = a.onCapyPs5)\n'
        '                            }\n'
        '                        }\n',
        already='SettingsGroup(stringResource(R.string.capyps5_setup_group))',
    )

    strings = repo_root / "app/src/main/res/values/strings.xml"
    additions = '''
    <!-- DROIDDECK_CAPYPS5_INTEGRATION_060A1 -->
    <string name="rail_capyps5">PS5</string>
    <string name="capyps5_title">CapyPS5</string>
    <string name="capyps5_subtitle">Your PS5 library, launched from DroidDeck</string>
    <string name="capyps5_setup_group">PlayStation 5</string>
    <string name="capyps5_setup_title">CapyPS5 integration</string>
    <string name="capyps5_setup_hint">Find your PS5 game dumps and launch them from the DroidDeck library.</string>
    <string name="capyps5_open_library">Open PS5 library</string>
    <string name="capyps5_installed">CapyPS5 is installed</string>
    <string name="capyps5_not_installed">CapyPS5 is not installed</string>
    <string name="capyps5_settings_note">Open CapyPS5 once and grant its requested all-files access. Graphics drivers, per-game options, frame generation, touch controls and emulator updates are managed in CapyPS5 itself.</string>
    <string name="capyps5_open_settings">Open CapyPS5</string>
    <string name="capyps5_get_app">Get CapyPS5</string>
    <string name="capyps5_choose_folder">Choose folder</string>
    <string name="capyps5_pick_folder">Choose your PS5 game folder</string>
    <string name="capyps5_library">PS5 game library</string>
    <string name="capyps5_folder_format">Each game folder must contain eboot.bin and a sce_sys folder. You can choose the CapyPS5 folder or a parent folder containing game folders.</string>
    <string name="capyps5_games_found">%1$d games found</string>
    <string name="capyps5_rescan">Rescan</string>
    <string name="capyps5_empty_title">No PS5 game dumps found</string>
    <string name="capyps5_empty_hint">Choose the folder where your own dumped PS5 titles are stored. Incomplete folders are skipped.</string>
    <string name="capyps5_play">Play</string>
    <string name="capyps5_open_failed">Could not open CapyPS5.</string>
    <string name="capyps5_launch_failed">Could not hand this game to CapyPS5. Open CapyPS5 directly and check that the game is listed there.</string>
    <string name="capyps5_compatibility">Device check</string>
    <string name="capyps5_compatibility_detail">Android 12+: %1$s · ARM64: %2$s · Vulkan 1.3: %3$s · Memory: %4$s</string>
    <string name="capyps5_ram_ok">12 GB RAM recommendation met</string>
    <string name="capyps5_ram_below">below 12 GB recommendation</string>
    <string name="capyps5_device_warning">This device does not report all of CapyPS5’s baseline requirements. The emulator may not start or may be unstable.</string>
    <string name="capyps5_shader_note">Vulkan shaderInt64 is also required by current CapyPS5 builds. Android does not expose this GPU feature in the simple system-feature check above, so CapyPS5 verifies it when starting.</string>
    <string name="capyps5_yes">Yes</string>
    <string name="capyps5_no">No</string>
'''
    replace_once(strings, '</resources>', additions + '</resources>', already='DROIDDECK_CAPYPS5_INTEGRATION_060A1')

    print("\nCapyPS5 integration source applied.")
    print("Review the diff and run the DroidDeck unit tests/build before installing an APK.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", nargs="?", default=".", help="DroidDeck checkout directory")
    args = parser.parse_args()
    REPO = Path(args.repo).resolve()
    SOURCE_ROOT = Path(__file__).resolve().parents[1]
    try:
        apply(SOURCE_ROOT, REPO)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

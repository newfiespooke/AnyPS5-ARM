#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
REPO="${1:-.}"
exec python3 "$ROOT/tools/apply.py" "$REPO"

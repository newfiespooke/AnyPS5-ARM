# Upstream and release checklist

Before each release of this integration:

- [ ] Check CapyPS5's launcher activity remains exported.
- [ ] Check its game activity remains non-exported and is launched internally.
- [ ] Confirm `launch_elf` and `launch_dir` are still consumed on launcher activity creation.
- [ ] Run scanner tests and inspect symlink/depth/result bounds.
- [ ] Verify the package query exists in the merged manifest.
- [ ] Verify Setup → Overview and the PS5 rail entry navigate to the same page.
- [ ] Test installed, missing, upgraded and removed CapyPS5 states.
- [ ] Test on Adreno, Mali, Xclipse and PowerVR devices where available.
- [ ] Test Android 12+ and unsupported Android/ABI/Vulkan combinations.
- [ ] Confirm all game dumps remain user-supplied and excluded from release artifacts.
- [ ] Build a signed APK from a clean checkout and attach full source/build provenance.

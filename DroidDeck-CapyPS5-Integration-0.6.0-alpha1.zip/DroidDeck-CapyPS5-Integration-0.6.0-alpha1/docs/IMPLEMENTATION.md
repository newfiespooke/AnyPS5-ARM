# Implementation notes

## Component boundaries

```text
DroidDeck rail / Setup
        |
        v
CapyPs5Page (Compose library + quick settings entry)
        |
        +--> CapyPs5Bridge.scan()   reads game-folder metadata only
        |
        +--> PackageManager        discovers org.capyps5.emulator
        |
        +--> explicit launcher Intent
                  launch_elf + launch_dir
                         |
                         v
              CapyPS5 MainActivity
                         |
                         v
              CapyPS5 private GameActivity
```

No CapyPS5 Kotlin, JNI, native library, emulator runtime, shaders, or proprietary assets are included.

## Scanner invariants

- Accept a directory with `eboot.bin` and `sce_sys/`.
- Skip PS4-style `param.sfo`-only folders until CapyPS5 exposes playable PS4 support.
- Treat `sce_sys/param.json` as optional metadata and fall back to the folder name.
- Bound recursion at three directory levels and 250 results.
- Canonicalize paths and reject symlinks/paths that escape the chosen root.
- Do not unpack, rewrite, patch, or execute game files in DroidDeck.

## Settings ownership

DroidDeck stores only the selected library path in its own preferences. CapyPS5 continues to own its emulator configuration, drivers, controller mappings, frame-generation and per-game settings. This keeps the two applications independently updateable.

## Device checks

DroidDeck reads Android version, ABI, advertised Vulkan API version, and physical memory. It does not claim to query Vulkan `shaderInt64` from Java package metadata; CapyPS5 performs that GPU feature check itself.

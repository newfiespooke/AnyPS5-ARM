package com.droiddeck.launcher.capyps5

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class CapyPs5ScannerTest {
    @Test fun scansOnlyFoldersWithEbootAndSceSys() {
        val root = createTempDir(prefix = "capyps5-library-")
        try {
            val valid = File(root, "PPSA00001").apply { mkdirs() }
            File(valid, "eboot.bin").writeBytes(byteArrayOf(1, 2, 3))
            File(valid, "sce_sys").mkdirs()

            val missingSceSys = File(root, "incomplete").apply { mkdirs() }
            File(missingSceSys, "eboot.bin").writeBytes(byteArrayOf(1))

            val ps4Only = File(root, "ps4-dump").apply { mkdirs() }
            File(ps4Only, "eboot.bin").writeBytes(byteArrayOf(1))
            File(ps4Only, "sce_sys").mkdirs()
            File(ps4Only, "sce_sys/param.sfo").writeBytes(byteArrayOf(1))

            val nested = File(root, "collection/second-title").apply { mkdirs() }
            File(nested, "eboot.bin").writeBytes(byteArrayOf(1))
            File(nested, "sce_sys").mkdirs()

            val games = CapyPs5Bridge.scan(root)
            assertEquals(listOf("PPSA00001", "second-title"), games.map { it.title })
            assertTrue(games.all { it.eboot.isFile && File(it.directory, "sce_sys").isDirectory })
        } finally {
            root.deleteRecursively()
        }
    }

    @Test fun missingFolderReturnsEmptyLibrary() {
        val root = createTempDir(prefix = "capyps5-missing-")
        try {
            val missing = File(root, "not-created")
            assertTrue(CapyPs5Bridge.scan(missing).isEmpty())
        } finally {
            root.deleteRecursively()
        }
    }
}

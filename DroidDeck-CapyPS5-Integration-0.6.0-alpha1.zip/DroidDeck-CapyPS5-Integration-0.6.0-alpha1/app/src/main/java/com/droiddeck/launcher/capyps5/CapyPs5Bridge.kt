package com.droiddeck.launcher.capyps5

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.util.Log
import org.json.JSONObject
import java.io.File

/** Companion-app bridge. CapyPS5 remains a separately installed application/process. */
object CapyPs5Bridge {
    const val PACKAGE_NAME = "org.capyps5.emulator"
    private const val PREFS = "droiddeck_capyps5"
    private const val KEY_LIBRARY = "library_path"
    private const val TAG = "CapyPS5Bridge"
    private const val MAX_SCAN_DEPTH = 3
    private const val MAX_GAMES = 250
    private const val MAX_PARAM_JSON_BYTES = 1024L * 1024L
    private const val VULKAN_1_3 = 0x00403000

    data class Game(val title: String, val directory: File, val eboot: File) {
        val stableKey: String get() = runCatching { directory.canonicalPath }.getOrDefault(directory.absolutePath)
        val icon: File? get() = File(directory, "sce_sys/icon0.png").takeIf { it.isFile }
    }

    data class DeviceCompatibility(
        val android12OrLater: Boolean,
        val arm64: Boolean,
        val vulkan13: Boolean,
        val ram12GbRecommended: Boolean,
    ) {
        val meetsHardRequirements: Boolean get() = android12OrLater && arm64 && vulkan13
    }

    fun libraryFolder(context: Context): String = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_LIBRARY, File(Environment.getExternalStorageDirectory(), "CapyPS5").absolutePath)
        ?: File(Environment.getExternalStorageDirectory(), "CapyPS5").absolutePath

    fun setLibraryFolder(context: Context, path: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LIBRARY, File(path).absolutePath).apply()
    }

    fun isInstalled(context: Context): Boolean = launchIntent(context) != null

    fun open(context: Context): Boolean {
        val intent = launchIntent(context) ?: return false
        return runCatching {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }.onFailure { Log.w(TAG, "Unable to open CapyPS5", it) }.getOrDefault(false)
    }

    /**
     * CapyPS5 v0.0.5 consumes launch_elf/launch_dir in its exported launcher
     * activity and starts its private GameActivity internally. The extras are an
     * upstream implementation hook, not a stable public API; see integration docs.
     */
    fun launchGame(context: Context, game: Game): Boolean {
        if (!game.eboot.isFile || !game.directory.isDirectory) return false
        val intent = launchIntent(context) ?: return false
        intent.putExtra("launch_elf", game.eboot.absolutePath)
        intent.putExtra("launch_dir", game.directory.absolutePath)
        return runCatching {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            true
        }.onFailure { Log.w(TAG, "Unable to hand game to CapyPS5", it) }.getOrDefault(false)
    }

    fun compatibility(context: Context): DeviceCompatibility {
        val features = context.packageManager.systemAvailableFeatures.orEmpty()
        val vulkanVersion = features.firstOrNull { it.name == PackageManager.FEATURE_VULKAN_HARDWARE_VERSION }?.version ?: 0
        val memory = ActivityManager.MemoryInfo().also {
            (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it)
        }
        return DeviceCompatibility(
            android12OrLater = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S,
            arm64 = Build.SUPPORTED_ABIS.any { it.equals("arm64-v8a", ignoreCase = true) },
            vulkan13 = vulkanVersion >= VULKAN_1_3,
            ram12GbRecommended = memory.totalMem >= 12L * 1024L * 1024L * 1024L,
        )
    }

    /** Finds dumped titles with eboot.bin + sce_sys/, bounded to depth/count. */
    fun scan(root: File?): List<Game> {
        if (root == null || !root.isDirectory) return emptyList()
        val canonicalRoot = runCatching { root.canonicalFile }.getOrNull() ?: return emptyList()
        val found = LinkedHashMap<String, Game>()

        fun visit(directory: File, depth: Int) {
            if (found.size >= MAX_GAMES) return
            val canonical = runCatching { directory.canonicalFile }.getOrNull() ?: return
            val canonicalPath = canonical.path
            if (canonicalPath != canonicalRoot.path && !canonicalPath.startsWith(canonicalRoot.path + File.separator)) return
            if (!canonical.isDirectory) return
            val eboot = File(canonical, "eboot.bin")
            val sceSys = File(canonical, "sce_sys")
            val paramJson = File(sceSys, "param.json")
            val paramSfo = File(sceSys, "param.sfo")
            // CapyPS5 currently detects param.sfo-only folders as PS4 titles;
            // that early compatibility path is listed by CapyPS5 but not playable.
            val ps4OnlyDump = paramSfo.isFile && !paramJson.isFile
            if (eboot.isFile && sceSys.isDirectory && !ps4OnlyDump) {
                val game = Game(readTitle(canonical), canonical, eboot)
                found.putIfAbsent(game.stableKey, game)
                return
            }
            if (depth >= MAX_SCAN_DEPTH) return
            canonical.listFiles()?.asSequence()
                ?.filter { it.isDirectory && it.name != "sce_sys" }
                ?.sortedBy { it.name.lowercase() }
                ?.forEach { child -> if (found.size < MAX_GAMES) visit(child, depth + 1) }
        }

        visit(canonicalRoot, 0)
        return found.values.sortedBy { it.title.lowercase() }
    }

    private fun readTitle(directory: File): String {
        val fallback = directory.name.ifBlank { "Untitled PS5 game" }
        val metadata = File(directory, "sce_sys/param.json")
        if (!metadata.isFile || metadata.length() !in 1..MAX_PARAM_JSON_BYTES) return fallback
        return runCatching {
            val json = JSONObject(metadata.readText())
            val localized = json.optJSONObject("localizedParameters")
            val locale = java.util.Locale.getDefault()
            val localizedTitle = localized?.optJSONObject(locale.toLanguageTag())
                ?: localized?.keys()?.asSequence()
                    ?.firstOrNull { it.startsWith(locale.language + "-") }
                    ?.let { localized.optJSONObject(it) }
                ?: localized?.optString("defaultLanguage")?.takeIf { it.isNotBlank() }?.let { localized.optJSONObject(it) }
                ?: localized?.optJSONObject("en-US")
            sequenceOf(
                localizedTitle?.optString("titleName"),
                json.optString("titleName"),
                json.optString("title"),
                json.optString("name"),
            ).mapNotNull { it?.trim()?.takeIf { title -> title.isNotEmpty() && title != "null" } }
                .firstOrNull() ?: fallback
        }.getOrDefault(fallback)
    }

    @Suppress("DEPRECATION")
    private fun launchIntent(context: Context): Intent? = try {
        if (Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageInfo(PACKAGE_NAME, PackageManager.PackageInfoFlags.of(0))
        } else {
            context.packageManager.getPackageInfo(PACKAGE_NAME, 0)
        }
        context.packageManager.getLaunchIntentForPackage(PACKAGE_NAME)?.addCategory(Intent.CATEGORY_LAUNCHER)
    } catch (_: PackageManager.NameNotFoundException) {
        null
    } catch (error: Exception) {
        Log.w(TAG, "Unable to resolve CapyPS5 launcher", error)
        null
    }
}

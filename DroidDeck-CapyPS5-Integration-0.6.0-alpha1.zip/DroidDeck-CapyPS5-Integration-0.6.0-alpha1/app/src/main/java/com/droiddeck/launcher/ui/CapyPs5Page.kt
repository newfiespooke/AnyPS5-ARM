package com.droiddeck.launcher.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.VideogameAsset
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.droiddeck.launcher.R
import com.droiddeck.launcher.capyps5.CapyPs5Bridge
import com.droiddeck.launcher.files.InAppFilePicker
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
internal fun CapyPs5Page(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var folder by remember { mutableStateOf(CapyPs5Bridge.libraryFolder(context)) }
    var games by remember { mutableStateOf<List<CapyPs5Bridge.Game>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    var installed by remember { mutableStateOf(CapyPs5Bridge.isInstalled(context)) }
    val compatibility = remember { CapyPs5Bridge.compatibility(context) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            InAppFilePicker.pickedPath(result.data)?.let { selected ->
                folder = selected
                CapyPs5Bridge.setLibraryFolder(context, selected)
                refreshKey++
            }
        }
    }

    LaunchedEffect(folder, refreshKey) {
        scanning = true
        games = withContext(Dispatchers.IO) { CapyPs5Bridge.scan(File(folder)) }
        scanning = false
        installed = CapyPs5Bridge.isInstalled(context)
    }

    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Outlined.VideogameAsset, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(modifier = Modifier.weight(1f)) {
                Text(stringResource(R.string.capyps5_title), fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(stringResource(R.string.capyps5_subtitle), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { refreshKey++ }) {
                Icon(Icons.Outlined.Refresh, contentDescription = stringResource(R.string.capyps5_rescan))
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (installed) stringResource(R.string.capyps5_installed) else stringResource(R.string.capyps5_not_installed),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp,
                )
                Text(stringResource(R.string.capyps5_settings_note), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        if (!installed || !CapyPs5Bridge.open(context)) {
                            runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://capyps5.org"))) }
                                .onFailure { Toast.makeText(context, R.string.capyps5_open_failed, Toast.LENGTH_LONG).show() }
                        }
                    }) {
                        Text(if (installed) stringResource(R.string.capyps5_open_settings) else stringResource(R.string.capyps5_get_app))
                    }
                    OutlinedButton(onClick = {
                        folderPicker.launch(InAppFilePicker.buildDirIntent(context, context.getString(R.string.capyps5_pick_folder), folder))
                    }) {
                        Icon(Icons.Outlined.FolderOpen, contentDescription = null)
                        Text(stringResource(R.string.capyps5_choose_folder))
                    }
                }
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.capyps5_library), fontWeight = FontWeight.SemiBold, fontSize = 19.sp)
                Text(folder, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(stringResource(R.string.capyps5_folder_format), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.capyps5_games_found, games.size), modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    if (scanning) CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.height(22.dp))
                    else TextButton(onClick = { refreshKey++ }) { Text(stringResource(R.string.capyps5_rescan)) }
                }
            }
        }

        if (games.isEmpty() && !scanning) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.capyps5_empty_title), fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.capyps5_empty_hint), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        games.forEach { game ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (game.icon != null) {
                        AsyncImage(
                            model = game.icon,
                            contentDescription = game.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)),
                        )
                    } else {
                        Icon(Icons.Outlined.VideogameAsset, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(game.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(game.directory.name, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Button(enabled = installed, onClick = {
                        if (!CapyPs5Bridge.launchGame(context, game)) {
                            Toast.makeText(context, R.string.capyps5_launch_failed, Toast.LENGTH_LONG).show()
                            installed = CapyPs5Bridge.isInstalled(context)
                        }
                    }) { Text(stringResource(R.string.capyps5_play)) }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.capyps5_compatibility), fontWeight = FontWeight.SemiBold)
        Text(
            stringResource(
                R.string.capyps5_compatibility_detail,
                if (compatibility.android12OrLater) stringResource(R.string.capyps5_yes) else stringResource(R.string.capyps5_no),
                if (compatibility.arm64) stringResource(R.string.capyps5_yes) else stringResource(R.string.capyps5_no),
                if (compatibility.vulkan13) stringResource(R.string.capyps5_yes) else stringResource(R.string.capyps5_no),
                if (compatibility.ram12GbRecommended) stringResource(R.string.capyps5_ram_ok) else stringResource(R.string.capyps5_ram_below),
            ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(stringResource(R.string.capyps5_shader_note), color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (!compatibility.meetsHardRequirements) {
            Text(stringResource(R.string.capyps5_device_warning), color = MaterialTheme.colorScheme.error)
        }
    }
}

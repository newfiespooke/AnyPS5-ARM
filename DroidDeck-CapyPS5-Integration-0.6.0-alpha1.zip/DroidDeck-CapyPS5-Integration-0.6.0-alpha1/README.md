# DroidDeck + CapyPS5 integration

**Target:** `newfiespooke/DroidDeck` fork, Android app source  
**Target app version:** `0.6.0-alpha1` (versionCode 15, based on fork 0.5.0)  
**Integration style:** independent companion app, first-class launcher/library surface

This source patch adds CapyPS5 discovery and launch controls to DroidDeck without copying CapyPS5 code or native libraries into the DroidDeck APK.

## What this adds

- A **PS5** entry in DroidDeck's left navigation rail.
- A **PlayStation 5 / CapyPS5 integration** section in Setup → Overview.
- Package discovery for `org.capyps5.emulator` on Android 11+.
- A saved PS5 game-folder location, selected using DroidDeck's existing file picker.
- A bounded scanner for dumped title folders containing both `eboot.bin` and `sce_sys/`.
- A title list with one-tap **Play** actions.
- A button to open CapyPS5 itself, where its own graphics, driver, controller, frame-generation and per-game settings remain available.
- A device checklist for Android 12+, ARM64, Vulkan 1.3 and the 12 GB RAM recommendation.
- Unit tests for valid, incomplete and nested game-folder scanning.

## Installation and use

1. Clone or check out your DroidDeck fork locally.
2. Unzip this package.
3. Run:

   ```sh
   python3 tools/apply.py /path/to/DroidDeck
   ```

   Or from this package directory:

   ```sh
   ./tools/apply.sh /path/to/DroidDeck
   ```

4. Review the applied changes:

   ```sh
   cd /path/to/DroidDeck
   git diff --check
   git diff
   ```

5. Install CapyPS5 separately from its official project release. Open it once and grant its requested all-files access. Then open DroidDeck → Setup → Overview → PlayStation 5, or use the **PS5** rail entry.
6. Choose the parent folder that contains your own PS5 game folders. A title is listed when it contains `eboot.bin` and `sce_sys/`.
7. Select **Play** beside a title. To change GPU drivers, rendering, frame generation or the controller layout, open CapyPS5 from the same page and use its own Settings screens.

The scanner checks the selected root plus nested directories to a maximum depth of three and lists at most 250 games. It sorts titles by display name and uses a folder name when `sce_sys/param.json` does not expose a readable title field.

## Launch contract and compatibility note

CapyPS5's Android manifest exports `org.capyps5.emulator.MainActivity` as its launcher activity but declares `GameActivity` as non-exported. The bridge therefore launches the exported launcher with `launch_elf` and `launch_dir` extras; CapyPS5 v0.0.5 reads those extras from its launcher intent and creates its private game activity internally.

That extra-based handoff is an implementation hook documented in CapyPS5's current source comment, **not a versioned public API**. It is tested against the source shape available when this patch was prepared. A later CapyPS5 update could remove or rename the extras. If a title does not start, launch CapyPS5 directly and check whether that build still accepts the handoff. The patch never tries to start the private `GameActivity` directly.

The bridge intentionally does not attempt to share DroidDeck's FEX, Proton, Vulkan driver selection, overlay, frame-generation, or controller injection settings with CapyPS5. The two apps run as separate Android processes and own their own runtime/configuration. This is a first-class library/launcher integration, not a merged PS5 emulator engine.

## Requirements and legal boundary

CapyPS5 documents Android 12+, arm64 and a Vulkan 1.3 GPU with `shaderInt64`; 12 GB RAM is recommended. The UI marks the RAM figure as a recommendation, not a hard requirement. Android's package-feature query does not verify `shaderInt64`, so CapyPS5 itself remains responsible for that runtime GPU check. Actual game compatibility and performance depend on the device and GPU driver.

Use only PS5 game dumps you are legally entitled to use. This patch contains no games, firmware, BIOS, Sony keys, game data, or CapyPS5 executable/library files.

DroidDeck is GPL-3.0 and CapyPS5 is GPL-2.0-only. To avoid combining incompatible licensed code into one derivative work, CapyPS5 remains an independently installed app. DroidDeck only uses Android package discovery and an intent handoff. Do not copy CapyPS5 sources or native libraries into the DroidDeck APK without separate permission or a licensing change from the relevant rights holders.

## Build and test

From your DroidDeck checkout, use its documented Android build setup. Then run:

```sh
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

The test source added by this patch is `app/src/test/java/com/droiddeck/launcher/capyps5/CapyPs5ScannerTest.kt`.

This package is a **source patch**, not a prebuilt APK. The bridge has not been compiled or tested on a physical Android device in this environment. Build and test it in the DroidDeck checkout before distributing it.

## Rollback

Remove the added `CapyPs5Bridge.kt`, `CapyPs5Page.kt`, and scanner test. Revert the marked changes in the existing `FrontEnd*` files, `MainActivity.kt`, `AndroidManifest.xml`, and `strings.xml`. No existing game data or CapyPS5 installation is modified.
